'use strict';

/**
 * Extra functies van het apparaat (logboek, geschiedenis, besparing, prijzen van morgen, weer).
 * Deze methoden worden aan InverterDevice gehangen.
 */

/** true als versie a (bijv. "3.44.0") nieuwer is dan b. */
function versionNewer(a, b) {
  const pa = String(a).split('.').map(Number); const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
}
const { getJson, postJson } = require('../../lib/http');
const dynamic = require('../../lib/dynamic');
const vattenfall = require('../../lib/vattenfall');
const vattenMerge = require('../../lib/vattenmerge');
const { createRemote } = require('../../lib/remote');
const seriesLib = require('../../lib/series');
const compare2 = require('../../lib/compare2');
const i18n = require('../../lib/i18n');
const dayReview = require('../../lib/dayreview');
const standby = require('../../lib/standby');
const yearCompare = require('../../lib/yearcompare');
const paybackLib = require('../../lib/payback');
const invoiceLib = require('../../lib/invoice');
const learnLib = require('../../lib/learn');
const dayCompare = require('../../lib/daycompare');
const insights = require('../../lib/insights');
const healthLib = require('../../lib/health');
const usageLib = require('../../lib/usage');
const scoreLib = require('../../lib/score');
const feedin = require('../../lib/feedin');
const feedinWarn = require('../../lib/feedinwarn');
const batteryDyn = require('../../lib/batterydyn');
const solisCloud = require('../../lib/soliscloud');
const prices = require('../../lib/prices');
const forecast = require('../../lib/forecast');
const history = require('../../lib/history');
const shadow = require('../../lib/shadow');
const planner = require('../../lib/planner');
const loadsLib = require('../../lib/loads');
const anomaly = require('../../lib/anomaly');
const expensive = require('../../lib/expensive');
const batteryLib = require('../../lib/battery');
const report = require('../../lib/report');
const connLib = require('../../lib/conn');
const bugLib = require('../../lib/report_bug');
const doctorLib = require('../../lib/doctor');
const brands = require('../../lib/brands');
const lightLib = require('../../lib/light');
const weekplan = require('../../lib/weekplan');
const csvLib = require('../../lib/csv');
const sunLib = require('../../lib/sun');
const hImport = require('../../lib/homeyimport');
const reconstruct = require('../../lib/reconstruct');
const { zoned, hhmm, addDays, isSunday, fmtDate, parseDate, parseMonth } = require('../../lib/timeutil');

const MAX_EVENTS = 50;
const EXTERNAL_EVERY_MS = 20 * 60 * 1000;
const FORECAST_EVERY_MS = 3 * 60 * 60 * 1000;

function nl(v, d) { return Number(v).toFixed(d).replace('.', ','); }

module.exports = {
  // ---------- logboek ----------
  /** Taal van de app: instelling Taal, of de taal van Homey. */
  applyLanguage() {
    try {
      let hl = 'nl';
      try { hl = this.homey.i18n.getLanguage(); } catch (e) { hl = 'nl'; }
      i18n.setLang(i18n.resolve(this.getSettings().language, hl));
    } catch (e) { this.error(e.message); }
  },

  logEvent(text) {
    const tz = this.homey.clock.getTimezone();
    text = i18n.tr(String(text));
    const e = { t: Date.now(), text };
    this.events = (this.events || []).concat([e]).slice(-MAX_EVENTS);
    this.setCapabilityValue('inverter_last_event', hhmm(e.t, tz) + ' ' + text.slice(0, 60)).catch(this.error);
    this.setStoreValue('events', this.events).catch(this.error);
  },

  eventLines(n) {
    const tz = this.homey.clock.getTimezone();
    return (this.events || []).slice(-n).reverse().map((e) => {
      const z = zoned(e.t, tz);
      return z.date.slice(8) + '-' + z.date.slice(5, 7) + ' ' + hhmm(e.t, tz) + ' ' + e.text;
    });
  },

  async showLog() {
    const lines = this.eventLines(10);
    const text = lines.length ? lines.join(' | ') : i18n.tr('Nog geen gebeurtenissen.');
    try {
      await this.sendNotification('Solis logboek: ' + text);
    } catch (e) { this.error('Logboek melding mislukt:', e.message); }
    return text;
  },

  async restartConnection() {
    this.logEvent('Verbinding herstart (handmatig).');
    this.fails = 0;
    this.connect();
    this.schedulePoll(200);
  },

  // ---------- extra meldingen ----------
  checkExtraAlerts(d) {
    const s = this.getSettings();
    // temperatuur
    const tmax = Number(s.tempMax) || 70;
    if (d.temperature > tmax && !this.tempNotified) {
      this.tempNotified = true;
      this.logEvent('Temperatuur hoog: ' + nl(d.temperature, 1) + ' °C');
      this.notify('temp', 'temperatuur van de omvormer is ' + nl(d.temperature, 1) + ' °C (grens ' + tmax + ' °C).');
    } else if (d.temperature < tmax - 5) {
      this.tempNotified = false;
    }
    // geen opbrengst terwijl de panelen spanning geven
    const noYield = this.online !== false && this.lastEffective !== 'uit' && d.power === 0 && d.dcVoltage >= 100;
    const now = Date.now();
    if (noYield) {
      if (!this.noYieldSince) this.noYieldSince = now;
      if (now - this.noYieldSince > 15 * 60 * 1000 && !this.noYieldNotified) {
        this.noYieldNotified = true;
        this.logEvent('Geen opbrengst terwijl panelen ' + nl(d.dcVoltage, 0) + ' V geven');
        this.notify('noyield', 'geen opbrengst, terwijl de panelen ' + nl(d.dcVoltage, 0) + ' V geven. Status: ' + d.statusText + '.');
      }
    } else {
      this.noYieldSince = 0;
      this.noYieldNotified = false;
    }
  },

  checkPriceZone(price) {
    const s = this.getSettings();
    if (this.currentContract() !== 'dynamisch' || price === null) { this.priceZone = null; return; }
    let zone = 'ok';
    if (price < s.uitBelow) zone = 'neg';
    else if (price < s.geenExportBelow) zone = 'low';
    if (this.priceZone && this.priceZone !== zone) {
      const txt = zone === 'neg' ? 'prijs is onder je uit-grens (' + nl(price, 3) + ' €/kWh).'
        : zone === 'low' ? 'prijs is onder je export-grens (' + nl(price, 3) + ' €/kWh).'
          : 'prijs is weer boven je grenzen (' + nl(price, 3) + ' €/kWh).';
      this.logEvent('Prijs: ' + zone + ' (' + nl(price, 3) + ')');
      this.notify('price', txt);
    }
    this.priceZone = zone;
  },

  // ---------- geschiedenis en dagafsluiting ----------
  closeDay(d) {
    if (!d || !d.date || !d.lastTick) return;
    const entry = this.dayEntry(d);
    this.history = history.addDay(this.history || [], entry);
    this.setStoreValue('history', this.history).catch(this.error);
    this.checkSoiling();
    this.checkAnomalies(d.date);
    this.checkPanelUnderperform(d.date);
  },

  // ---------- afwijkingen ----------
  checkAnomalies(date) {
    try {
      const h = this.history || [];
      const kWp = Number(this.getSettings().kWp) || 2.5;
      const ya = anomaly.yieldAnomaly(h, date, kWp);
      const code = this.forecastData && this.forecastData.codes ? this.forecastData.codes[date] : null;
      const msgs = [anomaly.consumptionAnomaly(h, date), ya ? ya + anomaly.cause(code) : null].filter(Boolean);
      for (const m of msgs) {
        this.logEvent('Afwijking: ' + m.slice(0, 80));
        this.notify('anomaly', m);
      }
    } catch (e) { this.error('Afwijkingscontrole mislukt:', e.message); }
  },

  // ---------- dure uren ----------
  async checkExpensive() {
    const s = this.getSettings();
    if (s.notifyExpensive === false || this.currentContract() !== 'dynamisch') return;
    const entries = [].concat((this.todayPrices && this.todayPrices.entries) || [], (this.tomorrowPrices && this.tomorrowPrices.entries) || []);
    const r = expensive.upcoming(entries, Date.now(), Number(s.fixedCosts) || 0, Number(s.expensiveAbove) || 0);
    if (!r) return;
    const key = String(r.from);
    if (this.getStoreValue('lastExpensive') === key) return;
    await this.setStoreValue('lastExpensive', key).catch(this.error);
    const tz = this.homey.clock.getTimezone();
    const eur = (v) => String(v.toFixed(2)).replace('.', ',');
    const text = 'Straks wordt stroom duur: van ' + planner.hh(r.from, tz) + ' tot ' + planner.hh(r.to, tz) + ', tot € ' + eur(r.peak) + ' per kWh. Gebruik zware apparaten liever eerder of later.';
    this.homey.flow.getDeviceTriggerCard('expensive_soon').trigger(this, { from: planner.hh(r.from, tz), to: planner.hh(r.to, tz), price: Math.round(r.peak * 1000) / 1000 }).catch(this.error);
    this.logEvent('Dure uren aangekondigd: ' + planner.hh(r.from, tz) + '-' + planner.hh(r.to, tz));
    await this.notify('expensive', text);
  },


  // ---------- dynamisch contract (2027) ----------
  avgDailyKwh() {
    const rows = (this.history || []).slice(-30).filter((h) => typeof h.importWh === 'number' && typeof h.exportWh === 'number' && h.kwh >= 0);
    if (rows.length < 7) return 0;
    const tot = rows.reduce((a, h) => a + Math.max(0, h.kwh * 1000 - h.exportWh + h.importWh), 0);
    return Math.round(tot / rows.length / 100) / 10;
  },

  dynamicInfo() {
    const s = this.getSettings();
    const ps = this.priceSeries();
    const a = dynamic.analyse({ today: ps.today, tomorrow: ps.tomorrow, add: Number(s.fixedCosts) || 0, dailyKwh: this.avgDailyKwh(), fixedPrice: Number(s.importTariffFixed) || 0, flexKwh: 2 });
    return {
      from: parseDate(s.dynamicFrom) || '2027-01-01',
      days: dynamic.daysUntil(parseDate(s.dynamicFrom) || '2027-01-01', this.todayString()),
      active: this.currentContract() === 'dynamisch',
      dailyKwh: this.avgDailyKwh(),
      add: Number(s.fixedCosts) || 0,
      analysis: a,
      battery: a ? batteryDyn.estimate({ cheap: a.cheap.avg, pricey: a.pricey.avg, pricePerKwh: Number(s.batteryPricePerKwh) || 0 }) : null,
      feedin: feedin.status(history.overview(this.history || [], this.todayString(), this.dayEntry(this.stats.data()), { imp: Number(s.importTariffFixed) || 0, exp: Number(s.exportTariffFixed) || 0 }).month, feedin.costAt(s.feedInSchedule, s.feedInCost, this.todayString())),
      negSaved: this.negSavedInfo(),
      dayCompare: dayCompare.compare(this.history || [], { imp: Number(this.getSettings().importTariffFixed) || 0, exp: Number(this.getSettings().exportTariffFixed) || 0 }, 14),
      score: scoreLib.summary(this.history || [], Number(s.kWp) || 2.5),
    };
  },

  /** Melding als de prijs onder jouw alarmgrens zakt (één keer per keer dat hij zakt). */
  async checkPriceAlarm() {
    const s = this.getSettings();
    if (s.notifyPriceAlarm !== true) { this.priceAlarmOn = false; return; }
    const p = this.freshPrice();
    if (p === null) return;
    const thr = Number(s.priceAlarmBelow);
    if (!Number.isFinite(thr)) return;
    if (p < thr && !this.priceAlarmOn) {
      this.priceAlarmOn = true;
      const text = 'De stroomprijs is nu € ' + String(p.toFixed(3)).replace('.', ',') + ' per kWh, onder je alarmgrens van € ' + String(thr.toFixed(3)).replace('.', ',') + '. Goed moment voor boiler, auto of wasmachine.';
      this.logEvent('Prijsalarm: ' + p);
      this.homey.flow.getDeviceTriggerCard('price_below').trigger(this, { price: Math.round(p * 1000) / 1000 }).catch(this.error);
      await this.notify('pricealarm', text);
    } else if (p >= thr + 0.01) this.priceAlarmOn = false;
  },

  /** Gegevens voor de terugleverwaarschuwing (zie lib/feedinwarn.js). null bij een vast contract of zonder prijzen. */
  feedinBreak(series) {
    const s = this.getSettings();
    if (this.currentContract() !== 'dynamisch') return null;
    const cost = feedin.costAt(s.feedInSchedule, s.feedInCost, this.todayString());
    return feedinWarn.analyse(series || this.priceSeries(), Number(s.fixedCosts) || 0, cost);
  },

  /** Meldt (eenmaal per dag) dat morgen de prijs negatief wordt en/of dat terugleveren geld kost. Beide in één bericht. */
  async checkNegativeTomorrow() {
    const s = this.getSettings();
    if ((s.notifyNegative === false && s.notifyFeedinWarn === false) || !this.tomorrowPrices) return;
    const tom = this.tomorrowPrices.date;
    if (this.getStoreValue('lastNegative') === tom) return;
    await this.setStoreValue('lastNegative', tom).catch(this.error);
    const ps = this.priceSeries();
    const a = dynamic.analyse({ today: null, tomorrow: ps.tomorrow, add: Number(s.fixedCosts) || 0 });
    const negHours = a && a.negHours ? a.negHours : [];
    const negOn = s.notifyNegative !== false && negHours.length > 0;
    const fb = s.notifyFeedinWarn !== false ? this.feedinBreak(ps) : null;
    const extra = feedinWarn.extraText(fb, negHours);
    if (!negOn && !extra) return;
    const hh = (h) => String(h).padStart(2, '0') + ':00';
    if (negOn) {
      this.logEvent('Negatieve prijs morgen aangekondigd.');
      this.homey.flow.getDeviceTriggerCard('negative_tomorrow').trigger(this, { from: hh(negHours[0]), to: hh((negHours[negHours.length - 1] + 1) % 24) }).catch(this.error);
      await this.notify('expensive', dynamic.negText(a) + (extra ? ' ' + extra : ''));
    } else {
      this.logEvent('Terugleverwaarschuwing voor morgen.');
      await this.notify('feedinWarn', extra);
    }
  },

  // ---------- SolisCloud: echte dagopbrengst ----------
  async importSolisCloud() {
    const s = this.getSettings();
    const cfg = { keyId: String(s.soliscloudKeyId || '').trim(), secret: String(s.soliscloudSecret || '').trim(), sn: String(s.soliscloudSn || '').trim() };
    if (!cfg.keyId || !cfg.secret) throw new Error('Vul eerst bij Instellingen de SolisCloud KeyID en KeySecret in.');
    const post = this.postJson || postJson;
    const today = this.todayString();
    const first = (this.history || []).length ? this.history[0].date : addDays(today, -400);
    const from = first < addDays(today, -800) ? addDays(today, -800) : first;
    const days = await solisCloud.fetchDays(cfg, from, addDays(today, -1), post);
    let set = 0; let added = 0;
    const have = new Map((this.history || []).map((h) => [h.date, h]));
    for (const date of Object.keys(days).sort()) {
      const kwh = days[date];
      const h = have.get(date);
      if (h) {
        if (!h.imported) continue; // eigen gemeten dag blijft zoals hij is
        if (kwh > 0 && h.kwh !== kwh) { h.kwh = kwh; delete h.solarEstimated; h.solarCloud = true; set++; }
      } else if (kwh > 0) {
        this.history = history.addDay(this.history || [], { date, kwh, imported: true, solarCloud: true });
        added++;
      }
    }
    const st = this.getSettings();
    const est = hImport.applyEstimates(this.history || [], st.importTariffFixed, st.exportTariffFixed);
    await this.setStoreValue('history', this.history).catch(this.error);
    const text = 'SolisCloud: ' + Object.keys(days).length + ' dagen opgehaald, ' + set + ' bijgewerkt, ' + added + ' nieuw. Euro\'s opnieuw berekend voor ' + est + ' dagen.';
    this.logEvent(text);
    return { text, days: Object.keys(days).length, set, added };
  },


  // ---------- automatische back-up ----------
  backupDownload() {
    this.setStoreValue('lastBackupDownload', Date.now()).catch(this.error);
    return this.backupData();
  },

  /** Elke nacht een kopie in de app-opslag van Homey (met de vorige als reserve). Overleeft het opnieuw toevoegen van het apparaat. */
  async autoBackup() {
    const today = this.todayString();
    if (this.currentMinutes() < 3 * 60 || this.getStoreValue('lastAutoBackup') === today) return;
    if (!(this.history || []).length || !this.homey.settings) return;
    const prev = this.homey.settings.get('autoBackup');
    if (prev && prev.data) this.homey.settings.set('autoBackupPrev', prev);
    this.homey.settings.set('autoBackup', { t: Date.now(), days: this.history.length, data: this.backupData() });
    await this.setStoreValue('lastAutoBackup', today).catch(this.error);
    this.logEvent('Automatische back-up gemaakt (' + this.history.length + ' dagen).');
  },

  /** Is de geschiedenis leeg (apparaat opnieuw toegevoegd) en bestaat er een back-up? Zet die dan terug. */
  async restoreFromAutoBackup() {
    if (!this.homey.settings) return false;
    const ab = this.homey.settings.get('autoBackup');
    const cur = (this.history || []).length;
    if (!ab || !ab.data || !Array.isArray(ab.data.history) || cur >= 5 || ab.data.history.length <= cur) return false;
    await this.restoreData(ab.data);
    this.logEvent('Geschiedenis automatisch teruggezet uit de back-up van ' + fmtDate(new Date(ab.t).toISOString().slice(0, 10)) + '.');
    return true;
  },

  /** Herinnering om af en toe zelf een back-up te downloaden (die staat dan buiten Homey). */
  async checkBackupReminder() {
    const s = this.getSettings();
    if (s.notifyBackup === false || this.vacationOn() || (this.history || []).length < 14) return;
    const now = Date.now();
    const last = Math.max(this.getStoreValue('lastBackupDownload') || 0, this.getStoreValue('lastBackupReminder') || 0);
    if (!last) { await this.setStoreValue('lastBackupReminder', now).catch(this.error); return; }
    if (now - last < 45 * 24 * 3600 * 1000 || this.currentMinutes() < 10 * 60) return;
    await this.setStoreValue('lastBackupReminder', now).catch(this.error);
    this.logEvent('Herinnering back-up verstuurd.');
    await this.notifyText('Je hebt al even geen back-up gedownload. Open het dashboard en kies onderaan "Back-up downloaden", dan staat je geschiedenis ook buiten Homey veilig.');
  },

  // ---------- factuurcontrole ----------
  invoiceInfo() {
    const s = this.getSettings();
    const hist = this.history || [];
    const last = invoiceLib.totals(hist, invoiceLib.prevMonth(this.todayString()));
    return { last: last.days ? last : null, check: invoiceLib.check(hist, { month: s.invoiceMonth, importKwh: s.invoiceImportKwh, exportKwh: s.invoiceExportKwh, total: s.invoiceTotal, fixedMonthly: s.invoiceFixedMonthly }) };
  },

  async checkInvoice() {
    const s = this.getSettings();
    const c = invoiceLib.check(this.history || [], { month: s.invoiceMonth, importKwh: s.invoiceImportKwh, exportKwh: s.invoiceExportKwh, total: s.invoiceTotal, fixedMonthly: s.invoiceFixedMonthly });
    if (!c) return;
    const sig = [parseMonth(s.invoiceMonth) || s.invoiceMonth, s.invoiceImportKwh, s.invoiceExportKwh, s.invoiceTotal, s.invoiceFixedMonthly, c.own.days].join('|');
    if (this.getStoreValue('lastInvoiceSig') === sig) return;
    await this.setStoreValue('lastInvoiceSig', sig).catch(this.error);
    this.logEvent('Factuurcontrole ' + c.label + ': ' + c.verdict);
    await this.notifyText(c.text);
  },

  // ---------- jaarterugblik ----------
  async checkYearly() {
    const s = this.getSettings();
    if (s.notifyYearly === false || this.vacationOn()) return;
    const today = this.todayString();
    const mm = today.slice(5, 10);
    let year = null;
    if (mm === '12-31' && this.currentMinutes() >= 18 * 60) year = today.slice(0, 4);
    else if (mm === '01-01' && this.currentMinutes() >= 9 * 60) year = String(Number(today.slice(0, 4)) - 1);
    if (!year || this.getStoreValue('lastYearly') === year) return;
    await this.setStoreValue('lastYearly', year).catch(this.error);
    const hist = this.history || [];
    const last = year + '-12-31';
    if (hist.filter((h) => h.date.startsWith(year)).length < 30) return;
    const ov = history.overview(hist, last, history.get(hist, last) || { date: last, kwh: 0 }, { imp: Number(s.importTariffFixed) || 0, exp: Number(s.exportTariffFixed) || 0 });
    const prev = ov.prev && ov.prev.hasData ? ov.prev.toDate.kwh : null;
    this.logEvent('Jaarterugblik verstuurd.');
    await this.notifyText(report.yearlyText(year, ov.year, prev, ov.whatIfYear));
  },


  /** Zet een melding op de Homey-tijdlijn en geeft hem ook door aan de flow-kaart "Solis melding" (daarmee kun je een pushmelding naar je telefoon sturen). */
  async sendNotification(text) {
    try { this.pushFeed(text); } catch (x) { this.error(x.message); }
    text = i18n.tr(String(text));
    const r = await this.homey.notifications.createNotification({ excerpt: text });
    try { this.homey.flow.getDeviceTriggerCard('notification').trigger(this, { tekst: text }).catch((x) => this.error(x.message)); } catch (x) { this.error(x.message); }
    return r;
  },


  // ---------- verbruik uit Homey Energie ----------
  /** Dagcijfers van Homey Energie (kWh). Homey rekent het verbruik zelf uit uit P1, omvormer en apparaten. */
  async homeyEnergyDay(date) {
    const api = await this.getAppApi();
    if (!api.energy || typeof api.energy.getReportDay !== 'function') throw new Error('Deze Homey geeft geen energierapport door.');
    let rep;
    try { rep = await api.energy.getReportDay({ date }); } catch (err) {
      if (/not found/i.test(String(err && err.message))) return null; // Homey bewaart dit rapport niet (meer)
      throw err;
    }
    const el = rep && rep.electricity;
    if (!el || typeof el.consumedPeriod !== 'number') return null;
    const n = (v) => (typeof v === 'number' && isFinite(v) ? Math.round(v * 1000) / 1000 : null);
    return { use: n(el.consumedPeriod), self: n(el.solarSelfUsedPeriod), imp: n(el.importedPeriod), exp: n(el.exportedPeriod), gen: n(el.generatedPeriod) };
  },

  /** Vandaag (elke 5 minuten) voor het dashboard. */
  async refreshHomeyToday() {
    if (Date.now() - (this.homeyTodayAt || 0) < 5 * 60 * 1000) return;
    this.homeyTodayAt = Date.now();
    try {
      const date = this.todayString();
      const r = await this.homeyEnergyDay(date);
      if (r && r.use !== null) this.homeyToday = Object.assign({ date }, r);
      this.homeyEnergyErr = false;
    } catch (e) {
      if (!this.homeyEnergyErr) { this.homeyEnergyErr = true; this.logEvent('Homey Energie vandaag ophalen mislukt: ' + String(e.message).slice(0, 60)); }
    }
  },

  /** Verbruik van eerdere dagen uit Homey Energie, per dag, tot de tijd op is. Opnieuw uitvoeren gaat verder waar het bleef. */
  async importHomeyEnergy(maxDays) {
    const today = this.todayString();
    const hist = this.history || [];
    if (!hist.length) throw new Error('Nog geen geschiedenis. Haal eerst de geschiedenis uit Homey op.');
    const start = Date.now();
    const todo = hist.filter((h) => h.date < today && typeof h.useKwh !== 'number' && !h.noHomeyUse).map((h) => h.date).reverse().slice(0, maxDays || 400);
    let done = 0;
    let fails = 0;
    let none = 0;
    let noneRun = 0;
    for (const date of todo) {
      if (Date.now() - start > 90 * 1000) break;
      try {
        const r = await this.homeyEnergyDay(date);
        const h = history.get(this.history, date);
        if (!h) continue;
        if (r && r.use !== null && r.use >= 0) { h.useKwh = r.use; if (r.self !== null) h.selfKwh = r.self; done++; noneRun = 0; } else {
          h.noHomeyUse = true; none++; noneRun++;
          if (noneRun >= 5) { // Homey heeft deze oudere dagen niet meer: de rest overslaan
            for (const dd of todo) { const hh = history.get(this.history, dd); if (hh && dd < date && typeof hh.useKwh !== 'number') { hh.noHomeyUse = true; none++; } }
            break;
          }
        }
        fails = 0;
      } catch (e) {
        fails++;
        if (fails >= 5) { await this.setStoreValue('history', this.history).catch(this.error); throw new Error('Homey Energie reageert niet: ' + String(e.message).slice(0, 60)); }
      }
    }
    await this.setStoreValue('history', this.history).catch(this.error);
    const left = Math.max(0, todo.filter((dd) => { const hh = history.get(this.history, dd); return hh && typeof hh.useKwh !== 'number' && !hh.noHomeyUse; }).length);
    let monthTxt = '';
    try { const gm = await this.importHomeyMonths(); monthTxt = ' Maandtotalen van ' + Object.keys(this.homeyMonths || {}).length + ' maanden staan klaar (' + gm + ' nieuw).'; } catch (e) { monthTxt = ' Maandtotalen ophalen lukte niet: ' + String(e.message).slice(0, 60) + '.'; }
    this.logEvent('Homey Energie: verbruik van ' + done + ' dagen opgehaald' + (left ? ', nog ' + left + ' te gaan' : '') + '.');
    return 'Verbruik van ' + done + ' dagen uit Homey Energie opgehaald' + (none ? ' (voor ' + none + ' oudere dagen bewaart Homey geen rapport, daar gebruikt de app zijn eigen berekening)' : '') + '.' + (left ? ' Er zijn nog ' + left + ' dagen over. Druk nog een keer op de knop om verder te gaan.' : ' Alles is binnen.') + monthTxt;
  },

  /** Maandcijfers van Homey Energie (kWh). Maandrapporten blijven veel langer bewaard dan dagrapporten. Homey beschrijft de parameternaam niet, dus we proberen een paar varianten. */
  async homeyEnergyMonth(ym) {
    const api = await this.getAppApi();
    if (!api.energy || typeof api.energy.getReportMonth !== 'function') throw new Error('Deze Homey geeft geen maandrapport door.');
    let rep = null;
    let lastErr = null;
    for (const args of [{ yearMonth: ym }, { month: ym }, { date: ym }, { date: ym + '-01' }]) {
      try { rep = await api.energy.getReportMonth(args); lastErr = null; break; } catch (err) {
        lastErr = err;
        if (/not found/i.test(String(err && err.message)) && args.yearMonth) { /* mogelijk bestaat de maand niet: toch ook andere naam proberen */ }
      }
    }
    if (!rep) { if (lastErr && !/not found/i.test(String(lastErr.message))) throw lastErr; return null; }
    const el = rep.electricity;
    if (!el || typeof el.consumedPeriod !== 'number') return null;
    const n = (v) => (typeof v === 'number' && isFinite(v) ? Math.round(v * 10) / 10 : null);
    const imp = n(el.importedPeriod);
    const exp = n(el.exportedPeriod);
    const gen = n(el.generatedPeriod);
    // Homey's 'consumedPeriod' per maand klopt niet met het huisverbruik (bleek lager dan wat er is ingekocht); daarom zelf uitrekenen: opwek + ingekocht - teruggeleverd
    const use = imp !== null && exp !== null ? n(Math.max(0, (gen || 0) + imp - exp)) : n(el.consumedPeriod);
    return { v: 2, use, homeyUse: n(el.consumedPeriod), self: n(el.solarSelfUsedPeriod), imp, exp, gen };
  },

  /** Haalt de maandtotalen van de afgelopen 24 maanden en bewaart ze (de lopende maand wordt telkens ververst). */
  async importHomeyMonths() {
    const today = this.todayString();
    const months = Object.assign({}, this.getStoreValue('homeyMonths') || {});
    let y = Number(today.slice(0, 4));
    let m = Number(today.slice(5, 7));
    let got = 0;
    let fails = 0;
    let lastMsg = '';
    for (let i = 0; i < 24; i++) {
      const ym = y + '-' + String(m).padStart(2, '0');
      const isNow = i === 0;
      if (isNow || !months[ym] || months[ym].v !== 2) {
        try {
          const r = await this.homeyEnergyMonth(ym);
          if (r && r.use !== null) { months[ym] = r; got++; }
        } catch (e) { fails++; lastMsg = String(e.message).slice(0, 60); if (fails >= 3) break; }
      }
      m--; if (m < 1) { m = 12; y--; }
    }
    await this.setStoreValue('homeyMonths', months).catch(this.error);
    this.homeyMonths = months;
    this.logEvent('Homey Energie: ' + got + ' maanden opgehaald.');
    if (!got && fails) throw new Error('Maandrapport ophalen mislukt: ' + lastMsg);
    return got;
  },

  /** Elke nacht het verbruik van gisteren uit Homey Energie halen. */
  async checkHomeyEnergyDaily() {
    const today = this.todayString();
    if (this.currentMinutes() < 3 * 60 + 30 || this.getStoreValue('lastHomeyEnergy') === today) return;
    const y = addDays(today, -1);
    const h = history.get(this.history || [], y);
    await this.setStoreValue('lastHomeyEnergy', today).catch(this.error);
    if (!h) return;
    try {
      const r = await this.homeyEnergyDay(y);
      if (r && r.use !== null) { h.useKwh = r.use; if (r.self !== null) h.selfKwh = r.self; await this.setStoreValue('history', this.history).catch(this.error); }
      await this.importHomeyMonths().catch((x) => this.error(x.message));
    } catch (e) { this.logEvent('Homey Energie gisteren ophalen mislukt: ' + String(e.message).slice(0, 60)); }
  },

  /** Maanden zonder eigen opbrengstgegevens aanvullen met wat Homey Energie als opwek kent. */
  withHomeyMonths(ov) {
    const hm = this.homeyMonths || this.getStoreValue('homeyMonths') || {};
    const yy = this.todayString().slice(0, 4);
    const r1 = (v) => Math.round(v * 10) / 10;
    const rows = [];
    (ov.months || []).forEach((x) => {
      const r = hm[yy + '-' + String(x.m).padStart(2, '0')];
      const own = (this.history || []).filter((h) => h.date.startsWith(yy + '-' + String(x.m).padStart(2, '0')));
      const gen = x.kwh > 0 ? x.kwh : (r && typeof r.gen === 'number' ? r1(r.gen) : 0);
      const ownImp = own.reduce((a, h) => a + (Number(h.importWh) || 0), 0) / 1000;
      const ownExp = own.reduce((a, h) => a + (Number(h.exportWh) || 0), 0) / 1000;
      const imp = r && typeof r.imp === 'number' ? r1(r.imp) : (ownImp > 0 ? r1(ownImp) : null);
      const exp = r && typeof r.exp === 'number' ? r1(r.exp) : (ownExp > 0 ? r1(ownExp) : null);
      const use = r && typeof r.use === 'number' ? r1(r.use) : (imp !== null && exp !== null ? r1(Math.max(0, gen + imp - exp)) : null);
      if (gen > 0 || imp !== null || exp !== null || use !== null) rows.push({ m: x.m, gen, use, imp, exp });
    });
    ov.monthTable = rows;
    return ov;
  },

  /** Slimme inzichten voor het dashboard: sluipverbruik, opbrengst tegenover normaal, schaduw, maandbudget, CO2. */
  slimInfo() {
    const s = this.getSettings();
    const today = this.todayString();
    const mins = this.currentMinutes();
    const entry = this.dayEntry(this.stats.data());
    const all = history.addDay(this.history || [], entry);
    const tariff = Number(s.importTariffFixed) || 0;
    const tariffs = { imp: tariff, exp: Number(s.exportTariffFixed) || 0 };
    const sm = history.overview(this.history || [], today, entry, tariffs);
    const totalKwh = Math.max(Number(this.getCapabilityValue('meter_power')) || 0, all.reduce((a, h) => a + (Number(h.kwh) || 0), 0));
    const use = usageLib.summary(all, today, this.homeyMonths || this.getStoreValue('homeyMonths') || {});
    const ysum = sm.year;
    const selfShare = ysum.kwh > 0 ? Math.max(0, Math.min(1, 1 - ysum.exportKwh / ysum.kwh)) : 0.4;
    const price = this.freshPrice();
    const d = this.stats.data();
    const pv = Number(this.getCapabilityValue('measure_power')) || 0;
    const netOk = this.netW !== null && this.netW !== undefined && Date.now() - this.netAt < 120000;
    const pt = planner.planText((this.planResult || []).filter((p) => p.day === 'vandaag'), this.homey.clock.getTimezone());
    const fc = this.forecastFor(0);
    return {
      standby: insights.standby(all, today, mins, tariff),
      expected: insights.expected(all, s.panelKwp, today, 14),
      shade: insights.shade(all, today),
      budget: insights.budget(sm.month.importKwh, s.budgetImportKwh, today, mins),
      co2: Object.assign(insights.co2(totalKwh), { kwh: Math.round(totalKwh) }),
      grid: insights.grid(all, today),
      saldering: insights.saldering(all, tariffs, Number(s.feedInCost) || 0, today),
      household: insights.household(use.ready ? use.avg30 : null, s.householdSize),
      forecastYear: insights.yearForecast(all, s.panelKwp, today, Object.assign({ selfShare }, tariffs)),
      goal: insights.goal(all, today, s.goalSelfPct),
      live: netOk ? insights.liveEuro(pv, this.netW, this.importPrice(price), this.exportPrice(price)) : { ready: false },
      tip: { forecast: fc, plan: pt || null },
      kwp: Number(s.panelKwp) || 0,
      v: d.vMax || 0,
    };
  },

  /** Meldingen: sluipverbruik omhoog, maandbudget (80 %, op, of het gaat te hard). Elk maar één keer. */
  async checkSlim() {
    const s = this.getSettings();
    if (this.vacationOn()) return;
    const today = this.todayString();
    const info = this.slimInfo();
    if (s.notifyStandby !== false && info.standby.ready && info.standby.up) {
      const key = today.slice(0, 7) + ':' + Math.round(info.standby.nowW / 25);
      if (this.getStoreValue('lastStandby') !== key) {
        await this.setStoreValue('lastStandby', key).catch(this.error);
        this.logEvent('Sluipverbruik omhoog: ' + info.standby.nowW + ' W.');
        await this.notifyText('Sluipverbruik: ' + info.standby.text);
      }
    }
    const b = info.budget;
    if (b.ready) {
      const month = today.slice(0, 7);
      const sent = this.getStoreValue('budgetSent') || {};
      const done = sent.month === month ? sent.levels || [] : [];
      let lvl = null;
      if (b.pct >= 100) lvl = 'over';
      else if (b.pct >= 80) lvl = 'bijna';
      else if (b.projPct !== null && b.projPct > 110 && Number(today.slice(8, 10)) >= 7) lvl = 'tempo';
      if (lvl && !done.includes(lvl)) {
        await this.setStoreValue('budgetSent', { month, levels: done.concat(lvl) }).catch(this.error);
        this.logEvent('Maandbudget: ' + lvl + ' (' + b.pct + ' %).');
        await this.notifyText('Maandbudget: ' + b.text);
      }
    }
    // netspanning: één melding per dag als de omvormer waarschijnlijk is teruggeschakeld
    if (s.notifyVoltage !== false) {
      const d = this.stats.data();
      const topMin = Math.round((d.vTopMs || 0) / 60000);
      if (topMin >= 5 && this.getStoreValue('lastVoltageDay') !== today) {
        await this.setStoreValue('lastVoltageDay', today).catch(this.error);
        this.logEvent('Hoge netspanning: ' + Math.round(d.vMax) + ' V, ' + topMin + ' min.');
        await this.notifyText('Netspanning: vandaag ' + topMin + ' minuten op 253 V of hoger (hoogste ' + String(Math.round(d.vMax * 10) / 10).replace('.', ',') + ' V). De omvormer schakelt dan terug en je mist opbrengst. ' + (info.grid.ready && info.grid.topDays >= 3 ? 'Dit gebeurt vaker: vraag je netbeheerder om de spanning te meten.' : 'Gebeurt dit vaker, vraag dan je netbeheerder om de spanning te meten.'));
      }
    }
    // reeks van het dagelijkse doel
    const gl = info.goal;
    if (s.notifyGoal !== false && gl.ready && [3, 7, 14, 30].includes(gl.streak) && this.getStoreValue('lastGoalStreak') !== today + ':' + gl.streak) {
      await this.setStoreValue('lastGoalStreak', today + ':' + gl.streak).catch(this.error);
      await this.notifyText('Doel gehaald: ' + gl.streak + ' dagen op rij boven ' + gl.goal + ' % eigen gebruik. Mooi bezig.');
    }
    // uitleg achteraf: gisteren niet teruggeleverd bij negatieve prijzen
    if (s.notifyNegDay !== false && this.currentMinutes() >= 7 * 60) {
      const y = addDays(today, -1);
      const h = history.get(this.history || [], y);
      if (h && (Number(h.saved) || 0) >= 0.05 && (Number(h.blockedWh) || 0) >= 200 && this.getStoreValue('lastNegDay') !== y) {
        await this.setStoreValue('lastNegDay', y).catch(this.error);
        await this.notifyText('Gisteren (' + fmtDate(y) + ') heb ik niet teruggeleverd toen de prijs negatief was: ongeveer ' + String(Math.round(h.blockedWh / 10) / 100).replace('.', ',') + ' kWh. Dat scheelde je ongeveer € ' + String((Math.round(h.saved * 100) / 100).toFixed(2)).replace('.', ',') + '.');
      }
    }
  },

  /** Onderhoudsherinnering: half maart (na de winter) en half oktober (na de bladeren). Elk jaar één keer per moment. */
  async checkMaintenance() {
    const s = this.getSettings();
    if (s.notifyMaintenance === false || this.vacationOn()) return;
    const today = this.todayString();
    const md = today.slice(5);
    const key = md >= '03-15' && md < '04-15' ? today.slice(0, 4) + '-voorjaar' : md >= '10-15' && md < '11-15' ? today.slice(0, 4) + '-najaar' : null;
    if (!key || this.getStoreValue('lastMaintenance') === key || this.currentMinutes() < 10 * 60) return;
    await this.setStoreValue('lastMaintenance', key).catch(this.error);
    const ex = insights.expected(history.addDay(this.history || [], this.dayEntry(this.stats.data())), s.panelKwp, today, 14);
    const extra = ex.ready ? ' Je opbrengst is de laatste 14 dagen ' + ex.pct + ' % van wat gebruikelijk is.' : '';
    this.logEvent('Onderhoudsherinnering ' + key);
    await this.notifyText(key.endsWith('voorjaar') ? 'Onderhoud: de winter is voorbij. Kijk of er vuil, mos of vogelpoep op de panelen ligt en of er nergens iets los zit. Spuit ze eventueel af met water, nooit met een hogedrukspuit.' + extra : 'Onderhoud: de bladeren vallen. Kijk of er blad of vuil op de panelen ligt, zodat de opbrengst in de donkere maanden niet onnodig daalt.' + extra);
  },

  /** Alleen-lezen overzicht van de instellingen voor het dashboard. Geen sleutels of wachtwoorden. */
  settingsView() {
    const s = this.getSettings();
    const yn = (v) => (v ? 'Aan' : 'Uit');
    const eur3 = (v) => (Number(v) > 0 ? '\u20AC ' + String(Number(v).toFixed(3)).replace('.', ',') : 'niet ingevuld');
    const num = (v, u) => (Number(v) > 0 ? String(Number(v)).replace('.', ',') + (u ? ' ' + u : '') : 'niet ingevuld');
    const notif = [
      ['Storing of geen gegevens', s.notifyFault !== false], ['Dagrapport', s.notifyDaily !== false], ['Weekrapport', s.notifyWeekly !== false], ['Maandrapport', s.notifyMonthly !== false],
      ['Ochtendsamenvatting', s.notifyMorning !== false], ['Afwijkingen', s.notifyAnomaly !== false], ['Hoge temperatuur', s.notifyTemp !== false], ['Netspanning', s.notifyVoltage !== false],
      ['Sluipverbruik', s.notifyStandby !== false], ['Onderhoud', s.notifyMaintenance !== false], ['Negatieve prijs morgen', s.notifyNegative !== false], ['Dure uren', s.notifyExpensive !== false],
      ['Goed moment', s.notifyGoodMoment === true], ['Prijsalarm', s.notifyPriceAlarm === true], ['Apparaat klaar', s.notifyApplianceDone !== false], ['Apparaat te lang aan', s.notifyApplianceLong !== false], ['Doel en reeksen', s.notifyGoal !== false],
    ];
    const contract = this.currentContract ? this.currentContract() : s.contract;
    return [
      { t: 'Contract en tarieven', rows: [
        ['Contract nu', contract === 'dynamisch' ? 'Dynamisch' : 'Vast'],
        ['Dynamisch vanaf', s.contract === 'vast' ? (fmtDate(parseDate(s.dynamicFrom) || '2027-01-01')) : 'n.v.t.'],
        ['Leverancier', s.supplier === 'Andere' ? s.supplierOther || 'Andere' : s.supplier],
        ['Vast: afname per kWh', eur3(s.importTariffFixed)], ['Vast: teruglevering per kWh', eur3(s.exportTariffFixed)],
        ['Vaste kosten dynamisch', eur3(s.fixedCosts)], ['Terugleverkosten per kWh', Number(s.feedInCost) > 0 ? eur3(s.feedInCost) : 'geen'],
      ] },
      { t: 'Installatie en doelen', rows: [
        ['Vermogen panelen', num(s.panelKwp, 'kWp')], ['Personen in huis', num(s.householdSize)], ['Maandbudget inkoop', num(s.budgetImportKwh, 'kWh')],
        ['Dagelijks doel eigen gebruik', Number(s.goalSelfPct) > 0 ? Math.round(s.goalSelfPct) + ' %' : 'uit'], ['Aanschafprijs', Number(s.purchasePrice) > 0 ? '\u20AC ' + Math.round(s.purchasePrice) : 'niet ingevuld'],
        ['Vakantiestand', yn(s.vacationMode)],
      ] },
      { t: 'Meldingen', on: notif.filter((x) => x[1]).map((x) => x[0]), off: notif.filter((x) => !x[1]).map((x) => x[0]) },
      { t: 'Sturing en apparaten', rows: [
        ['Uit onder', Number(s.uitBelow) > 0 ? eur3(s.uitBelow) : 'niet gebruikt'], ['Geen export onder', eur3(s.geenExportBelow)],
        ['Tijdvenster geen export', s.windowEnabled ? (s.windowFrom + ' tot ' + s.windowTo) : 'Uit'],
        ['Apparaten volgen', s.trackAuto ? 'alle slimme stekkers' : (String(s.trackDevices || '').split(',').filter((x) => x.trim()).length + ' gekozen')],
        ['Planner', (s.plannerLearnedAuto !== false ? 'geleerde apparaten' : 'handmatig') + (String(s.plannerTasks || '').trim() ? ' + eigen lijst' : '')],
        ['Zelfverbruik-sturing', s.loadsEnabled ? (s.loadsTest !== false ? 'Aan (testmodus)' : 'Aan') : 'Uit'],
      ] },
      { t: 'Koppelingen', rows: [
        ['P1-dongle', yn(s.p1Enabled !== false)], ['Uurprijzen ophalen', yn(s.fetchPrices !== false)],
        ['SolisCloud', s.soliscloudKeyId && s.soliscloudSecret ? 'Ingesteld' : 'Niet ingesteld'],
        ['Maandcijfers Homey Energie', Object.keys(this.homeyMonths || this.getStoreValue('homeyMonths') || {}).length + ' maanden'],
        ['Dagen in geschiedenis', String((this.history || []).length)], ['App-versie', (this.homey.manifest ? this.homey.manifest.version : '-') + (this.newAppVersion ? ' (nieuw: ' + this.newAppVersion + ')' : '')],
      ].concat(this.connRows()) },
      { t: 'Dashboard', rows: [
        ['Standaardpagina', s.dashboardTheme || 'zon'], ['Pagina\'s', ((this.dashboard && this.dashboard.beeldPages) ? this.dashboard.beeldPages().length : String(s.dashboardPages || '').split(',').filter((x) => x.trim()).length) + ' pagina\'s'],
        ['Licht of donker', s.dashboardMode || 'auto'], ['Dimmen bij zonsondergang', yn(s.dashboardNight !== false)], ['Poort', String(s.dashboardPort || 8765)],
      ] },
    ];
  },

  usageNow() {
    const today = this.todayString();
    const ht = this.homeyToday && this.homeyToday.date === today && Date.now() - (this.homeyTodayAt || 0) < 20 * 60 * 1000 ? this.homeyToday : null;
    const all = history.addDay(this.history || [], this.dayEntry(this.stats.data())).map((h) => (ht && h.date === today ? Object.assign({}, h, { useKwh: ht.use, selfKwh: ht.self }) : h));
    return usageLib.summary(all, today, this.homeyMonths || this.getStoreValue('homeyMonths') || {});
  },

  /**
   * Kijkt wat Homey Energie zelf voor vandaag meldt, zodat we het met de eigen berekening kunnen vergelijken.
   * Homey beschrijft de velden van dit rapport niet, daarom zoekt dit naar getallen met verbruik in de naam en toont het begin van het rapport.
   */
  async homeyEnergyCheck() {
    const api = await this.getAppApi();
    if (!api.energy || typeof api.energy.getReportDay !== 'function') throw new Error('Deze Homey geeft geen energierapport door.');
    const date = this.todayString();
    const rep = await api.energy.getReportDay({ date });
    const found = [];
    const walk = (o, path, depth) => {
      if (found.length >= 8 || depth > 4 || o === null || typeof o !== 'object') return;
      for (const k of Object.keys(o)) {
        const v = o[k];
        if (typeof v === 'number' && /consum|usage|used|import|total|generat|produc|export/i.test(k)) found.push(path + k + '=' + Math.round(v * 1000) / 1000);
        else if (v && typeof v === 'object') walk(v, path + k + '.', depth + 1);
      }
    };
    walk(rep, '', 0);
    const own = usageLib.summary(history.addDay(this.history || [], this.dayEntry(this.stats.data())), date);
    const mine = own.ready ? 'Mijn berekening vandaag: ' + own.today.use + ' kWh verbruik (' + own.today.self + ' eigen zon, ' + own.today.grid + ' net). ' : '';
    const text = mine + (found.length ? 'Homey Energie meldt: ' + found.join(', ') + '. ' : 'Geen getallen met verbruik in het rapport gevonden. ') + 'Begin van het rapport: ' + JSON.stringify(rep).slice(0, 300);
    this.logEvent('Homey Energie: ' + (found.length ? found.slice(0, 3).join(', ') : 'geen verbruiksvelden'));
    return text;
  },

  /** Testmelding: laat zien of meldingen op je telefoon aankomen (negeert de vakantiestand). */
  async testNotification() {
    await this.sendNotification('Solis: dit is een testmelding. Zie je dit op je telefoon, dan werken meldingen.');
    this.logEvent('Testmelding verstuurd.');
    return 'Testmelding verstuurd naar de tijdlijn van Homey. Komt hij niet als pushmelding binnen, maak dan een flow met de kaart Solis melding (zie de handleiding).';
  },

  // ---------- apparaten die leren ----------
  learnCycle(name, r, mins) {
    const tz = this.homey.clock.getTimezone();
    const data = learnLib.addCycle(this.getStoreValue('appLearn') || {}, name, { t: r.since, min: mins, kwh: r.wh / 1000, avgW: mins > 0 ? (r.wh * 60) / mins : 0, peakW: r.peak, hour: zoned(r.since, tz).h });
    this.setStoreValue('appLearn', data).catch(this.error);
    const p = learnLib.profile(name, data[name]);
    if (p && p.cycles === 3) this.logEvent('Geleerd: ' + p.text + '.');
  },

  learnInfo() { return learnLib.summary(this.getStoreValue('appLearn') || {}).map((p) => ({ name: p.name, cycles: p.cycles, ready: p.ready, programs: p.programs, typical: p.typical, usualHour: p.usualHour })); },

  /** Zodra het beste startmoment van een geplande taak begint: flow-trigger "Beste moment". */
  checkBestMoment() {
    const now = Date.now();
    this.planFired = this.planFired || {};
    for (const p of this.planResult || []) {
      if (now < p.from || now >= p.to) continue;
      const key = p.name + '|' + p.from;
      if (this.planFired[key]) continue;
      this.planFired[key] = now;
      this.logEvent('Beste moment voor ' + p.name + ' is nu.');
      this.homey.flow.getDeviceTriggerCard('best_moment').trigger(this, { apparaat: p.name, uren: p.hours, kosten: p.cost }, {}).catch(this.error);
    }
    for (const k of Object.keys(this.planFired)) if (now - this.planFired[k] > 48 * 3600000) delete this.planFired[k];
  },

  // ---------- bespaarlogboek negatieve prijzen ----------
  trackNegSaving(price, eff) {
    const now = Date.now();
    const last = this.negAt || now;
    this.negAt = now;
    if (price === null || price >= 0 || (eff !== 'geen-export' && eff !== 'uit')) return;
    const dt = Math.min(now - last, 120000);
    const pot = this.potentialNowW();
    const w = Math.max(0, typeof pot === 'number' ? pot : (this.pvW || 0));
    const wh = (w * dt) / 3600000;
    const m = this.todayString().slice(0, 7);
    const all = this.negSaved || (this.negSaved = this.getStoreValue('negSaved') || {});
    const e = all[m] || (all[m] = { wh: 0, eur: 0 });
    e.wh += wh; e.eur += (wh / 1000) * Math.abs(price);
    if (now - (this.negSavedAt || 0) > 10 * 60000) { this.negSavedAt = now; this.setStoreValue('negSaved', all).catch(this.error); }
  },

  negSavedInfo() {
    const all = this.negSaved || this.getStoreValue('negSaved') || {};
    const today = this.todayString();
    const m = all[today.slice(0, 7)] || { wh: 0, eur: 0 };
    const y = Object.keys(all).filter((k) => k.startsWith(today.slice(0, 4))).reduce((a, k) => a + all[k].eur, 0);
    return { monthKwh: Math.round(m.wh / 10) / 100, monthEur: Math.round(m.eur * 100) / 100, yearEur: Math.round(y * 100) / 100 };
  },

  // ---------- vakantie: samenvatting als je terug bent ----------
  async checkVacationEnd() {
    const since = this.getStoreValue('vacationSince');
    const on = this.vacationOn();
    const today = this.todayString();
    if (on) { if (!since) await this.setStoreValue('vacationSince', today).catch(this.error); return; }
    if (!since) return;
    await this.setStoreValue('vacationSince', null).catch(this.error);
    const sumLib = require('../../lib/vacationsum'); // eslint-disable-line global-require
    const startMs = Date.parse(since + 'T00:00:00Z') - 14 * 3600 * 1000;
    const r = sumLib.summarize(this.history || [], since, today, this.events || [], startMs);
    if (!r) return;
    this.logEvent('Vakantiesamenvatting verstuurd.');
    try { await this.sendNotification('Solis: ' + i18n.tr(r.text)); } catch (e) { this.error(e.message); }
    try { await this.homey.flow.getDeviceTriggerCard('vacation_summary').trigger(this, { text: i18n.tr(r.text) }); } catch (e) { this.error(e.message); }
  },

  panelHealth() { return healthLib.panels(this.history || [], Number(this.getSettings().kWp) || 2.5); },

  // ---------- vuil paneel ----------
  checkSoiling() {
    const r = history.soilingCheck(this.history || []);
    if (!r) return;
    const last = this.getStoreValue('lastSoilingNote') || 0;
    if (r.drop >= 0.2 && Date.now() - last > 14 * 24 * 3600 * 1000) {
      this.setStoreValue('lastSoilingNote', Date.now()).catch(this.error);
      const pct = Math.round(r.drop * 100);
      this.logEvent('Opbrengst op zonnige dagen ' + pct + '% lager dan eerder.');
      this.notify('soiling', 'de opbrengst op zonnige dagen is ongeveer ' + pct + '% lager dan de weken ervoor. Controleer of de panelen vuil zijn, beschaduwd worden (bladeren, sneeuw) of dat er iets stuk is.');
    }
  },

  dayEntry(d) {
    return {
      date: d.date,
      kwh: Math.round(d.todayKwh * 100) / 100,
      exportWh: Math.round(d.exportWh),
      blockedWh: Math.round(d.blockedWh),
      saved: Math.round(d.saved * 1000) / 1000,
      limitedMs: d.ms['geen-export'],
      offMs: d.ms.uit,
      peakW: Math.round(d.peakW),
      radMJ: d.radMJ || 0,
      importWh: Math.round(d.importWh || 0),
      importCost: Math.round((d.importCost || 0) * 1000) / 1000,
      exportRev: Math.round((d.exportRev || 0) * 1000) / 1000,
      valueSelf: Math.round((d.valueSelf || 0) * 1000) / 1000,
      valueExport: Math.round((d.valueExport || 0) * 1000) / 1000,
      hourWh: Object.keys(d.hourWh || {}).reduce((o, h) => { o[h] = Math.round(d.hourWh[h]); return o; }, {}),
      vMax: Math.round((d.vMax || 0) * 10) / 10,
      vHighMin: Math.round((d.vHighMs || 0) / 60000),
      vTopMin: Math.round((d.vTopMs || 0) / 60000),
      houseWh: Object.keys(d.hourHouse || {}).reduce((o, h) => { o[h] = Math.round(d.hourHouse[h]); return o; }, {}),
      apps: Object.keys(d.apps || {}).reduce((o, n) => { o[n] = { wh: Math.round(d.apps[n].wh), cost: Math.round(d.apps[n].cost * 1000) / 1000 }; return o; }, {}),
    };
  },

  summary() {
    const today = this.todayString();
    return history.summary(this.history || [], today, this.dayEntry(this.stats.data()));
  },

  async updateSummaryCaps(inverterMonthKwh) {
    const sm = this.summary();
    await this.setCapabilityValue('inverter_year', Math.round(sm.yearKwh)).catch(this.error);
    if (sm.monthImportCost > 0.004 || sm.monthExportRev > 0.004) await this.setCapabilityValue('inverter_cost_month', Math.round((sm.monthImportCost - sm.monthExportRev) * 100) / 100).catch(this.error);
    const pct = history.selfUsePct(sm.monthKwh, sm.monthExportWh);
    if (pct !== null) await this.setCapabilityValue('inverter_selfuse_month', pct).catch(this.error);
    await this.setCapabilityValue('inverter_yesterday', Math.round(sm.yesterdayKwh * 10) / 10).catch(this.error);
    await this.setCapabilityValue('inverter_week', Math.round(sm.weekKwh * 10) / 10).catch(this.error);
    await this.setCapabilityValue('inverter_saving_month', Math.round(sm.monthSaved * 100) / 100).catch(this.error);
    if (typeof inverterMonthKwh === 'number') await this.setCapabilityValue('inverter_month', inverterMonthKwh).catch(this.error);
  },

  // ---------- verwachting en potentieel ----------
  learnedFactor() {
    return forecast.learnFactor((this.history || []).filter((h) => h.radMJ > 0));
  },

  potentialNowW() {
    if (!this.forecastData) return null;
    const tz = this.homey.clock.getTimezone();
    const z = zoned(Date.now(), tz);
    const key = z.date + 'T' + String(z.h).padStart(2, '0') + ':00';
    const rad = this.forecastData.hourly[key];
    if (typeof rad !== 'number') return null;
    const s = this.getSettings();
    return forecast.potentialW(rad, this.learnedFactor(), Number(s.kWp) || 2.5, s.maxPower || 2500);
  },

  // ---------- externe gegevens: prijzen van morgen en weer ----------
  async refreshExternal() {
    this.checkAppUpdate().catch(() => {});
    try { await this.refreshExternalInner(); } finally { this.refreshPlan(); }
  },

  /** Kijkt hooguit eens per 6 uur op GitHub of er een nieuwere versie van deze app is, en meldt dat één keer per versie. */
  async checkAppUpdate() {
    const now = Date.now();
    if (this.updateCheckedAt && now - this.updateCheckedAt < 6 * 3600 * 1000) return;
    this.updateCheckedAt = now;
    const fetchJson = this.fetchJson || getJson;
    const info = await fetchJson('https://raw.githubusercontent.com/djdirty60/Solis-Kodi/main/tv-apps/versie.json?t=' + now, 10000);
    const h = info && info.homey;
    const cur = this.homey.manifest ? this.homey.manifest.version : '0';
    if (!h || !h.version || !versionNewer(h.version, cur)) { this.newAppVersion = null; return; }
    this.newAppVersion = h.version;
    if (this.getStoreValue('updateNotified') !== h.version) {
      await this.setStoreValue('updateNotified', h.version).catch(this.error);
      this.logEvent('Nieuwe versie ' + h.version + ' staat op GitHub.');
      this.notify('update', 'versie ' + h.version + ' staat op GitHub (je hebt ' + cur + '). ' + (h.nieuw ? h.nieuw + ' ' : '') + 'Installeren: zie homey-app/LEES-MIJ.txt in de Solis-Kodi repo.');
    }
  },

  async refreshExternalInner() {
    const s = this.getSettings();
    if (s.basicMode === true) return; // alleen de basis: geen prijzen, weer of verwachting ophalen
    const tz = this.homey.clock.getTimezone();
    const today = this.todayString();
    const fetchJson = this.fetchJson || getJson;
    const kWp = Number(s.kWp) || 2.5;

    // weer
    if (Date.now() - (this.forecastAt || 0) > FORECAST_EVERY_MS) {
      try {
        const lat = this.homey.geolocation.getLatitude();
        const lon = this.homey.geolocation.getLongitude();
        if (Number.isFinite(lat) && Number.isFinite(lon)) {
          const pf = forecast.parseOpenMeteo(await fetchJson(forecast.forecastUrl(lat, lon, tz)));
          this.forecastData = pf;
          this.forecastAt = Date.now();
          const factor = this.learnedFactor();
          const tomorrowRad = pf.daily[addDays(today, 1)];
          const todayRad = pf.daily[today];
          if (typeof todayRad === 'number') this.stats.data().radMJ = todayRad;
          if (typeof tomorrowRad === 'number') {
            const tk = forecast.estimateKwh(tomorrowRad, factor, kWp);
            const tdk = typeof todayRad === 'number' ? forecast.estimateKwh(todayRad, factor, kWp) : 0;
            await this.setCapabilityValue('inverter_forecast', Math.round(tk * 10) / 10).catch(this.error);
            this.forecastTextValue = forecast.forecastText(tk, tdk);
          }
        } else if (!this.geoLogged) {
          this.geoLogged = true;
          this.logEvent('Weer: locatie van Homey onbekend of niet toegestaan.');
        }
      } catch (e) {
        this.error('Weer ophalen mislukt:', e.message);
        if (!this.forecastErrLogged) { this.forecastErrLogged = true; this.logEvent('Weer ophalen mislukt: ' + e.message); }
      }
    }

    // prijzen
    const contract = this.currentContract();
    if (contract !== 'dynamisch') {
      await this.fetchChartPrices(today, tz).catch((e) => this.error('Prijzen (grafiek):', e.message));
      const w = s.windowEnabled ? 'Geen export van ' + s.windowFrom + ' tot ' + s.windowTo + '.' : 'Vast contract: geen sturing op de prijs.';
      await this.setCapabilityValue('inverter_plan_today', w).catch(this.error);
      await this.setCapabilityValue('inverter_plan_tomorrow', 'Vast contract: geen sturing op de prijs.').catch(this.error);
      return;
    }
    if (s.fetchPrices === false) return;
    const opts = {
      fixedCosts: Number(s.fixedCosts) || 0, uitBelow: s.uitBelow, geenExportBelow: s.geenExportBelow, tz,
    };
    const m = zoned(Date.now(), tz);
    const wantTomorrow = m.h * 60 + m.m >= 13 * 60 + 30;
    try {
      if (!this.todayPrices || this.todayPrices.date !== today) {
        const e = prices.parseEnergyZero(await fetchJson(prices.energyZeroUrl(today, tz)));
        this.todayPrices = { date: today, entries: e };
      }
      const a = prices.analyse(this.todayPrices.entries, opts);
      await this.setCapabilityValue('inverter_plan_today', a ? a.text : 'Prijzen van vandaag nog niet beschikbaar.').catch(this.error);
      const tom = addDays(today, 1);
      if (wantTomorrow && (!this.tomorrowPrices || this.tomorrowPrices.date !== tom)) {
        const e = prices.parseEnergyZero(await fetchJson(prices.energyZeroUrl(tom, tz)));
        if (e.length >= 20) this.tomorrowPrices = { date: tom, entries: e, announced: false };
      }
      if (this.tomorrowPrices && this.tomorrowPrices.date === tom) {
        const b = prices.analyse(this.tomorrowPrices.entries, opts);
        await this.setCapabilityValue('inverter_plan_tomorrow', b.text).catch(this.error);
        const bh = prices.bestHour(this.tomorrowPrices.entries, this.forecastData && this.forecastData.hourly, opts);
        if (bh) {
          await this.setCapabilityValue('inverter_best_hour', bh.text.slice(0, 120)).catch(this.error);
          this.bestInfo = {
            best: bh.best ? hhmm(bh.best.t, tz) : null,
            cheapest: hhmm(bh.cheapest.t, tz) + ' (' + prices.eur(bh.cheapest.total) + ')',
          };
        }
        if (!this.tomorrowPrices.announced) {
          this.tomorrowPrices.announced = true;
          this.logEvent('Prijzen van morgen binnen.');
          const pm = planner.planText((this.planResult || []).filter((p) => p.day === 'morgen'), tz);
          this.notify('plan', 'prijzen van morgen: ' + b.text + (pm ? ' Plan voor morgen: ' + pm : ''));
          this.homey.flow.getDeviceTriggerCard('prices_ready').trigger(this, {
            text: b.text,
            min_price: Math.round(b.min.total * 1000) / 1000,
            max_price: Math.round(b.max.total * 1000) / 1000,
            avg_price: Math.round(b.avg * 1000) / 1000,
            limited: b.limitedRanges.join(', '),
            off: b.offRanges.join(', '),
            best: bh ? bh.text : '',
          }).catch(this.error);
        }
      } else {
        await this.setCapabilityValue('inverter_plan_tomorrow', 'Prijzen van morgen komen na ongeveer 14:00.').catch(this.error);
      }
      this.priceErrLogged = false;
      const op = this.ownPrice();
      if (op !== null && this.priceSourceText().startsWith('zelf')) await this.setCapabilityValue('inverter_price', op).catch(this.error);
    } catch (e) {
      this.error('Prijzen ophalen mislukt:', e.message);
      if (!this.priceErrLogged) { this.priceErrLogged = true; this.logEvent('Prijzen ophalen mislukt: ' + e.message); }
    }
  },

  /** Bij een vast contract halen we de uurprijzen alleen op voor de grafiek in het dashboard. */
  async fetchChartPrices(today, tz) {
    if (this.getSettings().fetchPrices === false) return;
    const fetchJson = this.fetchJson || getJson;
    if (!this.todayPrices || this.todayPrices.date !== today) {
      const e = prices.parseEnergyZero(await fetchJson(prices.energyZeroUrl(today, tz)));
      if (e.length) this.todayPrices = { date: today, entries: e };
    }
    const m = zoned(Date.now(), tz);
    const tom = addDays(today, 1);
    if (m.h * 60 + m.m >= 13 * 60 + 30 && (!this.tomorrowPrices || this.tomorrowPrices.date !== tom)) {
      const e = prices.parseEnergyZero(await fetchJson(prices.energyZeroUrl(tom, tz)));
      if (e.length >= 20) this.tomorrowPrices = { date: tom, entries: e, announced: true };
    }
  },

  /** Uurprijzen voor het dashboard: { today:[{h,p}], tomorrow:[{h,p}] } (euro per kWh, incl. vaste kosten). */
  priceSeries() {
    const tz = this.homey.clock.getTimezone();
    const add = Number(this.getSettings().fixedCosts) || 0;
    const mk = (l) => (l && l.entries ? l.entries.map((e) => ({ h: zoned(e.t, tz).h, p: Math.round((e.price + add) * 10000) / 10000 })) : null);
    return { today: mk(this.todayPrices), tomorrow: mk(this.tomorrowPrices) };
  },

  // ---------- eigen prijs (als de flow geen prijs doorgeeft) ----------
  ownPrice() {
    const st = this.getSettings();
    if (this.currentContract() !== 'dynamisch' || st.fetchPrices === false) return null;
    const list = [this.todayPrices, this.tomorrowPrices].filter(Boolean);
    const now = Date.now();
    for (const l of list) {
      const e = l.entries.find((x) => now >= x.t && now < x.t + 3600000);
      if (e) return Math.round((e.price + (Number(st.fixedCosts) || 0)) * 10000) / 10000;
    }
    return null;
  },

  rollPrices(today) {
    if (this.tomorrowPrices && this.tomorrowPrices.date === today) this.todayPrices = this.tomorrowPrices;
    else if (this.todayPrices && this.todayPrices.date !== today) this.todayPrices = null;
    this.tomorrowPrices = null;
    this.refreshExternal().catch(this.error);
  },

  priceSourceText() {
    if (this.price !== null && this.priceAt && Date.now() - this.priceAt <= 3 * 3600000) return 'flow "Geef prijs door"';
    return this.ownPrice() !== null ? 'zelf opgehaald (EnergyZero)' : 'geen';
  },

  // ---------- zelftest ----------
  async selfTest() {
    const s = this.getSettings();
    const ago = (t) => (t ? Math.round((Date.now() - t) / 60000) + ' min geleden' : 'nooit');
    const parts = [];
    parts.push('Verbinding: ' + (this.online === true ? 'ok' : this.online === false ? 'NIET bereikbaar' : 'nog onbekend') + '.');
    parts.push('Contract: ' + this.currentContract() + '.');
    const pr = this.freshPrice();
    parts.push('Prijs: ' + (pr === null ? 'geen' : nl(pr, 3) + ' (bron: ' + this.priceSourceText() + ')') + '.');
    parts.push('P1-koppeling: ' + (this.p1Status || 'uit') + '.');
    parts.push('Netvermogen: ' + (this.netAt ? ago(this.netAt) : 'nog niet ontvangen (flow "Geef netvermogen door")') + '.');
    parts.push('Weer: ' + (this.forecastAt ? 'ok, ' + ago(this.forecastAt) : 'nog niet opgehaald') + '.');
    if (this.currentContract() === 'dynamisch') {
      parts.push('Prijzen vandaag: ' + (this.todayPrices ? 'ok' : 'niet opgehaald') + ', morgen: ' + (this.tomorrowPrices ? 'ok' : 'nog niet') + '.');
    }
    parts.push('Schrijven: ' + (s.allowWrite ? 'aan' : 'uit') + '.');
    const text = parts.join(' ');
    this.logEvent('Zelftest uitgevoerd.');
    try { await this.sendNotification('Solis zelftest: ' + text); } catch (e) { this.error(e.message); }
    return text;
  },

  // ---------- foutenrapport en installatiecontrole (voor testers) ----------
  /** Onthoudt de laatste fouten bij het uitlezen van de omvormer (alleen in het geheugen, max 10). */
  noteModbusError(msg) {
    this.recentErrors = (this.recentErrors || []).concat([{ t: Date.now(), text: String(msg || '') }]).slice(-10);
  },

  /** Platte tekst zonder persoonlijke gegevens, om te delen met de maker van de app. */
  async bugReport() {
    const s = this.getSettings();
    let version = '';
    try { version = this.homey.manifest.version; } catch (e) { version = ''; }
    let model;
    if (this.modelCache !== undefined) model = this.modelCache;
    else if (this.online === true && this.inv && typeof this.inv.readModel === 'function') {
      try { model = await this.inv.readModel(); this.modelCache = model; } catch (e) { model = undefined; }
    }
    let desc = null;
    try { desc = brands.describe(s.inverterBrand || 'solis', { model }); } catch (e) { desc = null; }
    const modelText = model === undefined || model === null ? undefined : '0x' + Number(model).toString(16).toUpperCase();
    const text = bugLib.build({
      version,
      driver: { brand: desc ? desc.name : String(s.inverterBrand || ''), model: modelText, serial: s.soliscloudSn || undefined, datalogger: desc ? desc.protocol : undefined },
      settings: s,
      errors: this.recentErrors || [],
      log: this.eventLines(20),
      diag: this.connRows(),
      now: Date.now(),
      tr: i18n.tr,
    });
    this.logEvent('Foutenrapport gemaakt.');
    return { text };
  },

  /** "Controleer mijn installatie": gebruikt de gegevens die de app al heeft, plus één kleine test van de omvormer. */
  async runDoctor() {
    const s = this.getSettings();
    const checks = [];
    // omvormer
    if (this.online === true) checks.push({ id: 'inverter', status: 'ok' });
    else if (this.sleeping) checks.push({ id: 'inverter', status: 'oversla', detail: i18n.tr('omvormer slaapt, te weinig zon') });
    else {
      try { await this.inv.readModel(); checks.push({ id: 'inverter', status: 'ok' }); } catch (e) { checks.push({ id: 'inverter', status: 'fout', detail: e.message }); }
    }
    // P1
    const p1s = String(this.p1Status || '');
    if (s.p1Enabled === false || p1s === 'uit' || !p1s) checks.push({ id: 'p1', status: 'oversla', detail: i18n.tr('uitgezet') });
    else if (p1s.indexOf('actief') === 0) checks.push({ id: 'p1', status: 'ok' });
    else checks.push({ id: 'p1', status: 'fout', detail: p1s });
    // prijzen
    if (this.currentContract() !== 'dynamisch' || s.fetchPrices === false) checks.push({ id: 'prices', status: 'oversla', detail: i18n.tr('niet nodig') });
    else checks.push({ id: 'prices', status: this.todayPrices ? 'ok' : 'fout' });
    // weer
    checks.push({ id: 'weather', status: this.forecastAt ? 'ok' : 'fout' });
    // dashboard
    if (s.dashboardEnabled === false) checks.push({ id: 'dashboard', status: 'oversla', detail: i18n.tr('uitgezet') });
    else {
      const up = !!(this.dashboard && this.dashboard.server && this.dashboard.server.listening !== false);
      checks.push({ id: 'dashboard', status: up ? 'ok' : 'fout', detail: up ? i18n.tr('poort') + ' ' + this.dashboard.port : undefined });
    }
    // SolisCloud: alleen als ingevuld
    const cfg = { keyId: String(s.soliscloudKeyId || '').trim(), secret: String(s.soliscloudSecret || '').trim(), sn: String(s.soliscloudSn || '').trim() };
    if (!cfg.keyId || !cfg.secret) checks.push({ id: 'soliscloud', status: 'oversla', detail: i18n.tr('niet ingevuld') });
    else {
      try {
        const day = addDays(this.todayString(), -1);
        await solisCloud.fetchDays(cfg, day, day, this.postJson || postJson);
        checks.push({ id: 'soliscloud', status: 'ok' });
      } catch (e) { checks.push({ id: 'soliscloud', status: 'fout', detail: bugLib.scrub(e.message, [cfg.keyId, cfg.secret, cfg.sn]) }); }
    }
    this.logEvent('Installatiecontrole uitgevoerd.');
    return doctorLib.summarize(checks, { tr: i18n.tr });
  },

  /**
   * Goed moment om apparaten te starten:
   * - er is minstens X watt overschot, of
   * - de app begrenst/zet de omvormer uit (opwek gaat verloren), of
   * - de prijs is negatief.
   */
  goodReason(watts) {
    const sur = Number(this.getCapabilityValue('inverter_surplus')) || 0;
    if (sur >= (Number.isFinite(watts) ? watts : 300)) return 'overschot';
    if (this.lastEffective === 'geen-export' || this.lastEffective === 'uit') return 'opwek gaat verloren';
    const p = this.freshPrice();
    if (p !== null && p < 0) return 'negatieve prijs';
    return null;
  },

  goodMoment(watts) {
    return this.goodReason(watts) !== null;
  },

  /** Meldt één keer als er een goed moment begint (en niet vaker dan eens per 30 minuten). */
  checkGoodMoment() {
    const s = this.getSettings();
    const reason = this.goodReason(Number(s.goodMomentWatts) || 300);
    if (reason && !this.goodMomentOn && Date.now() - (this.lastGoodAt || 0) > 30 * 60 * 1000) {
      this.lastGoodAt = Date.now();
      this.logEvent('Goed moment: ' + reason);
      let fit = '';
      if (reason === 'overschot') {
        const sur = Number(this.getCapabilityValue('inverter_surplus')) || 0;
        const names = (this.learnInfo() || []).filter((p) => p.ready && p.typical && p.typical.watts <= sur + 200).map((p) => p.name);
        fit = ' Je levert nu ' + Math.round(sur).toLocaleString(i18n.loc()) + ' W terug' + (names.length ? ', genoeg voor: ' + names.slice(0, 3).join(', ') : '') + '.';
      }
      this.notify('goodmoment', 'goed moment om apparaten te starten (' + reason + ').' + fit);
      this.homey.flow.getDeviceTriggerCard('good_moment_started').trigger(this, {
        reason, surplus: Number(this.getCapabilityValue('inverter_surplus')) || 0,
      }).catch(this.error);
    }
    if (this.goodMomentOn && reason === null) {
      this.homey.flow.getDeviceTriggerCard('good_moment_ended').trigger(this, {}).catch(this.error);
    }
    this.goodMomentOn = reason !== null;
  },

  async showMonth() {
    const sm = this.summary();
    const text = history.monthText(sm) + ' ' + history.paybackText(sm, Number(this.getSettings().purchasePrice) || 0);
    this.logEvent('Maandoverzicht getoond.');
    try { await this.sendNotification('Solis maandoverzicht: ' + text); } catch (e) { this.error(e.message); }
    return text;
  },

  /** Verwachte opbrengst (kWh) voor vandaag (+i dagen), of null. */
  forecastFor(i) {
    if (!this.forecastData) return null;
    const date = addDays(this.todayString(), i);
    const rad = this.forecastData.daily[date];
    if (typeof rad !== 'number') return null;
    return Math.round(forecast.estimateKwh(rad, this.learnedFactor(), Number(this.getSettings().kWp) || 2.5) * 10) / 10;
  },

  forecastDay(i) {
    const date = addDays(this.todayString(), i);
    const codes = (this.forecastData && this.forecastData.codes) || {};
    return { date, kwh: this.forecastFor(i), code: typeof codes[date] === 'number' ? codes[date] : null };
  },

  days14() {
    const all = history.addDay(this.history || [], this.dayEntry(this.stats.data()));
    return all.slice(-14).map((h) => ({ date: h.date, kwh: Math.round((Number(h.kwh) || 0) * 10) / 10 }));
  },

  paybackInfo(sm) {
    const price = Number(this.getSettings().purchasePrice) || 0;
    return paybackLib.compute(price, this.history || [], sm.totalValue, sm.valueDays);
  },

  /** Uur van morgen met de meeste verwachte zon. */
  sunnyTomorrow() {
    if (!this.forecastData) return null;
    const tom = addDays(this.todayString(), 1);
    let best = null;
    for (const k of Object.keys(this.forecastData.hourly)) {
      if (!k.startsWith(tom)) continue;
      const w = this.forecastData.hourly[k];
      if (!best || w > best.w) best = { h: Number(k.slice(11, 13)), w: Math.round(w) };
    }
    return best;
  },

  vacationOn() {
    const s = this.getSettings();
    if (s.vacationMode !== true) return false;
    const u = parseDate(s.vacationUntil);
    if (u && this.todayString() > u) return false;
    return true;
  },

  async setVacation(on) {
    const cfg = Object.assign({}, this.homey.settings.get('cfg') || {}, { vacationMode: !!on });
    this.homey.settings.set('cfg', cfg);
    if (on && !this.getStoreValue('vacationSince')) await this.setStoreValue('vacationSince', this.todayString()).catch(this.error);
    this.logEvent('Vakantiestand ' + (on ? 'aan' : 'uit') + '.');
  },

  /** Onthoudt de laatste meldingen, zodat de Kodi-add-on ze op de tv kan tonen (/meldingen.json). */
  pushFeed(text) {
    let t = String(text || '').trim();
    if (!t || /^Solis logboek:/i.test(t)) return;
    let title = 'Solis';
    const m = /^Solis (dagrapport|weekrapport|maandrapport):\s*/i.exec(t);
    if (m) { title = m[1][0].toUpperCase() + m[1].slice(1).toLowerCase(); t = t.slice(m[0].length); } else t = t.replace(/^Solis:\s*/i, '');
    if (t.length > 230) { const cut = t.slice(0, 230); const i = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf(' ')); t = (i > 80 ? cut.slice(0, i) : cut).replace(/[ ,.;:]+$/, '') + '…'; }
    const kind = /storing|niet bereikbaar|offline|temperatuur|netspanning|geen opbrengst|geen prijs|mislukt|let op/i.test(t) ? 'warn' : /goed moment|doel gehaald|negatief|goedkoop|record|klaar/i.test(t) ? 'good' : 'info';
    const feed = (this.getStoreValue('feed') || []).slice(-29);
    const last = feed.length ? feed[feed.length - 1].id : 0;
    feed.push({ id: Math.max(Date.now(), last + 1), at: Date.now(), title: i18n.tr(title), text: i18n.tr(t.charAt(0).toUpperCase() + t.slice(1)), kind });
    this.setStoreValue('feed', feed).catch(this.error);
  },

  feedSince(since) {
    const feed = this.getStoreValue('feed') || [];
    const sid = Number(since);
    const items = Number.isFinite(sid) && since !== undefined && since !== null && since !== '' ? feed.filter((x) => x.id > sid) : feed;
    return { now: Date.now(), last: feed.length ? feed[feed.length - 1].id : 0, items: items.slice(-30) };
  },

  notifyText(text) {
    if (this.vacationOn() || this.getSettings().basicMode === true) return Promise.resolve();
    return this.sendNotification('Solis: ' + text).catch((e) => this.error(e.message));
  },

  /** Bijzondere momenten: nieuw record, eerste negatieve prijs van het jaar. */
  checkSpecials(todayKwh, price) {
    const s = this.getSettings();
    if (s.notifyRecord === false) return;
    const today = this.todayString();
    const hist = this.history || [];
    if (hist.length >= 7 && todayKwh > 0 && this.getStoreValue('recordNote') !== today) {
      const best = history.records(hist.filter((h) => h.date !== today)).bestDay;
      if (best && todayKwh > best.kwh + 0.05) {
        this.setStoreValue('recordNote', today).catch(this.error);
        this.logEvent('Nieuw record: ' + todayKwh + ' kWh.');
        this.notifyText('Nieuw record! Vandaag al ' + String(Math.round(todayKwh * 10) / 10).replace('.', ',') + ' kWh, meer dan je beste dag (' + String(best.kwh).replace('.', ',') + ' kWh op ' + best.date + ').');
      }
    }
    if (typeof price === 'number' && price < 0) {
      const year = today.slice(0, 4);
      if (this.getStoreValue('negYear') !== year) {
        this.setStoreValue('negYear', year).catch(this.error);
        this.notifyText('Eerste negatieve stroomprijs van dit jaar: ' + String(price.toFixed(3)).replace('.', ',') + ' euro per kWh.');
      }
    }
  },

  /** Een afgeronde beurt leren (duur tot het laatste moment van hoog verbruik). */
  finishCycle(n, r) {
    r.pending = false;
    const mins = r.mins || 0;
    if (mins >= 8 && r.wh >= 20) this.learnCycle(n, r, mins);
  },

  /** Apparaat klaar: vermogen was een tijd hoog en blijft nu laag. */
  checkApplianceDone(out) {
    const s = this.getSettings();
    this.appRun = this.appRun || {};
    const now = Date.now();
    for (const n of Object.keys(out)) {
      const w = out[n];
      const r = this.appRun[n] || (this.appRun[n] = { on: false, since: 0, low: 0, wh: 0, last: now, peak: 0 });
      // Een vaatwasser staat tijdens het drogen lang op een paar watt; pas na 20 minuten laag is hij echt klaar.
      // Andere apparaten (wasmachine) na 5 minuten laag.
      const cls = (this.appClass || {})[n] || '';
      const dish = cls === 'dishwasher' || /vaat|dish/i.test(n);
      const endTicks = dish ? 60 : 15;
      if (w >= 15) {
        if (!r.on && r.pending && now - r.endedAt < 30 * 60000) {
          // stroom komt binnen 30 minuten terug: dat is nog dezelfde beurt (bijvoorbeeld weken of naspoelen)
          r.on = true; r.pending = false;
        } else if (!r.on) {
          if (r.pending) this.finishCycle(n, r, s); // vorige beurt eerst afronden
          r.on = true; r.since = now; r.wh = 0; r.peak = 0; r.m0 = (this.appMeter || {})[n]; r.notified = false;
        }
        r.wh += (w * (now - r.last)) / 3600000;
        if (w > r.peak) r.peak = w;
        r.low = 0;
        r.lastHigh = now;
      } else if (r.on) {
        r.low++;
        if (r.low >= endTicks) {
          r.on = false;
          r.endedAt = now;
          r.mins = Math.round(((r.lastHigh || now) - r.since) / 60000); // tot het laatste moment van verbruik, zonder de wachttijd
          // liever de kWh-teller van de stekker dan het opgetelde vermogen (dat mist stukken als de app herstartte)
          const m1 = (this.appMeter || {})[n];
          if (typeof r.m0 === 'number' && typeof m1 === 'number') { const mwh = (m1 - r.m0) * 1000; if (mwh > 0 && mwh < 20000) r.wh = mwh; }
          if (r.mins >= 8 && !r.notified && s.notifyApplianceDone !== false) r.notified = true, this.notifyText(n + ' is klaar (' + r.mins + ' min, ' + String(Math.round(r.wh / 10) / 100).replace('.', ',') + ' kWh).');
          r.pending = true; // pas leren als hij 30 minuten uit blijft, anders telt een pauze als twee beurten
        }
      } else if (r.pending && now - r.endedAt >= 30 * 60000) {
        this.finishCycle(n, r, s);
      }
      r.last = now;
    }
    // lopende beurten eens per minuut bewaren, zodat een herstart of update van de app tijdens het wassen de beurt niet wist
    if (now - (this.appRunSavedAt || 0) > 60000) { this.appRunSavedAt = now; this.setStoreValue('appRun', this.appRun).catch(this.error); }
    if (s.notifyApplianceLong !== false) {
      try {
        const typ = {};
        for (const p of learnLib.summary(this.getStoreValue('appLearn') || {})) if (p.ready && p.typical) typ[p.name] = p.typical.min;
        for (const o of standby.overdue(this.appRun, typ, now)) {
          const t = standby.text(o);
          this.logEvent('Apparaat lang aan: ' + o.name + ' (' + o.mins + ' min)');
          this.notify('applianceLong', t);
        }
      } catch (e) { this.error('Controle apparaat te lang aan mislukt:', e.message); }
    }
  },

  /** Terugblik op een dag (standaard gisteren). */
  dayReview(dateStr) {
    const today = this.todayString();
    const d = String(dateStr || '').trim().toLowerCase();
    const date = !d || d === 'gisteren' ? addDays(today, -1) : d === 'vandaag' ? today : d;
    const entry = date === today ? this.dayEntry(this.stats.data()) : null;
    const hist = entry ? history.addDay(this.history || [], entry) : (this.history || []);
    const label = date === addDays(today, -1) ? 'Gisteren' : date === today ? 'Vandaag' : date;
    return dayReview.review(hist, date, { label });
  },

  /** Geschiedenis inclusief de dag van vandaag (nog niet afgesloten). */
  historyWithToday() {
    const entry = this.dayEntry(this.stats.data());
    return history.addDay(this.history || [], entry);
  },

  seriesData(periode) { return seriesLib.series(this.historyWithToday(), periode, this.todayString()); },

  compareData(a, b) { return compare2.compare(this.historyWithToday(), a, b); },

  async dayReviewText(dateStr) {
    const r = this.dayReview(dateStr);
    const text = r ? r.text : 'Voor die dag heb ik geen gegevens.';
    this.logEvent('Dagterugblik getoond.');
    try { await this.sendNotification('Solis dagterugblik: ' + text); } catch (e) { this.error(e.message); }
    return text;
  },

  /** Back-up van geschiedenis en instellingen. */
  backupData() {
    const cfg = Object.assign({}, (this.homey.settings && this.homey.settings.get('cfg')) || {});
    delete cfg.dashboardPassword; delete cfg.dashboardToken; // wachtwoorden horen niet in een bestand dat je kunt delen
    return { versie: 1, gemaakt: new Date().toISOString(), history: this.history || [], dag: this.stats.data(), instellingen: cfg };
  },

  async restoreData(b) {
    if (!b || !Array.isArray(b.history) || b.history.length > 900 || !b.history.every((h) => h && typeof h.date === 'string')) throw new Error('Dit is geen geldige back-up.');
    this.history = b.history;
    await this.setStoreValue('history', this.history);
    if (b.instellingen && typeof b.instellingen === 'object' && this.homey.settings) {
      const cur = this.homey.settings.get('cfg') || {};
      const next = Object.assign({}, b.instellingen);
      ['dashboardPassword', 'dashboardToken'].forEach((k) => { if (cur[k] !== undefined) next[k] = cur[k]; else delete next[k]; });
      this.homey.settings.set('cfg', next);
    }
    this.logEvent('Back-up teruggezet (' + b.history.length + ' dagen).');
    return b.history.length;
  },

  // ---------- Vattenfall-import: dagen uit een bestand van Mijn Vattenfall ----------
  /** Velden die de import kan veranderen; daarvan bewaren we de oude waarden om het ongedaan te kunnen maken. */
  vfFields() { return ['importWh', 'exportWh', 'useKwh', 'selfKwh', 'vattenfall', 'imported', 'noHomeyUse', 'importCost', 'exportRev', 'valueSelf', 'valueExport', 'estimated']; },

  vfFormat(v, dec) { return Number(v).toLocaleString('nl-NL', { minimumFractionDigits: dec, maximumFractionDigits: dec }); },

  /**
   * Leest het bestand (base64) en toont wat er zou gebeuren (dryRun) of doet het echt.
   * Geeft { ok, dry, text, summary, canUndo }. text is al in de taal van de app.
   */
  /** Factuur-vulhulp: leest een dagbestand en geeft de maandtotalen terug om in te vullen. Schrijft niets weg. */
  async invoiceFillFromFile(b64, filename, month) {
    const buf = Buffer.from(String(b64 || ''), 'base64');
    if (!buf.length) throw new Error(i18n.tr('Het bestand is leeg.'));
    if (buf.length > 8 * 1024 * 1024) throw new Error(i18n.tr('Het bestand is te groot (meer dan 8 MB). Download een kortere periode of splits het bestand.'));
    let parsed;
    try { parsed = vattenfall.parse(buf, filename, { tz: this.homey.clock.getTimezone() }); } catch (e) { throw new Error(i18n.tr(e.message)); }
    const m = month ? parseMonth(month) : null;
    let r;
    try { r = require('../../lib/invoicefill').pick(parsed, { month: m, today: this.todayString() }); } catch (e) { throw new Error(i18n.tr(e.message)); } // eslint-disable-line global-require
    return { ok: true, month: r.month, label: i18n.tr(r.label), importKwh: r.importKwh, exportKwh: r.exportKwh, days: r.days, expectedDays: r.expectedDays, complete: r.complete, text: i18n.tr(r.note) };
  },

  async importVattenfall(b64, filename, dryRun) {
    const buf = Buffer.from(String(b64 || ''), 'base64');
    if (!buf.length) throw new Error(i18n.tr('Het bestand is leeg.'));
    if (buf.length > 8 * 1024 * 1024) throw new Error(i18n.tr('Het bestand is te groot (meer dan 8 MB). Download een kortere periode of splits het bestand.'));
    let parsed;
    try { parsed = vattenfall.parse(buf, filename, { tz: this.homey.clock.getTimezone() }); } catch (e) { throw new Error(i18n.tr(e.message)); }
    const info = parsed.info;
    const today = this.todayString();
    const before = this.history || [];
    const merged = vattenMerge.merge(before, parsed.days, { today });
    const keys = Object.keys(parsed.days);
    let imp = 0; let exp = 0;
    keys.forEach((k) => { imp += parsed.days[k].importKwh || 0; exp += parsed.days[k].exportKwh || 0; });
    const f = (v, d) => this.vfFormat(v, d);
    const lines = [];
    lines.push('Gelezen uit "' + String(filename || 'bestand').replace(/[<>]/g, '') + '": ' + info.days + ' dagen, van ' + info.from + ' tot ' + info.to + ' (' + (info.format === 'xlsx' ? 'Excel' : 'CSV') + (info.interval ? ', per uur of kwartier' : '') + ').');
    lines.push('Afname in totaal ' + f(imp, 1) + ' kWh, teruglevering ' + f(exp, 1) + ' kWh.');
    lines.push('Gebruikte kolommen: afname = ' + (info.importColumns.join(' + ') || '-') + '; teruglevering = ' + (info.exportColumns.join(' + ') || '-') + '.');
    lines.push((dryRun ? 'Dit gebeurt als je importeert: ' : 'Gedaan: ') + merged.added + ' nieuwe dagen, ' + merged.updated + ' dagen aangevuld, ' + merged.same + ' dagen gelijk, ' + merged.skipped + ' dagen overgeslagen omdat de app ze zelf gemeten heeft.');
    if (merged.future) lines.push(merged.future + ' dagen van vandaag of later zijn overgeslagen.');
    if (merged.truncated) lines.push('Let op: de app bewaart maximaal 800 dagen; ' + merged.truncated + ' oudste dagen vallen eraf.');
    if (info.warnings.length) { lines.push('Let op:'); info.warnings.forEach((w) => lines.push('- ' + w)); }
    const summary = { days: info.days, from: info.from, to: info.to, importKwh: Math.round(imp * 10) / 10, exportKwh: Math.round(exp * 10) / 10, added: merged.added, updated: merged.updated, same: merged.same, skipped: merged.skipped, warnings: info.warnings.length };
    if (dryRun) return { ok: true, dry: true, summary, text: i18n.tr(lines.join('\n')), canUndo: !!this.getStoreValue('historyBackup') };
    if (!merged.added && !merged.updated) return { ok: true, dry: false, summary, text: i18n.tr(lines.join('\n') + '\nEr is niets veranderd.'), canUndo: !!this.getStoreValue('historyBackup') };
    // oude waarden bewaren (één stuk) zodat het ongedaan gemaakt kan worden
    const fields = this.vfFields();
    const prev = {}; const orig = new Map(before.map((h) => [h.date, h]));
    const kept = new Set(merged.history.map((h) => h.date));
    const added = [];
    for (const h of merged.history) {
      const o = orig.get(h.date);
      if (!o) { added.push(h.date); continue; }
      if (JSON.stringify(fields.map((k) => o[k])) !== JSON.stringify(fields.map((k) => h[k]))) { prev[h.date] = fields.reduce((a, k) => { a[k] = o[k] === undefined ? null : o[k]; return a; }, {}); }
    }
    const dropped = before.filter((h) => !kept.has(h.date));
    await this.setStoreValue('historyBackup', { t: Date.now(), file: String(filename || ''), added, prev, dropped });
    this.history = merged.history;
    const st = this.getSettings();
    hImport.applyEstimates(this.history, st.importTariffFixed, st.exportTariffFixed);
    await this.setStoreValue('history', this.history);
    const text = i18n.tr(lines.join('\n') + '\nJe kunt dit ongedaan maken met de knop Ongedaan maken bij Gegevens importeren.');
    this.logEvent('Vattenfall-gegevens geïmporteerd: ' + merged.added + ' nieuwe dagen, ' + merged.updated + ' aangevuld.');
    try { await this.sendNotification('Vattenfall-gegevens geïmporteerd: ' + merged.added + ' nieuwe dagen en ' + merged.updated + ' dagen aangevuld (' + info.from + ' tot ' + info.to + ').'); } catch (e) { this.error(e.message); }
    return { ok: true, dry: false, summary, text, canUndo: true };
  },

  /** Zet de laatste Vattenfall-import terug (nieuwe dagen weg, oude waarden terug). */
  async undoVattenfall() {
    const bk = this.getStoreValue('historyBackup');
    if (!bk || !Array.isArray(bk.added)) throw new Error(i18n.tr('Er is niets om ongedaan te maken.'));
    const fields = this.vfFields();
    const drop = new Set(bk.added);
    let out = (this.history || []).filter((h) => !drop.has(h.date)).map((h) => Object.assign({}, h));
    let n = 0;
    for (const h of out) {
      const p = bk.prev && bk.prev[h.date];
      if (!p) continue;
      fields.forEach((k) => { if (p[k] === null || p[k] === undefined) delete h[k]; else h[k] = p[k]; });
      n++;
    }
    out = out.concat(bk.dropped || []);
    out.sort((a, b) => (a.date < b.date ? -1 : 1));
    this.history = out;
    await this.setStoreValue('history', this.history);
    await this.setStoreValue('historyBackup', null);
    this.logEvent('Vattenfall-import ongedaan gemaakt: ' + bk.added.length + ' dagen verwijderd, ' + n + ' dagen teruggezet.');
    return { ok: true, text: i18n.tr('Vattenfall-import ongedaan gemaakt: ' + bk.added.length + ' dagen verwijderd, ' + n + ' dagen teruggezet.'), canUndo: false };
  },

  // ---------- planner ----------
  refreshPlan() {
    try {
      const s = this.getSettings();
      const tasks = learnLib.plannerTasks(planner.parseTasks(s.plannerTasks), this.getStoreValue('appLearn') || {}, { useLearned: s.plannerUseLearned !== false, auto: s.plannerLearnedAuto !== false });
      if (!tasks.length) { this.planResult = []; return; }
      const tz = this.homey.clock.getTimezone();
      const entries = [].concat((this.todayPrices && this.todayPrices.entries) || [], (this.tomorrowPrices && this.tomorrowPrices.entries) || []);
      const hourly = (this.forecastData && this.forecastData.hourly) || {};
      const factor = this.learnedFactor();
      const kWp = Number(s.kWp) || 2.5;
      const maxW = Number(s.maxPower) || 2500;
      const sunW = (t) => {
        const z = zoned(t, tz);
        const rad = hourly[z.date + 'T' + String(z.h).padStart(2, '0') + ':00'];
        return typeof rad === 'number' ? forecast.potentialW(rad, factor, kWp, maxW) : null;
      };
      this.planResult = planner.plan(tasks, {
        now: Date.now(), tz, entries, fixedCosts: Number(s.fixedCosts) || 0, dynamic: this.currentContract() === 'dynamisch',
        importFixed: Number(s.importTariffFixed) || 0, exportFixed: Number(s.exportTariffFixed) || 0, sunW,
      });
    } catch (e) { this.error('Planner mislukt:', e.message); }
  },

  planForDashboard() {
    const tz = this.homey.clock.getTimezone();
    return (this.planResult || []).map((p) => ({ name: p.name, day: p.day, from: planner.hh(p.from, tz), to: planner.hh(p.to, tz), hours: p.hours, solarPct: p.solarPct, cost: p.cost }));
  },

  // ---------- zelfverbruik-sturing ----------
  async getAppApi() {
    if (!this.appApi) {
      const f = this.apiFactory || (async (h) => { const { HomeyAPI } = require('homey-api'); return HomeyAPI.createAppAPI({ homey: h }); }); // eslint-disable-line global-require
      this.appApi = await f(this.homey);
    }
    return this.appApi;
  },

  async findLoadDevice(name) {
    this.loadIds = this.loadIds || {};
    const api = await this.getAppApi();
    const known = this.loadIds[name];
    if (known && Date.now() - known.at < 10 * 60000) {
      try { const d = await api.devices.getDevice({ id: known.id }); if (d) return d; } catch (e) { delete this.loadIds[name]; }
    }
    const all = Object.values(await api.devices.getDevices());
    const n = name.toLowerCase();
    const dev = all.find((d) => (d.name || '').toLowerCase() === n && Array.isArray(d.capabilities) && d.capabilities.includes('onoff'))
      || all.find((d) => (d.name || '').toLowerCase().includes(n) && Array.isArray(d.capabilities) && d.capabilities.includes('onoff'));
    if (dev) this.loadIds[name] = { id: dev.id, at: Date.now() };
    return dev || null;
  },

  // ---------- apparaat klaarzetten: de app start het op het beste moment ----------
  armedList() { return this.getStoreValue('armed') || {}; },

  /** Taak voor de planner: geleerde duur en vermogen als die er zijn, anders 2 uur en 1000 W. */
  armedTask(name, until, from, durMin) {
    const s = this.getSettings();
    const tasks = learnLib.plannerTasks(planner.parseTasks(s.plannerTasks), this.getStoreValue('appLearn') || {}, { useLearned: s.plannerUseLearned !== false, auto: true });
    const n = String(name).toLowerCase();
    const t = tasks.find((x) => x.name.toLowerCase() === n) || tasks.find((x) => x.name.toLowerCase().includes(n) || n.includes(x.name.toLowerCase()));
    // duur uit de flow (bijvoorbeeld 'Time remaining' van de wasmachine) gaat voor op de geleerde of standaard duur
    const hours = durMin > 0 ? Math.max(1, Math.ceil(durMin / 60)) : (t ? t.hours : 2); // de planner rekent in hele uren
    return { name, hours, watts: t ? t.watts : 1000, until: until > 0 && until <= 24 ? until : null, from: from > 0 && from < 24 ? from : 0, learned: !!(t && t.learned), fromFlow: durMin > 0 };
  },

  /** Plan voor één klaargezet apparaat; telt het huidige uur nog mee. */
  armedPlan(task, now) {
    const s = this.getSettings();
    const tz = this.homey.clock.getTimezone();
    const entries = [].concat((this.todayPrices && this.todayPrices.entries) || [], (this.tomorrowPrices && this.tomorrowPrices.entries) || []);
    const hourly = (this.forecastData && this.forecastData.hourly) || {};
    const factor = this.learnedFactor();
    const kWp = Number(s.kWp) || 2.5;
    const maxW = Number(s.maxPower) || 2500;
    const sunW = (t) => {
      const z = zoned(t, tz);
      const rad = hourly[z.date + 'T' + String(z.h).padStart(2, '0') + ':00'];
      return typeof rad === 'number' ? forecast.potentialW(rad, factor, kWp, maxW) : null;
    };
    let start = Math.floor(now / 3600000) * 3600000;
    if (task.from > 0) {
      const z0 = zoned(now, tz);
      // overdag-modus: voor 'vanaf' of na 20:00 wachten tot morgen vanaf het gekozen uur
      if (z0.h < task.from) start += (task.from - z0.h) * 3600000;
      else if (z0.h >= 20) start += (24 - z0.h + task.from) * 3600000;
    }
    return planner.plan([task], {
      now: start, tz, entries, fixedCosts: Number(s.fixedCosts) || 0, dynamic: this.currentContract() === 'dynamisch',
      importFixed: Number(s.importTariffFixed) || 0, exportFixed: Number(s.exportTariffFixed) || 0, sunW,
    })[0] || null;
  },

  async armAppliance(name, until, from, after, durMin) {
    const nm = String(name || '').trim();
    if (!nm) throw new Error('Vul de naam van het apparaat in.');
    const dev = await this.findLoadDevice(nm);
    if (!dev) throw new Error('Ik vind geen apparaat met een aan/uit-knop dat "' + nm + '" heet in Homey.');
    const armed = Object.assign({}, this.armedList());
    // "na" is de naam van een ander apparaat; een getal (bijvoorbeeld per ongeluk 'Time remaining') negeren we
    const afterName = /^[\d\s.,]*$/.test(String(after || '')) ? '' : String(after || '');
    const dur = Number(durMin) > 0 && Number(durMin) <= 1440 ? Number(durMin) : 0;
    armed[dev.name] = { at: Date.now(), until: Number(until) > 0 ? Number(until) : 0, from: Number(from) > 0 && Number(from) < 24 ? Number(from) : 0, after: afterName, durMin: dur };
    await this.setStoreValue('armed', armed).catch(this.error);
    const task = this.armedTask(dev.name, armed[dev.name].until, armed[dev.name].from, armed[dev.name].durMin);
    const p = this.armedPlan(task, Date.now());
    const tz = this.homey.clock.getTimezone();
    const when = p ? (p.from <= Date.now() ? 'nu' : p.day + ' om ' + planner.hh(p.from, tz)) : null;
    this.logEvent(dev.name + ' klaargezet' + (when ? ', start ' + when : ''));
    this.armedTickAt = 0;
    await this.armedTick().catch(this.error);
    return dev.name + ' staat klaar' + (when ? ' en start ' + when + '.' : '. Er is nog geen goed moment berekend; de app blijft kijken.');
  },

  async disarmAppliance(name) {
    const armed = Object.assign({}, this.armedList());
    const n = String(name || '').trim().toLowerCase();
    const key = Object.keys(armed).find((k) => k.toLowerCase() === n || k.toLowerCase().includes(n));
    if (!key) return 'Dat apparaat stond niet klaar.';
    delete armed[key];
    await this.setStoreValue('armed', armed).catch(this.error);
    this.logEvent(key + ' niet meer klaargezet.');
    return key + ' staat niet meer klaar.';
  },

  /** Elke minuut: is het beste moment van een klaargezet apparaat aangebroken? Dan aanzetten. */
  async armedTick() {
    if (this.getSettings().basicMode === true) return;
    if (Date.now() - (this.armedTickAt || 0) < 55000) return;
    this.armedTickAt = Date.now();
    const armed = Object.assign({}, this.armedList());
    const names = Object.keys(armed);
    if (!names.length) return;
    const now = Date.now();
    let changed = false;
    for (const name of names) {
      const a = armed[name];
      const task = this.armedTask(name, a.until, a.from, a.durMin);
      const p = this.armedPlan(task, now);
      if (now - a.at > 36 * 3600000) {
        delete armed[name]; changed = true;
        await this.notifyText(name + ' is niet gestart: ik vond binnen 36 uur geen beter moment. Zet het apparaat zelf aan of zet het opnieuw klaar.');
        continue;
      }
      let go = !!p && p.from <= now + 30000;
      if (go && a.after && !(await this.afterDone(a.after, armed, now))) go = false;
      const imp = this.netW !== null && this.netW !== undefined && now - this.netAt < 120000 ? Math.max(0, this.netW) : 0;
      if (go && imp + task.watts > 0.9 * 230 * (Number(this.getSettings().fuseAmps) || 25)) go = false; // zekering: even wachten
      if (!p) {
        // geen prijzen of zonneverwachting bekend: overdag gewoon starten (bij dynamisch eerst 30 minuten wachten op prijzen)
        const hz = zoned(now, this.homey.clock.getTimezone()).h;
        const okHour = task.from > 0 ? (hz >= task.from && hz < 20) : true;
        const waited = this.currentContract() !== 'dynamisch' || now - a.at > 30 * 60000;
        go = okHour && waited;
      }
      if (!go) continue;
      try {
        const dev = await this.findLoadDevice(name);
        if (!dev) throw new Error('apparaat niet gevonden');
        await dev.setCapabilityValue({ capabilityId: 'onoff', value: true });
        delete armed[name]; changed = true;
        this.logEvent(name + ' gestart op het beste moment.');
        const wl = (this.getStoreValue('washLog') || []).slice(-19);
        wl.push({ t: now, name, cost: p ? p.cost : 0, worst: p ? p.worst : 0 });
        await this.setStoreValue('washLog', wl).catch(this.error);
        const done = Object.assign({}, this.getStoreValue('armedDone') || {}, { [name]: now });
        await this.setStoreValue('armedDone', done).catch(this.error);
        await this.notifyText(name + ' is gestart op het beste moment (geschatte kosten ' + String((Math.round((p ? p.cost : 0) * 100) / 100).toFixed(2)).replace('.', ',') + ' euro' + (p && p.solarPct >= 20 ? ', ' + p.solarPct + ' % zon' : '') + ')' + (p && p.worst - p.cost >= 0.01 ? '. Dat scheelt ongeveer ' + String((Math.round((p.worst - p.cost) * 100) / 100).toFixed(2)).replace('.', ',') + ' euro ten opzichte van het duurste moment.' : '.'));
      } catch (e) {
        this.error('Klaargezet apparaat starten mislukt:', e.message);
        if (!a.failedAt) { a.failedAt = now; changed = true; await this.notifyText(name + ' kon ik niet aanzetten (' + String(e.message).slice(0, 60) + '). Zet het zelf aan.'); }
      }
    }
    if (changed) await this.setStoreValue('armed', armed).catch(this.error);
  },

  /** Is het apparaat waarop gewacht wordt klaar? (niet meer klaargezet, 10 min na start, en 5 min lage stroom) */
  async afterDone(after, armed, now) {
    const n = String(after).toLowerCase();
    if (Object.keys(armed).some((k) => k.toLowerCase().includes(n) || n.includes(k.toLowerCase()))) return false;
    const done = this.getStoreValue('armedDone') || {};
    const dk = Object.keys(done).find((k) => k.toLowerCase().includes(n) || n.includes(k.toLowerCase()));
    if (dk && now - done[dk] < 10 * 60000) return false;
    const pk = Object.keys(this.appPower || {}).find((k) => k.toLowerCase().includes(n) || n.includes(k.toLowerCase()));
    const w = pk ? Number(this.appPower[pk]) : 0;
    this.afterLow = this.afterLow || {};
    if (w >= 15) { this.afterLow[n] = 0; return false; }
    if (!this.afterLow[n]) { this.afterLow[n] = now; }
    return now - this.afterLow[n] >= 5 * 60000;
  },

  /** Waarschuwing als de stroom van het net dicht bij de hoofdzekering komt. */
  async checkFuse() {
    const s = this.getSettings();
    if (s.notifyFuse === false) return;
    const now = Date.now();
    if (this.netW === null || this.netW === undefined || now - this.netAt > 120000) return;
    const amps = Number(s.fuseAmps) || 25;
    const a = Math.abs(this.netW) / 230;
    if (a < 0.85 * amps) { this.fuseSince = 0; return; }
    if (!this.fuseSince) this.fuseSince = now;
    if (now - this.fuseSince < 45000 || now - (this.fuseLast || 0) < 30 * 60000) return;
    this.fuseLast = now;
    await this.notifyText('Let op: je verbruikt nu ongeveer ' + String(a.toFixed(1)).replace('.', ',') + ' ampère van je ' + amps + ' ampère zekering. Zet een groot apparaat even uit voordat de zekering uitvalt.');
  },

  /** Ochtendbericht rond 07:30: beste moment voor de was overdag. */
  async checkMorning() {
    const s = this.getSettings();
    if (s.notifyMorning === false || this.vacationOn()) return;
    const today = this.todayString();
    if (this.getStoreValue('lastMorning') === today || this.currentMinutes() < 7 * 60 + 30 || this.currentMinutes() > 11 * 60) return;
    const tasks = learnLib.plannerTasks(planner.parseTasks(s.plannerTasks), this.getStoreValue('appLearn') || {}, { useLearned: s.plannerUseLearned !== false, auto: true });
    const wm = tasks.find((x) => /was/i.test(x.name));
    const task = Object.assign(this.armedTask(wm ? wm.name : 'Wasmachine', 20, 8), wm ? { hours: wm.hours, watts: wm.watts } : {});
    const p = this.armedPlan(task, Date.now());
    if (!p) return;
    await this.setStoreValue('lastMorning', today).catch(this.error);
    const tz = this.homey.clock.getTimezone();
    await this.notifyText('Wasadvies: het beste moment voor de was vandaag is ' + planner.hh(p.from, tz) + '–' + planner.hh(p.to, tz) + (p.solarPct >= 20 ? ', met ' + p.solarPct + ' % zonnestroom' : '') + ', kosten ongeveer ' + String((Math.round(p.cost * 100) / 100).toFixed(2)).replace('.', ',') + ' euro. Druk op je knop en de app regelt de rest.');
  },

  washInfo() {
    const wl = this.getStoreValue('washLog') || [];
    return { last: wl.slice(-3).reverse().map((x) => ({ name: x.name, t: x.t, cost: x.cost, saved: Math.max(0, Math.round((x.worst - x.cost) * 100) / 100) })), saved: Math.round(wl.reduce((a, x) => a + Math.max(0, x.worst - x.cost), 0) * 100) / 100, n: wl.length };
  },

  armedInfo() {
    const tz = this.homey.clock.getTimezone();
    const now = Date.now();
    const armed = this.armedList();
    return Object.keys(armed).map((name) => {
      const p = this.armedPlan(this.armedTask(name, armed[name].until, armed[name].from, armed[name].durMin), now);
      return { name, start: p ? (p.from <= now ? 'nu' : p.day + ' ' + planner.hh(p.from, tz)) : null, cost: p ? p.cost : null };
    });
  },

  /** Klaarzetten vanaf de tv met pincode (zie lib/remote.js). */
  remoteControl() {
    return createRemote({
      getPin: () => { const p = String(this.getSettings().dashboardPin || '').replace(/\D/g, ''); return p.length >= 4 && p.length <= 8 ? p : ''; },
      listDevices: async () => {
        const armed = this.armedInfo();
        const byName = {};
        armed.forEach((a) => { byName[a.name.toLowerCase()] = a; });
        const s = this.getSettings();
        const tasks = learnLib.plannerTasks(planner.parseTasks(s.plannerTasks), this.getStoreValue('appLearn') || {}, { useLearned: s.plannerUseLearned !== false, auto: true });
        const names = [];
        tasks.forEach((t) => { if (t.name && !names.some((n) => n.toLowerCase() === t.name.toLowerCase())) names.push(t.name); });
        armed.forEach((a) => { if (!names.some((n) => n.toLowerCase() === a.name.toLowerCase())) names.push(a.name); });
        return names.slice(0, 12).map((name) => {
          const a = byName[name.toLowerCase()];
          return { name, armed: !!a, info: a && a.start ? 'start ' + a.start : '' };
        });
      },
      arm: (name) => this.armAppliance(name, 0, 0, ''),
      disarm: (name) => this.disarmAppliance(name),
    });
  },

  async loadsTick() {
    if (this.getSettings().basicMode === true) return;
    const s = this.getSettings();
    this.loadsInfo = this.loadsInfo || {};
    if (s.loadsEnabled !== true || this.vacationOn()) { this.loadsInfo = {}; return; }
    const loads = loadsLib.parseLoads(s.loadsList);
    if (!loads.length) return;
    if (!this.loadMgr) this.loadMgr = new loadsLib.LoadManager();
    const now = Date.now();
    const isOn = {};
    const devs = {};
    try {
      for (const l of loads) {
        const d = await this.findLoadDevice(l.name);
        devs[l.name] = d;
        const v = d && d.capabilitiesObj && d.capabilitiesObj.onoff ? d.capabilitiesObj.onoff.value : null;
        isOn[l.name] = typeof v === 'boolean' ? v : null;
      }
    } catch (e) {
      this.appApi = null;
      if (!this.loadErrLogged) { this.loadErrLogged = true; this.logEvent('Sturing: apparaten lezen mislukt: ' + String(e.message).slice(0, 60)); }
      return;
    }
    this.loadErrLogged = false;
    const netW = now - this.netAt < 60000 && typeof this.netW === 'number' ? this.netW : undefined;
    const mode = this.lastEffective;
    this.loadsInfo = {};
    for (const l of loads) {
      this.loadsInfo[l.name] = { watts: l.watts, on: isOn[l.name], byUs: this.loadMgr.st(l.name).byUs, found: !!devs[l.name], test: s.loadsTest !== false };
    }
    if (mode !== 'normaal') return; // bij Geen export/Uit is overschot niet te zien
    const actions = this.loadMgr.decide({ now, netW, pvW: this.pvW || 0, loads, isOn });
    for (const a of actions) {
      const label = a.name + (a.on ? ' aanzetten' : ' uitzetten') + ' (' + a.reason + ')';
      if (s.loadsTest !== false) {
        this.testLog = this.testLog || {};
        if (now - (this.testLog[label] || 0) > 10 * 60000) { this.testLog[label] = now; this.logEvent('Testmodus: zou ' + label + '.'); }
        continue;
      }
      try {
        await devs[a.name].setCapabilityValue({ capabilityId: 'onoff', value: a.on });
        this.loadMgr.applied(a.name, a.on, now);
        this.logEvent('Sturing: ' + label + '.');
      } catch (e) {
        this.logEvent('Sturing mislukt bij ' + a.name + ': ' + String(e.message).slice(0, 50));
      }
    }
  },

  loadsStatus() {
    return Object.keys(this.loadsInfo || {}).map((n) => Object.assign({ name: n }, this.loadsInfo[n]));
  },

  /** true als gisteren of eergisteren ontbreekt in de geschiedenis (dan proberen we die uit Homey Insights te halen). */
  missingRecentDays() {
    const { addDays } = require('../../lib/timeutil'); // eslint-disable-line global-require
    const today = this.todayString();
    const h = this.history || [];
    if (!h.length) return false;
    return [1, 2].some((n) => { const d = addDays(today, -n); const e = h.find((x) => x.date === d); return !e || !(Number(e.kwh) > 0); });
  },

  // ---------- geschiedenis uit Homey overnemen ----------
  async importFromHomey() {
    const tz = this.homey.clock.getTimezone();
    const api = await this.getAppApi();
    const all = Object.values(await api.devices.getDevices());
    const isMine = (d) => /com\.leek\.solis/.test(String(d.driverId || d.driverUri || ''));
    const me = all.find(isMine) || all.find((d) => typeof this.getName === 'function' && d.name === this.getName());
    const p1 = all.find((d) => /p1|dongle|energy/i.test((d.name || '') + ' ' + (d.driverId || ''))
      && Array.isArray(d.capabilities) && d.capabilities.some((c) => /^meter_power\.(imported|exported)/.test(c)));
    const RES = ['last3Years', 'last2Years', 'lastYear', 'last6Months', 'last3Months', 'last31Days'];
    const notes = [];
    // haalt dagwaarden uit één Insights-log; kind: 'cum' (teller), 'max' (dagteller), 'power' (vermogen)
    const fetchDays = async (dev, cap, kind) => {
      const out = {};
      let points = 0; let errs = 0; let real = 0; let top = 0; const seen = [];
      for (const res of RES) {
        try {
          const r = await api.insights.getLogEntries({ id: 'homey:device:' + dev.id + ':' + cap, resolution: res });
          const arr = Array.isArray(r) ? r : (r && (r.values || r.entries)) || [];
          points = Math.max(points, arr.length);
          const cl = hImport.clean(arr);
          real = Math.max(real, cl.length);
          for (const c of cl) if (c.v > top) top = c.v;
          if (arr.length) seen.push(res.replace('last', '') + ' ' + cl.length + '/' + arr.length);
          const d = kind === 'cum' ? hImport.dailyFromCumulative(arr, tz) : kind === 'max' ? hImport.dailyMax(arr, tz) : hImport.dailyFromPower(arr, tz);
          for (const k of Object.keys(d.days)) if (!(k in out)) out[k] = d.days[k];
        } catch (e) { errs++; }
      }
      return { days: out, points, errs, real, top, seen };
    };
    const describe = (naam, r) => {
      const pos = Object.keys(r.days).filter((k) => r.days[k] > 0).length;
      let t = naam + ': ' + pos + ' dagen met waarde';
      if (!r.points) t += r.errs ? ' (log niet leesbaar)' : ' (log leeg)';
      else if (!pos) t += ' (' + r.real + ' echte punten van ' + r.points + ', hoogste ' + Math.round(r.top * 100) / 100 + '; ' + r.seen.join(', ') + ')';
      return t;
    };
    const solar = {};
    const take = (r) => { for (const k of Object.keys(r.days)) if (!(k in solar) && r.days[k] > 0) solar[k] = r.days[k]; };
    const has = (d, c) => Array.isArray(d.capabilities) && d.capabilities.includes(c);
    if (me) {
      // eerst de dagteller (0,1 kWh nauwkeurig), dan pas de totaalmeter (hele kWh)
      if (has(me, 'inverter_today')) { const r = await fetchDays(me, 'inverter_today', 'max'); notes.push(describe('omvormer dagopbrengst', r)); take(r); }
      if (has(me, 'meter_power')) { const r = await fetchDays(me, 'meter_power', 'cum'); notes.push(describe('omvormer meterstand', r)); take(r); }
      if (has(me, 'measure_power')) { const r = await fetchDays(me, 'measure_power', 'power'); notes.push(describe('omvormer vermogen', r)); take(r); }
    } else notes.push('omvormer niet gevonden in Homey');
    // andere zonnepaneel-apparaten (bijvoorbeeld een eerdere Solis-koppeling) kunnen oudere dagen hebben
    const others = all.filter((d) => d !== me && !isMine(d) && (d.class === 'solarpanel' || /solar|solis|pv/i.test((d.name || '') + ' ' + (d.driverId || ''))) && has(d, 'meter_power'));
    for (const o of others.slice(0, 4)) { const r = await fetchDays(o, 'meter_power', 'cum'); notes.push(describe('"' + o.name + '"', r)); take(r); }
    let imp = {}; let exp = {};
    if (p1) {
      const ci = p1.capabilities.find((c) => /^meter_power\.imported$/.test(c)) || p1.capabilities.find((c) => /^meter_power\.imported/.test(c));
      const ce = p1.capabilities.find((c) => /^meter_power\.exported$/.test(c)) || p1.capabilities.find((c) => /^meter_power\.exported/.test(c));
      if (ci) { const r = await fetchDays(p1, ci, 'cum'); imp = r.days; notes.push(describe('afname', r)); }
      if (ce) { const r = await fetchDays(p1, ce, 'cum'); exp = r.days; notes.push(describe('teruglevering', r)); }
    } else notes.push('P1 niet gevonden');
    const merged = hImport.mergeDays(this.history || [], solar, imp, exp, this.todayString());
    const added = merged.added;
    if (added.length) {
      this.history = history.addDay(this.history || [], added[0]);
      for (let i = 1; i < added.length; i++) this.history = history.addDay(this.history, added[i]);
    }
    let recon = '';
    try { recon = await this.reconstructSolar(); } catch (e) { recon = ' Opbrengst schatten mislukt: ' + String(e.message).slice(0, 120) + '.'; }
    const st = this.getSettings();
    const est = hImport.applyEstimates(this.history || [], st.importTariffFixed, st.exportTariffFixed);
    if (added.length || merged.updated || est || recon) await this.setStoreValue('history', this.history).catch(this.error);
    await this.setStoreValue('homeyImported', Date.now()).catch(this.error);
    const nSolar = Object.keys(solar).length;
    const text = 'Uit Homey overgenomen: ' + added.length + ' nieuwe dagen, ' + merged.updated + ' aangevuld. Zon-opbrengst gevonden voor ' + nSolar + ' dagen. [' + notes.join('; ') + ']'
      + (nSolar === 0 ? ' Homey bewaart geen opbrengst van voor de installatie van deze app.' : '') + recon
      + (est ? ' Euro\'s geschat voor ' + est + ' dagen.' : ' Vul bij Instellingen je vaste tarieven in om ook euro\'s te zien, en haal daarna opnieuw op.');
    this.logEvent(text.slice(0, 220));
    return { added: added.length, text };
  },

  /**
   * De omvormer heeft een levenslange teller (kWh). Wat de app zelf niet gemeten heeft, is dat totaal min
   * onze eigen dagen. Dat verdelen we over de eerdere dagen naar rato van de zonnestraling.
   * Het totaal klopt, de verdeling per dag is een schatting.
   */
  async reconstructSolar() {
    const total = Number(this.getCapabilityValue('meter_power')) || 0;
    const hist = this.history || [];
    if (total <= 0) return ' Opbrengst schatten kon niet: meterstand van de omvormer onbekend.';
    const today = this.todayString();
    const own = hist.filter((h) => !h.imported && h.date < today);
    const ownSum = own.reduce((a, h) => a + (Number(h.kwh) || 0), 0) + (Number(this.getCapabilityValue('inverter_today')) || 0);
    const pre = total - ownSum;
    const firstOwn = own.length ? own[0].date : today;
    const exp = hist.filter((h) => h.imported && (Number(h.exportWh) || 0) > 50).map((h) => h.date).sort();
    if (!exp.length) return '';
    // Een los getal ver voor de rest (meter-ruis) is geen start van de panelen: kies de eerste dag met minstens 3 teruglevering-dagen in de 10 dagen erna.
    const dayMs = 864e5;
    const firstExport = exp.find((d) => exp.filter((e) => Date.parse(e) >= Date.parse(d) && Date.parse(e) - Date.parse(d) <= 10 * dayMs).length >= 3) || exp[0];
    for (const h of hist) { if (h.imported && h.solarEstimated && h.date < firstExport) { h.kwh = 0; delete h.solarEstimated; } }
    const cand = hist.filter((h) => h.imported && h.date >= firstExport && h.date < firstOwn && !(h.kwh > 0 && !h.solarEstimated));
    if (!cand.length || pre <= 1) return '';
    const tz = this.homey.clock.getTimezone();
    const lat = this.homey.geolocation.getLatitude();
    const lon = this.homey.geolocation.getLongitude();
    const span = Math.round((Date.parse(today + 'T12:00:00Z') - Date.parse(firstExport + 'T12:00:00Z')) / 864e5) + 1;
    const fetchJson = this.fetchJson || getJson;
    // Open-Meteo is soms even niet bereikbaar (503): twee keer proberen, daarna het weerarchief
    const sleepMs = (ms) => new Promise((r) => this.homey.setTimeout(r, ms));
    let rad = null; let lastErr = null;
    for (let attempt = 0; attempt < 2 && !rad; attempt++) {
      try { rad = forecast.parseOpenMeteo(await fetchJson(forecast.pastUrl(lat, lon, tz, span))).daily; } catch (e) { lastErr = e; if (attempt === 0) await sleepMs(this.fetchJson ? 0 : 4000); }
    }
    if (!rad) {
      try { rad = forecast.parseOpenMeteo(await fetchJson(forecast.archiveUrl(lat, lon, tz, firstExport, addDays(today, -1)))).daily; } catch (e) { lastErr = e; }
    }
    if (!rad) {
      try {
        const pw = forecast.parsePower(await fetchJson(forecast.powerUrl(lat, lon, firstExport, addDays(today, -1))));
        if (Object.keys(pw).length >= 5) rad = pw;
      } catch (e) { lastErr = e; }
    }
    let days;
    let alloc;
    let how;
    if (rad) {
      days = cand.filter((h) => typeof rad[h.date] === 'number').map((h) => ({ date: h.date, rad: rad[h.date], minKwh: (Number(h.exportWh) || 0) / 1000 }));
      alloc = reconstruct.allocate(days, pre);
      how = 'verdeeld naar het weer';
    }
    if (!alloc) {
      // geen weer: opwek = teruglevering + gemiddeld eigen gebruik overdag
      days = cand.map((h) => ({ date: h.date, minKwh: (Number(h.exportWh) || 0) / 1000 }));
      alloc = reconstruct.allocateByExport(days, pre);
      how = 'verdeeld naar de teruglevering (weergegevens niet bereikbaar: ' + String(lastErr && lastErr.message).slice(0, 25) + ')';
    }
    if (!alloc) return ' Opbrengst schatten kon niet (totaal past niet bij de teruglevering).';
    for (const h of cand) {
      if (alloc[h.date] === undefined) continue;
      h.kwh = alloc[h.date];
      h.solarEstimated = true;
    }
    return ' Opbrengst van voor de installatie van deze app geschat voor ' + days.length + ' dagen: totaal ' + String(Math.round(pre)).replace('.', ',') + ' kWh volgens de meterstand van je omvormer, ' + how + '.';
  },

  // ---------- verbindingsdiagnose ----------
  /** Legt een echte overgang vast (weg of terug). Zelfde stand als de vorige doet niets. */
  connNote(up, elev) {
    try {
      if (!this.connLog) this.connLog = (this.getStoreValue && this.getStoreValue('connLog')) || [];
      const log = this.connLog;
      if (up && (!log.length || log[log.length - 1].up)) return; // terug zonder dat er een uitval was: niets te melden
      const e = elev === undefined ? (this.sunElevation ? this.sunElevation() : null) : elev;
      const r = connLib.record(log, { t: Date.now(), up, elev: e });
      if (!r.changed) return;
      this.connLog = r.log;
      this.connCache = null;
      this.setStoreValue('connLog', r.log).catch(this.error);
    } catch (e) { if (this.error) this.error(e.message); }
  },

  connInfo() {
    if (this.connCache && Date.now() - this.connCache.at < 60000) return this.connCache.sum;
    const log = this.connLog || (this.getStoreValue && this.getStoreValue('connLog')) || [];
    let sunFn = null;
    try {
      const lat = this.homey.geolocation.getLatitude(); const lon = this.homey.geolocation.getLongitude();
      if (typeof lat === 'number' && typeof lon === 'number') sunFn = (t) => sunLib.elevation(t, lat, lon);
    } catch (e) { sunFn = null; }
    let tz = 'Europe/Amsterdam';
    try { tz = this.homey.clock.getTimezone() || tz; } catch (e) { /* standaard */ }
    const sum = connLib.summary(log, { now: Date.now(), tz, sunFn, minElev: 5 });
    this.connCache = { at: Date.now(), sum };
    return sum;
  },

  connRows() {
    try { return connLib.rows(this.connInfo()); } catch (e) { return []; }
  },

  // ---------- verkeerslicht ----------
  /** Elke minuut: kleur opnieuw bepalen. Alleen bij een wissel gaat de flow-trigger af. */
  lightTick() {
    if (Date.now() - (this.lightAt || 0) < 55000) return this.lightState || null;
    this.lightAt = Date.now();
    const s = this.getSettings();
    const add = Number(s.fixedCosts) || 0;
    const list = (this.todayPrices && this.todayPrices.entries) || [];
    const netOk = this.netW !== null && this.netW !== undefined && Date.now() - (this.netAt || 0) < 120000;
    const prev = this.lightState || null;
    const res = lightLib.decide({
      contract: this.currentContract(),
      price: this.freshPrice(),
      prices: list.map((e) => e.price + add),
      surplusW: Number(this.getCapabilityValue('inverter_surplus')) || 0,
      netW: netOk ? this.netW : null,
      good: this.goodReason(Number(s.goodMomentWatts) || 300) !== null,
      prev,
      now: Date.now(),
    });
    this.lightState = res;
    if (prev && prev.color !== res.color) {
      this.logEvent('Verkeerslicht: ' + res.color + ' (' + res.reason + ')');
      this.homey.flow.getDeviceTriggerCard('traffic_light_changed').trigger(this, { kleur: res.color, reden: res.reason }).catch(this.error);
    }
    return res;
  },

  lightNow() {
    const r = this.lightState || this.lightTick() || this.lightState;
    return { color: r ? r.color : 'oranje', reason: r ? r.reason : 'Nog geen gegevens.' };
  },

  // ---------- wasdag-advies (zondag 19:00) ----------
  async checkWeekPlan() {
    const s = this.getSettings();
    if (s.notifyWeekPlan === false || this.vacationOn()) return;
    const today = this.todayString();
    if (!isSunday(today)) return;
    if (this.currentMinutes() < 19 * 60) return;
    if (this.getStoreValue('lastWeekPlan') === today) return;
    const days = [1, 2].map((i) => this.forecastDay(i)).filter((d) => typeof d.kwh === 'number');
    if (!days.length) return; // nog geen verwachting: later opnieuw proberen
    const adv = weekplan.advise({
      forecastDaily: days,
      hourlyByDate: (this.forecastData && this.forecastData.hourly) || {},
      tomorrowPrices: this.currentContract() === 'dynamisch' ? this.priceSeries().tomorrow : null,
    });
    if (!adv) return;
    await this.setStoreValue('lastWeekPlan', today).catch(this.error);
    this.logEvent('Wasdag-advies verstuurd.');
    await this.notify('weekplan', adv.text);
  },

  // ---------- cijfers als CSV ----------
  csvDownload() {
    const d = this.stats ? this.dayEntry(this.stats.data()) : null;
    return csvLib.toCsv(d ? history.addDay(this.history || [], d) : (this.history || []));
  },

  // ---------- maandrapport ----------
  async checkMonthly() {
    const s = this.getSettings();
    if (s.notifyMonthly === false || this.vacationOn()) return;
    const today = this.todayString();
    if (today.slice(8, 10) !== '01') return;
    if (this.currentMinutes() < 8 * 60 + 30) return;
    if (this.getStoreValue('lastMonthly') === today) return;
    await this.setStoreValue('lastMonthly', today).catch(this.error);
    const last = addDays(today, -1);
    const hist = this.history || [];
    if (hist.filter((h) => h.date.startsWith(last.slice(0, 7))).length < 5) return;
    const ov = history.overview(hist, last, history.get(hist, last) || { date: last, kwh: 0 }, { imp: Number(s.importTariffFixed) || 0, exp: Number(s.exportTariffFixed) || 0 });
    const pm = ov.monthsPrev && ov.prev && ov.prev.hasData ? (ov.monthsPrev[Number(last.slice(5, 7)) - 1] || {}).kwh : null;
    let text = report.monthlyText(null, Number(last.slice(5, 7)), ov.month, pm);
    const fi = feedin.text(feedin.status(ov.month, feedin.costAt(s.feedInSchedule, s.feedInCost, last)));
    if (fi) text += ' ' + fi;
    this.logEvent('Maandrapport verstuurd.');
    await this.notifyText(text);
    await this.triggerMonthly(text).catch((e) => this.error(e.message));
  },

  /** Flow-kaart "Maandrapport klaar" met het tekstrapport en een plaatje (de pagina Overzicht), voor mail of Telegram. */
  async triggerMonthly(text) {
    let image = null;
    try {
      const png = require('../../lib/beeld/paginas').render('overzicht', this.widgetData()); // eslint-disable-line global-require
      image = await this.homey.images.createImage();
      image.setStream(async (stream) => { stream.end(png); });
    } catch (e) { this.error('Maandplaatje mislukt: ' + e.message); return; }
    await this.homey.flow.getDeviceTriggerCard('monthly_report').trigger(this, { text, image });
  },

  /** Batterij-rekenhulp op uurbasis (lib/batterysim.js). */
  batterySimInfo() {
    const s = this.getSettings();
    return require('../../lib/batterysim').run(this.history || [], { capacityKwh: Number(s.batteryCapacityKwh) || 0, pricePerKwh: Number(s.batteryPricePerKwh) || 0, imp: Number(s.importTariffFixed) || 0, exp: Number(s.exportTariffFixed) || 0 }); // eslint-disable-line global-require
  },

  /** Spaarpotje: besparing deze maand, dit jaar en totaal (lib/savingspot.js). */
  savingsPotInfo() {
    return require('../../lib/savingspot').compute(history.addDay(this.history || [], this.dayEntry(this.stats.data())), this.todayString()); // eslint-disable-line global-require
  },

  /** Contractvergelijker (lib/contractcompare.js): vast, variabel en dynamisch op je echte kWh-cijfers. */
  contractCompareInfo() {
    const s = this.getSettings();
    return require('../../lib/contractcompare').compute(history.addDay(this.history || [], this.dayEntry(this.stats.data())), { // eslint-disable-line global-require
      today: this.todayString(), contract: this.currentContract(),
      fixedImp: Number(s.importTariffFixed) || 0, fixedExp: Number(s.exportTariffFixed) || 0,
      varImp: Number(s.compareVariableImport) || 0, varExp: Number(s.compareVariableExport) || 0,
    });
  },

  /** Kinderpagina (lib/kids.js): zonnestroom omgerekend naar auto's, wasbeurten en koffie. */
  kidsInfo() {
    const sm = this.summary();
    // gisteren ontbreekt soms in de geschiedenis (bijvoorbeeld na een herinstallatie): neem dan de laatste dag die er wel is
    let prev = sm.yesterdayKwh || 0; let prevDate = null;
    if (!(prev >= 0.5)) {
      const today = this.todayString();
      const last = (this.history || []).filter((h) => h.date < today && Number(h.kwh) >= 0.5).slice(-1)[0];
      if (last) { prev = Number(last.kwh); prevDate = last.date; }
    }
    return require('../../lib/kids').build({ todayKwh: Number(this.getCapabilityValue('inverter_today')) || 0, yesterdayKwh: prev, prevDate }, { day: Math.floor(Date.now() / 864e5) }); // eslint-disable-line global-require
  },

  batteryInfo() {
    const s = this.getSettings();
    return batteryLib.estimate(this.history || [], { imp: Number(s.importTariffFixed) || 0, exp: Number(s.exportTariffFixed) || 0, pricePerKwh: Number(s.batteryPricePerKwh) || 0 });
  },

  // ---------- ochtendsamenvatting ----------
  async checkMorning() {
    const s = this.getSettings();
    if (s.notifyMorning === false || this.vacationOn()) return;
    const m = /^(\d{1,2}):(\d{2})$/.exec(s.morningTime || '08:00');
    if (!m) return;
    const today = this.todayString();
    if (this.getStoreValue('lastMorning') === today) return;
    const mins = this.currentMinutes();
    if (mins < Number(m[1]) * 60 + Number(m[2]) || mins > 12 * 60) return;
    await this.setStoreValue('lastMorning', today).catch(this.error);
    const lines = [];
    const fc = this.forecastFor(0);
    if (fc !== null) lines.push('Vandaag verwacht ik ongeveer ' + String(fc).replace('.', ',') + ' kWh.');
    const fc1 = this.forecastFor(1);
    if (fc1 !== null) lines.push('Morgen: ongeveer ' + String(fc1).replace('.', ',') + ' kWh.');
    const sm = this.summary();
    if (sm.yesterdayKwh > 0) lines.push('Gisteren: ' + String(Math.round(sm.yesterdayKwh * 10) / 10).replace('.', ',') + ' kWh.');
    if (this.currentContract() === 'dynamisch') {
      const t = this.getCapabilityValue('inverter_plan_today');
      if (t) lines.push(t);
    }
    const pt = planner.planText((this.planResult || []).filter((p) => p.day === 'vandaag'), this.homey.clock.getTimezone());
    if (pt) lines.push('Plan: ' + pt);
    const problems = this.healthProblems();
    if (problems.length) lines.push('Let op: ' + problems.join(', ') + '.');
    if (lines.length) {
      this.logEvent('Ochtendsamenvatting verstuurd.');
      await this.notifyText('Goedemorgen. ' + lines.join(' '));
    }
    await this.triggerMorningCard(lines).catch((e) => this.error('Ochtendkaart mislukt: ' + e.message));
  },

  /** Flow-kaart "Ochtendkaart klaar": tekst en een plaatje (1200x675). Gaat hooguit eén keer per dag af (hangt aan lastMorning). */
  async triggerMorningCard(lines) {
    const d = this.widgetData();
    const text = 'Goedemorgen. ' + (lines && lines.length ? lines.join(' ') : 'Dit is je ochtendkaart.');
    const png = require('../../lib/beeld/page_ochtend').render(d); // eslint-disable-line global-require
    const image = await this.homey.images.createImage();
    image.setStream(async (stream) => { stream.end(png); });
    await this.homey.flow.getDeviceTriggerCard('morning_card').trigger(this, { text: i18n.tr(text), image });
  },

  /** Gevolgde apparaten: nu (W) en vandaag (kWh, euro). */
  appsNow(d) {
    const now = this.appPower || {};
    const today = (d && d.apps) || {};
    const names = Array.from(new Set(Object.keys(now).concat(Object.keys(today))));
    return names.map((n) => ({
      name: n,
      w: typeof now[n] === 'number' ? Math.round(now[n]) : null,
      kwh: today[n] ? Math.round((today[n].wh / 1000) * 100) / 100 : 0,
      cost: today[n] && today[n].cost > 0.004 ? Math.round(today[n].cost * 100) / 100 : null,
    }));
  },

  // ---------- gegevens voor de widgets ----------
  widgetData() {
    const s = this.getSettings();
    if (s.demoMode === true) return require('../../lib/demo').data(); // eslint-disable-line global-require
    const sm = this.summary();
    const d = this.stats.data();
    const net = sm.monthImportCost - sm.monthExportRev;
    return {
      available: true,
      online: this.online === true,
      contract: this.currentContract(),
      watts: Number(this.getCapabilityValue('measure_power')) || 0,
      maxPower: Number(s.maxPower) || 2500,
      todayKwh: Number(this.getCapabilityValue('inverter_today')) || 0,
      mode: this.lastEffective || 'normaal',
      price: this.freshPrice(),
      surplus: Number(this.getCapabilityValue('inverter_surplus')) || 0,
      net: (this.netW !== null && this.netW !== undefined && Date.now() - this.netAt < 120000) ? Math.round(this.netW) : null,
      forecastKwh: this.getCapabilityValue('inverter_forecast'),
      best: this.bestInfo || null,
      good: this.goodReason(Number(s.goodMomentWatts) || 300),
      month: {
        kwh: sm.monthKwh,
        cost: sm.monthImportCost > 0.004 || sm.monthExportRev > 0.004 ? net : null,
        value: sm.monthValue > 0.004 ? sm.monthValue : null,
        selfuse: history.selfUsePct(sm.monthKwh, sm.monthExportWh),
      },
      hours: d.hourWh || {},
      hoursHouse: d.hourHouse || {},
      forecastToday: this.forecastFor(0),
      forecast3: [0, 1, 2].map((i) => this.forecastDay(i)),
      days14: this.days14(),
      usage: this.usageNow(),
      payback: this.paybackInfo(sm),
      yearCompare: (() => { const y = yearCompare.compare(this.history || [], this.todayString()); if (y && y.months) y.months.forEach((m) => { m.whyText = yearCompare.explain(m) || ''; }); return y; })(),
      savingsPot: this.savingsPotInfo(),
      contractCompare: this.contractCompareInfo(),
      kids: this.kidsInfo(),
      dayReview: this.dayReview('gisteren'),
      shadow: shadow.analyse(this.history || []),
      exportInfo: { price: this.exportPrice(this.freshPrice()), negCostToday: Math.round((d.exportNegCost || 0) * 100) / 100, savedToday: Math.round((d.saved || 0) * 100) / 100, savedMonth: Math.round((sm.monthSaved || 0) * 100) / 100, exportKwhToday: Math.round((d.exportWh || 0) / 10) / 100 },
      sunny: this.sunnyTomorrow(),
      log: this.eventLines(5),
      logFull: this.eventLines(60),
      invoice: this.invoiceInfo(),
      learn: this.learnInfo(),
      learnWait: (() => { const have = new Set(this.learnInfo().map((x) => x.name.toLowerCase())); return String(this.getSettings().trackDevices || '').split(',').map((x) => x.trim()).filter((x) => x && !have.has(x.toLowerCase())); })(),
      health: this.panelHealth(),
      dynamic: this.dynamicInfo(),
      score: scoreLib.summary(this.history || [], Number(this.getSettings().kWp) || 2.5),
      plan: this.planForDashboard(),
      vacation: this.vacationOn(),
      battery: this.batteryInfo(),
      batterySim: this.batterySimInfo(),
      plannerOn: planner.parseTasks(s.plannerTasks).length > 0,
      loads: this.loadsStatus(),
      slim: this.slimInfo(),
      cfgView: i18n.deep(this.settingsView()),
      light: this.lightNow(),
      lang: i18n.getLang(),
      armed: this.armedInfo(),
      wash: this.washInfo(),
      overview: this.withHomeyMonths(history.overview(this.history || [], this.todayString(), this.dayEntry(d), { imp: Number(s.importTariffFixed) || 0, exp: Number(s.exportTariffFixed) || 0 })),
      apps: this.appsNow(d),
      prices: this.priceSeries(),
      feedinBreak: this.feedinBreak(),
      records: history.records(this.history || [], this.dayEntry(d)),
      yesterdayKwh: sm.yesterdayKwh,
      yearKwh: sm.yearKwh,
      totalKwh: Number(this.getCapabilityValue('meter_power')) || 0,
      hour: Math.floor(this.currentMinutes() / 60),
      time: String(Math.floor(this.currentMinutes() / 60)).padStart(2, '0') + ':' + String(this.currentMinutes() % 60).padStart(2, '0'),
    };
  },

  // ---------- weekrapport ----------
  async sendWeekly() {
    const sm = this.summary();
    const text = history.weekText(sm);
    await this.setStoreValue('lastWeekly', this.todayString()).catch(this.error);
    this.logEvent('Weekrapport verstuurd.');
    try {
      await this.sendNotification('Solis weekrapport: ' + text);
    } catch (e) { this.error('Weekrapport melding mislukt:', e.message); }
    this.homey.flow.getDeviceTriggerCard('weekly_report').trigger(this, {
      text,
      week_kwh: Math.round(sm.weekKwh * 10) / 10,
      prev_week_kwh: Math.round(sm.prevWeekKwh * 10) / 10,
      week_saved: Math.round(sm.weekSaved * 100) / 100,
      month_saved: Math.round(sm.monthSaved * 100) / 100,
    }).catch(this.error);
    return text;
  },

  isWeeklyDue() {
    const s = this.getSettings();
    return s.notifyWeekly !== false && isSunday(this.todayString()) && this.getStoreValue('lastWeekly') !== this.todayString();
  },

  async showYear() {
    const text = history.yearText(this.summary());
    this.logEvent('Jaaroverzicht getoond.');
    try { await this.sendNotification('Solis jaaroverzicht: ' + text); } catch (e) { this.error(e.message); }
    return text;
  },

  // ---------- automatische zelfcontrole (meldt alleen bij problemen) ----------
  healthProblems() {
    const s = this.getSettings();
    const p = [];
    if (this.online === false) p.push('omvormer niet bereikbaar');
    const dyn = this.currentContract() === 'dynamisch';
    if (dyn && this.freshPrice() === null) p.push('geen prijs (flow of eigen ophalen)');
    if (dyn && s.fetchPrices !== false && !this.todayPrices && this.priceErrLogged) p.push('prijzen ophalen mislukt');
    if (this.forecastErrLogged && !this.forecastAt) p.push('weer ophalen mislukt');
    if ((this.getStoreValue('wanted') || 'auto') === 'auto' && this.lastEffective === 'geen-export' && (!this.netAt || Date.now() - this.netAt > 5 * 60 * 1000)) p.push('geen netvermogen ontvangen');
    if (s.p1Enabled === true && this.p1At && Date.now() - this.p1At > 10 * 60 * 1000) p.push('P1-meter geeft geen data meer');
    const odd = (this.history || []).slice(-7).filter((h) => !h.imported && !h.solarEstimated && (Number(h.exportWh) || 0) / 1000 > (Number(h.kwh) || 0) * 1.15 + 0.5);
    if (odd.length) p.push('teruglevering hoger dan opwek op ' + fmtDate(odd[odd.length - 1].date) + ' (een meting klopt niet)');
    if (!s.allowWrite) p.push('schrijven staat uit');
    if (this.writeFails >= 3) p.push('schrijven naar omvormer mislukt');
    return p;
  },

  async healthCheck(manual) {
    const p = this.healthProblems();
    const text = p.length ? 'Let op: ' + p.join(', ') + '.' : 'Alles in orde.';
    await this.setCapabilityValue('inverter_health', text.slice(0, 80)).catch(this.error);
    await this.setStoreValue('lastHealth', this.todayString()).catch(this.error);
    if (manual || p.length) {
      this.logEvent('Controle: ' + text);
      if (manual || this.getSettings().notifyHealth !== false) {
        try { await this.sendNotification('Solis controle: ' + text); } catch (e) { this.error(e.message); }
      }
    }
    return text;
  },

  isHealthDue() {
    return this.getSettings().notifyHealth !== false && this.currentMinutes() >= 8 * 60 && this.getStoreValue('lastHealth') !== this.todayString();
  },

  EXTERNAL_EVERY_MS,
};
