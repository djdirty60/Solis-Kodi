# Een nieuw omvormermerk toevoegen

Deze app is gemaakt voor Solis. De map `lib/brands/` is de voorbereiding om later ook andere merken te ondersteunen. Er is nu **alleen Solis**. De bestaande Solis-code is niet omgebouwd: de adapter in `lib/brands/solis.js` geeft alleen door aan `lib/solis.js`.

Dit document legt stap voor stap uit hoe een ontwikkelaar een merk toevoegt. Kleine, rustige stappen; draai na elke stap de tests.

## Stap 1. Kijk eerst naar het voorbeeld

- `lib/brands/index.js`: het register en de lijst met verplichte onderdelen (bovenin staat de uitleg).
- `lib/brands/solis.js`: de adapter voor Solis.
- `lib/solis.js`: de echte Solis-code (registers, uitlezen, limiet zetten).
- `lib/modbus.js`: een kleine Modbus TCP-client zonder externe pakketten (functiecodes 03, 04, 06 en 16). Gebruik die ook voor een nieuw merk als het merk Modbus TCP spreekt.

## Stap 2. Schrijf de merk-code

Maak `lib/<merk>.js` (naar het voorbeeld van `lib/solis.js`). Een klasse met deze functies:

- uitlezen van het actuele vermogen, de spanning, de temperatuur en de status;
- opbrengst van vandaag, deze maand en totaal (in kWh);
- een limiet in watt zetten en de omvormer aan of uit zetten (alleen als het merk dat via het netwerk toestaat).

Zoek de registernummers in de officiële Modbus-documentatie van het merk. Schrijf nooit zomaar naar een register waarvan je de betekenis niet zeker weet: een verkeerde waarde kan de omvormer instellen op iets wat niet mag.

## Stap 3. Schrijf de adapter

Maak `lib/brands/<merk>.js`. Volg `lib/brands/solis.js`. De adapter exporteert:

| Onderdeel | Betekenis |
| --- | --- |
| `id` | korte naam in kleine letters, bijvoorbeeld `fronius` |
| `name` | naam zoals de gebruiker die ziet |
| `models` | lijst met bekende typen (tekst) |
| `capabilities` | `{ live, daily, limit, mode }`, elk `true` of `false` |
| `create(opts)` | geeft een object met de methoden hieronder |
| `describe(info)` | korte beschrijving voor het foutenrapport |

Het object uit `create(opts)` heeft deze methoden (alle zeven zijn verplicht, ook als een merk iets niet kan: gooi dan een duidelijke fout):

- `connect()` test de verbinding;
- `readLive()` geeft `{ power, todayKwh, statusText, ... }`, dezelfde velden als `Solis.readAll()`;
- `readDaily()` geeft `{ todayKwh, monthKwh, totalKwh }`;
- `setLimit(watts)` zet de exportlimiet;
- `setMode('aan' | 'uit')` zet de omvormer aan of uit;
- `describe(info)`;
- `close()` sluit de verbinding.

Meld de adapter aan in `lib/brands/index.js` onderaan, naast `register(require('./solis'));`:

```js
register(require('./<merk>'));
```

## Stap 4. Test met een nep-Modbusserver

Je hebt geen echte omvormer nodig voor de eerste test. Zie `test/brands.js`: daar staat een kleine nep-server (met `net.createServer`) die op een leesverzoek (functiecode 04) een vaste waarde teruggeeft. Kopieer dat idee:

1. Start de nep-server op een vrije poort (`listen(0, '127.0.0.1')`).
2. Maak de adapter met `brands.create('<merk>', { host: '127.0.0.1', port, unitId: 1 })`.
3. Roep `connect()`, `readLive()` en `readDaily()` aan en controleer de uitkomst.
4. Controleer dat een onbekend merk een duidelijke fout geeft en dat `brands.checkInstance` geen ontbrekende methode meldt.

Zie ook `test/test.js` en `test/smoke.js` voor hoe de rest van de app wordt getest. Draai alles met `node test/<naam>.js`.

## Stap 5. Laat het merk kiezen in de instellingen

Nu is er één instelling: `inverterBrand` (Installatie en doelen, standaard `solis`). Voeg je merk toe op drie plekken:

1. `lib/appsettings.js`: de standaardwaarde blijft `solis`.
2. `settings/index.html`: de lijst `values` van het veld `inverterBrand` in `SCHEMA` (zoek op `inverterBrand`).
3. `settings/en.js`: de Engelse tekst bij `inverterBrand` als die verandert.

Alle nieuwe teksten voor gebruikers komen in het Nederlands én het Engels (`lib/i18n_help.js` is een klein voorbeeld).

## Stap 6. Wat de app nu al uit het register gebruikt

Alleen het foutenrapport en de diagnose vragen `describe()` op. Het uitlezen en sturen van de omvormer in `drivers/inverter/device.js` gebruikt nog rechtstreeks `lib/solis.js`. Om een tweede merk echt te laten werken moet `device.js` dus nog zo worden aangepast dat `connect()`, `poll()` en de sturing via `brands.create(...)` lopen. Doe dat in een aparte stap, met alle bestaande tests als vangnet, en test het eerst met een tester die dat merk heeft.

## Sneller beginnen: het sjabloon

In `lib/brands/_sjabloon.js` staat een leeg merk met alle verplichte onderdelen en uitleg bij elk stuk. Zo gebruik je het:

1. Kopieer het bestand naar `lib/brands/<merk>.js` (de naam met een onderstrepingsteken wordt door de app niet geladen).
2. Vervang `voorbeeld`, `Voorbeeld-merk` en alles met `VOORBEELD` door de gegevens van het merk.
3. Zet bij `CAPABILITIES` een onderdeel op `false` als het merk dat niet via het netwerk toestaat.
4. Vul de methoden in: `connect`, `readLive`, `readDaily` (en `setLimit`, `setMode` als het merk dat kan).
5. Meld het merk aan onderaan `lib/brands/index.js` met `register(require('./<merk>'));`.
6. Kopieer `test/brandtemplate.js` naar `test/<merk>.js` en pas het aan. Die test meldt een nepmerk aan en controleert dat alle onderdelen er zijn. Draai hem met `node test/<merk>.js`.

Het sjabloon doet bewust niets met een echte omvormer. Een merk is pas klaar als iemand het met een echte omvormer heeft uitgeprobeerd. Tot die tijd mag je niet zeggen dat het werkt.

## Wat nog niet gecontroleerd is

- Er is nog nooit een ander merk dan Solis met de echte app getest.
- De adapter-interface is gebaseerd op wat Solis nodig heeft. Een merk met andere gegevens (bijvoorbeeld een batterij) kan om extra methoden vragen.
