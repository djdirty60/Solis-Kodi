# Demo-stand

Met de demo-stand laat je het dashboard en de tv-pagina's zien zonder omvormer. Alle cijfers zijn verzonnen: een jaar en een half aan zonnestroom, prijzen en verbruik van een huis met een installatie van 4,8 kWp. Elke keer is het beeld hetzelfde.

## Aanzetten in de app

1. Open de Solis-app in Homey, Instellingen, kopje **Dashboard**.
2. Zet **Demo-stand: verzonnen gegevens tonen** aan en bewaar.
3. Het dashboard (`http://IP-VAN-JE-HOMEY:8765`) en de tv-pagina's tonen nu de demogegevens. Je echte gegevens worden niet aangeraakt en niet overschreven.
4. Zet de demo-stand weer uit om je echte gegevens terug te zien.

Let op: zolang de demo-stand aan staat, gebruiken ook de Homey-flowkaarten die gegevens van het dashboard nemen (zoals de ochtendkaart) de verzonnen gegevens. Zet hem dus alleen aan als je iets wilt laten zien.

## Los demo-bestand (zonder Homey)

Open in een browser op je thuisnetwerk: `http://IP-VAN-JE-HOMEY:8765/demo.html`. Je krijgt het bestand `solis-demo.html`. Dubbelklik erop: het opent in elke browser, ook zonder Homey, zonder internet en zonder omvormer. Onderaan staat "Demo: verzonnen gegevens".

Wat erin zit: het hele dashboard met de demogegevens. Wat niet werkt: alles wat uitleg per dag, vergelijken van dagen en grafieken per periode ophaalt (die tonen een lege uitkomst), en het bedienen van de omvormer.

Handig voor: een foto of filmpje voor het Homey-forum, laten zien aan een buurman, of de app proberen voordat je een omvormer koppelt.

## Voor ontwikkelaars

- `lib/demo.js`: `data(now)` geeft het gegevensobject; `bundle(now)` geeft het losse HTML-bestand. Alles is deterministisch (vaste rij getallen, geen internet).
- Tests: `node test/fun.js`.
