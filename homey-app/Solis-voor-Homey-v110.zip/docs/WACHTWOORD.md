# Wachtwoord voor het dashboard (stap voor stap)

Standaard kan iedereen in je thuisnetwerk het dashboard openen. Wil je dat niet? Zet dan een wachtwoord.

## Wachtwoord aanzetten
1. Open de Homey-app op je telefoon en ga naar de instellingen van **Solis voor Homey**.
2. Open het kopje **Dashboard (Mac, tablet)**.
3. Vul bij **Wachtwoord voor het dashboard** een wachtwoord in. Kies iets dat je niet ook elders gebruikt.
4. Druk onderaan op **Opslaan**.

Open daarna het dashboard in je browser (bijvoorbeeld `http://IP-VAN-JE-HOMEY:8765`). Je ziet nu een inlogscherm. Na het inloggen onthoudt de browser dit 30 dagen.

## Uitloggen
Onderaan rechts op het dashboard staat een klein **Uitloggen**.

## Wachtwoord uitzetten
Maak het veld **Wachtwoord voor het dashboard** leeg en druk op **Opslaan**.

## Goed om te weten
- Na een herstart van de Homey-app (bijvoorbeeld na een update) moet je opnieuw inloggen.
- Na 5 keer een fout wachtwoord is inloggen 5 minuten geblokkeerd.
- Het dashboard werkt over gewoon `http` (niet versleuteld). Het wachtwoord houdt nieuwsgierige huisgenoten buiten, maar is geen beveiliging tegen iemand die meeluistert op je netwerk. Zet het dashboard dus nooit open naar internet.
- Een back-up bevat het wachtwoord niet. Als je een back-up terugzet, blijft je huidige wachtwoord gewoon staan.

## Kodi en Lucent
De Kodi-add-on en de Lucent-skin halen hun gegevens op via adressen als `/kodi.json`, `/meldingen.json`, `/lucent.json`, `/apparaten.json` en `/beeld/...`. Die kunnen geen wachtwoord invullen. Daarom blijven ze **gewoon open**, ook als je een wachtwoord hebt gezet. Het klaarzetten van een apparaat vanaf de tv (`/arm`) is al beschermd met de pincode.

Wil je die adressen ook afschermen?
1. Vul bij **Token voor Kodi en Lucent** een lang willekeurig woord in (bijvoorbeeld 20 letters en cijfers).
2. Druk op **Opslaan**.

Vanaf dat moment zijn die adressen alleen bereikbaar als het token wordt meegestuurd: als `?token=JOUWTOKEN` achter het adres, of als koptekst `X-Solis-Token`. Een browser die is ingelogd, kan er ook bij.

**Let op:** de Kodi-add-on kan het token nog niet meesturen. Zet je een token, dan werken de tv-pagina's en meldingen op de tv dus niet meer tot de add-on dat ondersteunt. Laat het token daarom leeg zolang je Kodi gebruikt.
