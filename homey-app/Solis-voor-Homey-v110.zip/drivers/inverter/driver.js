'use strict';

const Homey = require('homey');

module.exports = class InverterDriver extends Homey.Driver {
  async onInit() {
    this.log('Driver gestart');
  }

  // Geen aparte stap voor het IP-adres: dat vul je na het toevoegen in bij de instellingen (tandwiel).
  async onPairListDevices() {
    return [{
      name: 'Solis-omvormer',
      data: { id: 'solis-' + Date.now() },
      settings: { host: '', port: 502, unitId: 1 },
    }];
  }
};
