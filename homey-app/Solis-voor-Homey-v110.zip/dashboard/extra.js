/* Extra's voor het webdashboard: weerachtergrond, periodekeuze, dagen vergelijken, logboek,
   uitleg bij getallen en een menu (scherm aan houden, beginscherm). Alle teksten zijn Nederlands;
   bij Engels vertaalt i18n.js ze in de browser. */
(function () {
  'use strict';
  function $(i) { return document.getElementById(i); }
  function LOC() { return window.SOLIS_LOC || 'nl-NL'; }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { /* geen opslag */ } return null; }
  function el(tag, attrs, html) { var e = document.createElement(tag); for (var k in attrs) if (Object.prototype.hasOwnProperty.call(attrs, k)) e.setAttribute(k, attrs[k]); if (html !== undefined) e.innerHTML = html; return e; }
  function nf(v, d) { return (v === null || v === undefined || isNaN(v)) ? '\u2013' : Number(v).toLocaleString(LOC(), { minimumFractionDigits: d, maximumFractionDigits: d }); }
  function tr(s) { return window.SOLIS_TR ? window.SOLIS_TR(s) : s; }

  /* ---------- stijl ---------- */
  var css = '' +
    '#xb{position:fixed;left:14px;bottom:14px;z-index:60;width:44px;height:44px;border-radius:50%;border:0;cursor:pointer;background:rgba(20,28,60,.55);color:#fff;font-size:22px;line-height:44px;text-align:center;opacity:.35;transition:opacity .2s}' +
    '#xb:hover,#xb:focus-visible,#xb.on{opacity:1}body.idle #xb:not(.on){opacity:0}' +
    '.xpanel{position:fixed;z-index:61;left:14px;bottom:68px;min-width:280px;max-width:92vw;background:#fff;color:#0b1020;border-radius:18px;box-shadow:0 12px 50px rgba(11,16,32,.35);padding:10px;font:16px/1.4 Inter,-apple-system,sans-serif;display:none}' +
    '.xpanel.on{display:block}.xpanel button.xi{all:unset;box-sizing:border-box;display:flex;justify-content:space-between;align-items:center;gap:18px;width:100%;padding:11px 14px;border-radius:12px;cursor:pointer;font-size:16px}' +
    '.xpanel button.xi:hover,.xpanel button.xi:focus-visible{background:#eef1f8;outline:0}.xpanel .sw2{display:inline-block;width:38px;height:22px;border-radius:99px;background:#c9cfdd;position:relative}.xpanel .sw2::after{content:"";position:absolute;left:2px;top:2px;width:18px;height:18px;border-radius:50%;background:#fff;transition:left .15s}.xpanel .sw2.on{background:#1fae6b}.xpanel .sw2.on::after{left:18px}' +
    '.xmodal{position:fixed;z-index:70;inset:0;background:rgba(8,12,28,.55);display:none;align-items:center;justify-content:center;padding:16px}.xmodal.on{display:flex}' +
    '.xcard{background:#fff;color:#0b1020;border-radius:22px;box-shadow:0 20px 80px rgba(0,0,0,.4);padding:22px 26px;width:min(920px,100%);max-height:92vh;overflow:auto;font:17px/1.45 Inter,-apple-system,sans-serif}' +
    '.xcard h2{font-size:22px;font-weight:700;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center}.xcard h2 button{all:unset;cursor:pointer;font-size:26px;line-height:1;padding:4px 10px;border-radius:10px}.xcard h2 button:hover,.xcard h2 button:focus-visible{background:#eef1f8}' +
    '.xcard input,.xcard select{font:inherit;font-size:16px;padding:6px 10px;border:1px solid #d5d9e4;border-radius:10px;background:#fff;color:inherit}.xrow{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:12px}' +
    '.xchip{all:unset;cursor:pointer;padding:6px 14px;border-radius:99px;background:#eef1f8;font-size:15px;font-weight:500}.xchip.on{background:#0b1020;color:#fff}.xchip:focus-visible{outline:3px solid #ffc233}' +
    '.xlog{max-height:52vh;overflow:auto;border-top:1px solid #edf0f5}.xlog div{padding:7px 2px;border-bottom:1px solid #edf0f5;font-size:16px}.xlog .none{color:#6a7388}' +
    '.xleg{display:flex;gap:18px;font-size:15px;margin:6px 0;flex-wrap:wrap}.xleg i{display:inline-block;width:12px;height:12px;border-radius:50%;margin-right:6px;vertical-align:-1px}' +
    '#xper{display:inline-flex;gap:4px;margin-left:14px;vertical-align:middle}#xper button{all:unset;cursor:pointer;padding:4px 12px;border-radius:99px;background:#eef1f8;font-size:17px;font-weight:500;color:#3b4358}#xper button.on{background:#0b1020;color:#fff}#xper button:focus-visible{outline:3px solid #ffc233}' +
    '#xcmpb{position:absolute;right:440px;bottom:20px;font-size:18px;color:#6a7388;background:none;border:0;cursor:pointer;font-family:inherit;padding:0}#xcmpb:hover,#xcmpb:focus-visible{color:#0b1020;text-decoration:underline;outline:0}' +
    '[data-uitleg]{cursor:help}[data-uitleg]:focus-visible{outline:3px solid #ffc233;outline-offset:2px}' +
    'html[data-wxs=bewolkt] .zon #glow{opacity:.5}html[data-wxs=bewolkt] .zon #sun{opacity:.8}html[data-wxs=regen] .zon #glow{opacity:.18}html[data-wxs=regen] .zon #sun{opacity:.6}html[data-wxs=sneeuw] .zon #glow{opacity:.3}html[data-wxs=sneeuw] .zon #sun{opacity:.7}' +
    '#xwx{position:fixed;inset:0;z-index:3;pointer-events:none;transition:background 3s ease;background:transparent}' +
    '#xtoast{position:fixed;z-index:80;left:50%;bottom:22px;transform:translateX(-50%);background:#0b1020;color:#fff;border-radius:16px;padding:14px 18px;max-width:92vw;width:560px;font:16px/1.45 Inter,-apple-system,sans-serif;display:none;box-shadow:0 10px 40px rgba(0,0,0,.4)}#xtoast.on{display:block}#xtoast button{all:unset;cursor:pointer;margin-top:8px;padding:6px 16px;border-radius:99px;background:#fff;color:#0b1020;font-weight:600}' +
    'html[data-dm=dark] .xpanel,html[data-dm=dark] .xcard{background:#161b2e;color:#f2f4fb}html[data-dm=dark] .xpanel button.xi:hover,html[data-dm=dark] .xpanel button.xi:focus-visible,html[data-dm=dark] .xcard h2 button:hover{background:#242a42}html[data-dm=dark] .xcard input,html[data-dm=dark] .xcard select{background:#0c0f1a;border-color:#3a4160}html[data-dm=dark] .xchip,html[data-dm=dark] #xper button{background:#242a42;color:#c3c9dc}html[data-dm=dark] .xchip.on,html[data-dm=dark] #xper button.on{background:#f2f4fb;color:#0b1020}html[data-dm=dark] .xlog,html[data-dm=dark] .xlog div{border-color:#242a42}html[data-dm=dark] #xcmpb{color:#8b93ad}';
  var st = el('style', {}, css); document.head.appendChild(st);

  /* ---------- menu in de hoek ---------- */
  var menuBtn = el('button', { id: 'xb', type: 'button', 'aria-label': 'Menu', title: 'Menu', 'aria-haspopup': 'true' }, '\u22EF');
  var panel = el('div', { id: 'xp', class: 'xpanel', role: 'menu' }, '');
  document.body.appendChild(menuBtn); document.body.appendChild(panel);
  var wakeOn = function () { return ls('solisWake') !== '0'; };
  var weerOn = function () { var v = ls('solisWeer'); if (v === '1') return true; if (v === '0') return false; return !!(window.CFG && CFG.thema === 'weer'); };
  function standalone() { try { return (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true; } catch (e) { return false; } }
  function drawMenu() {
    panel.innerHTML =
      '<button class="xi" type="button" data-a="wake" role="menuitemcheckbox" aria-checked="' + wakeOn() + '"><span>Scherm aan houden</span><span class="sw2' + (wakeOn() ? ' on' : '') + '"></span></button>' +
      '<button class="xi" type="button" data-a="weer" role="menuitemcheckbox" aria-checked="' + weerOn() + '"><span>Weerachtergrond</span><span class="sw2' + (weerOn() ? ' on' : '') + '"></span></button>' +
      '<button class="xi" type="button" data-a="log" role="menuitem"><span>Logboek</span><span>\u203A</span></button>' +
      '<button class="xi" type="button" data-a="home" role="menuitem"><span>Zet op beginscherm</span><span>\u203A</span></button>';
  }
  function closeMenu() { panel.classList.remove('on'); menuBtn.classList.remove('on'); }
  menuBtn.onclick = function () { drawMenu(); var o = !panel.classList.contains('on'); panel.classList.toggle('on', o); menuBtn.classList.toggle('on', o); if (o) { var f = panel.querySelector('button'); if (f) f.focus(); } };
  panel.onclick = function (e) {
    var b = e.target; while (b && b !== panel && !(b.getAttribute && b.getAttribute('data-a'))) b = b.parentNode;
    if (!b || b === panel) return;
    var a = b.getAttribute('data-a');
    if (a === 'wake') {
      if (wakeOn()) { ls('solisWake', '0'); try { if (window.__wl) { window.__wl.release(); window.__wl = null; } } catch (x) { /* niets */ } }
      else { ls('solisWake', '1'); if (window.wake) window.wake(); }
      drawMenu();
    } else if (a === 'weer') { ls('solisWeer', weerOn() ? '0' : '1'); drawMenu(); weather(window.D); }
    else if (a === 'log') { closeMenu(); openLog(); }
    else if (a === 'home') { closeMenu(); showHint(true); }
  };

  /* ---------- tip: op beginscherm ---------- */
  var toast = el('div', { id: 'xtoast', role: 'status' }, '');
  document.body.appendChild(toast);
  function showHint(force) {
    if (!force && (standalone() || ls('solisHint') === '1')) return;
    toast.innerHTML = '<b>Zet dit dashboard op je beginscherm</b><br>iPhone of iPad: tik op de deel-knop en kies \u201CZet op beginscherm\u201D.<br>Android: open het menu van de browser en kies \u201CApp installeren\u201D.<br>Mac: kies in Safari Archief \u2192 Zet in Dock.<br><button type="button" id="xtok">Begrepen</button>';
    toast.classList.add('on');
    $('xtok').onclick = function () { toast.classList.remove('on'); ls('solisHint', '1'); };
  }
  setTimeout(function () {
    var touch = false; try { touch = ('ontouchstart' in window) || /iPhone|iPad|Android/i.test(navigator.userAgent); } catch (e) { /* niets */ }
    if (touch) showHint(false);
  }, 6000);

  /* ---------- logboek met zoeken en filter ---------- */
  var logM = el('div', { id: 'xlogm', class: 'xmodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Logboek' },
    '<div class="xcard"><h2><span>Logboek</span><button type="button" data-x="close" aria-label="Sluiten">\u00D7</button></h2>' +
    '<div class="xrow"><input id="xlq" type="search" placeholder="Zoeken" aria-label="Zoeken in het logboek" style="flex:1;min-width:160px">' +
    '<span><button class="xchip on" type="button" data-f="all">Alles</button> <button class="xchip" type="button" data-f="fault">Storingen</button> <button class="xchip" type="button" data-f="msg">Meldingen</button></span></div>' +
    '<div class="xlog" id="xll"></div></div>');
  document.body.appendChild(logM);
  var logFilter = 'all';
  var FAULT = /storing|fout|mislukt|niet bereikbaar|offline|verbinding weg|verbinding met|let op|temperatuur|afwijking|waarschuw|probleem|geen opbrengst|netspanning|zekering|noodstop/i;
  var MSG = /melding|bericht|rapport|goed moment|prijsalarm|prijzen van morgen|negatieve|waarschuwing|herinnering|klaar|verstuurd|dagterugblik|duur/i;
  function logMatch(line, f, q) {
    var t = String(line).replace(/^\d\d-\d\d \d\d:\d\d /, '');
    var shown = tr(t);
    if (f === 'fault' && !(FAULT.test(t) || FAULT.test(shown))) return false;
    if (f === 'msg' && !(MSG.test(t) || MSG.test(shown))) return false;
    if (q) { var l = q.toLowerCase(); if (String(line).toLowerCase().indexOf(l) < 0 && tr(String(line)).toLowerCase().indexOf(l) < 0) return false; }
    return true;
  }
  function drawLog() {
    var d = window.D || {}, lines = d.logFull || d.log || [], q = $('xlq').value.trim(), out = [];
    lines.forEach(function (x) { if (logMatch(x, logFilter, q)) out.push('<div>' + String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</div>'); });
    $('xll').innerHTML = out.length ? out.join('') : '<div class="none">Niets gevonden.</div>';
    var chips = logM.querySelectorAll('.xchip');
    for (var i = 0; i < chips.length; i++) chips[i].classList.toggle('on', chips[i].getAttribute('data-f') === logFilter);
  }
  function openLog() { logM.classList.add('on'); drawLog(); $('xlq').focus(); }
  logM.addEventListener('click', function (e) {
    var t = e.target;
    if (t === logM || (t.getAttribute && t.getAttribute('data-x') === 'close')) { logM.classList.remove('on'); return; }
    var f = t.getAttribute && t.getAttribute('data-f'); if (f) { logFilter = f; drawLog(); }
  });
  logM.querySelector('#xlq').addEventListener('input', drawLog);

  /* ---------- uitleg bij getallen ---------- */
  var UITLEG = {
    opwek: ['Opwek nu', 'Dit is wat je zonnepanelen op dit moment aan stroom maken, in watt (W). De omvormer meldt het elke paar seconden. Bij weinig zon of in de nacht is het laag of nul.'],
    vandaag: ['Vandaag', 'Het totaal aan stroom dat je panelen sinds middernacht hebben opgewekt, in kilowattuur (kWh). Het getal loopt de hele dag op. De verwachting komt uit de weersvoorspelling en wat je panelen eerder deden.'],
    verbruikvandaag: ['Verbruik vandaag', 'Alles wat je huis vandaag heeft gebruikt: stroom van je eigen zon plus stroom van het net. De app rekent dit uit met de meting van de P1-dongle en de opwek van de omvormer.'],
    zelf: ['Zelf gebruikt', 'Het deel van je zonnestroom dat je zelf in huis opmaakt, in procenten. Wat je niet gebruikt lever je terug aan het net. Hoger is vaak beter, zeker als terugleveren weinig oplevert.'],
    besparing: ['Besparing', 'Wat je zonnestroom waard is in euro\u2019s: de stroom die je zelf gebruikt (dat hoef je niet in te kopen) plus wat je terugleverde. De app rekent met je tarief of, bij dynamisch, met de prijs van dat uur.'],
    payback: ['Terugverdientijd', 'Hoelang het duurt voordat je panelen zichzelf hebben terugverdiend. Dat is de aanschafprijs gedeeld door wat je per jaar bespaart. Vanaf 60 dagen aan metingen gebruikt de app je echte besparing, daarvoor is het een schatting.'],
    overschot: ['Overschot', 'Wat je panelen op dit moment meer maken dan je huis gebruikt, in watt. Dat gaat naar het net. Is er genoeg overschot, dan is het een goed moment om een apparaat te starten.'],
    prijs: ['Stroomprijs', 'De prijs per kilowattuur op dit moment. Bij een dynamisch contract is dit de beursprijs van dit uur plus je vaste opslag (belasting en inkoopkosten). Bij een vast contract geldt je vaste tarief.'],
    score: ['Score vandaag', 'Hoeveel je panelen vandaag hebben opgewekt ten opzichte van wat de app verwachtte, in procenten. 100 % is precies zoals verwacht, meer is beter.'],
    co2: ['CO\u2082', 'Een ruwe schatting van de uitstoot die je zonnestroom heeft voorkomen. De app rekent met ongeveer 0,35 kg CO\u2082 per kilowattuur stroom van het net. Zo\u2019n schatting is nooit exact.'],
    advies: ['Slim advies', 'De app kijkt naar je overschot, de prijs en het verkeerslicht en zegt of nu een goed moment is om de was of vaatwasser aan te zetten. Er is een goed moment bij overschot, een negatieve prijs, of als de opwek anders verloren zou gaan.'],
    net: ['Van het net / terug', 'Hoeveel stroom je nu uit het net haalt (rood) of teruglevert (groen), gemeten door de P1-dongle bij de meter.'],
    huis: ['Huis gebruikt', 'Wat je huis op dit moment gebruikt, in watt: de zonnestroom die je direct opmaakt plus wat je van het net haalt.']
  };
  var KEYS = [
    [/^zonnepanelen$/i, 'opwek'], [/^opwek nu$/i, 'opwek'], [/^vandaag$/i, 'vandaag'], [/^opgewekt vandaag$/i, 'vandaag'], [/^verbruik vandaag$/i, 'verbruikvandaag'],
    [/^zelf gebruikt/i, 'zelf'], [/^waarde van je zonnestroom/i, 'besparing'], [/^besparing/i, 'besparing'], [/^terugverdiend/i, 'payback'], [/^terugverdientijd/i, 'payback'],
    [/^overschot/i, 'overschot'], [/^stroomprijs/i, 'prijs'], [/^score vandaag/i, 'score'], [/co\u2082|co2/i, 'co2'], [/^slim advies/i, 'advies'],
    [/^(van het net|terug naar het net|naar het net)$/i, 'net'], [/^huis gebruikt$/i, 'huis'], [/^goed voor het milieu/i, 'co2']
  ];
  function titleOf(t) {
    var h = t.querySelector('h3, .ol, .oh > span, .l'); if (!h) return '';
    return (h.textContent || '').replace(/\s+/g, ' ').trim();
  }
  function keyFor(tile) {
    if (tile.querySelector('#co')) return 'co2';
    if (tile.classList.contains('mid') || tile.querySelector('.num')) return 'opwek';
    if (tile.id === 'nn') { var nn = $('nnl'); if (nn && (/^terug naar het net$/i.test(nn.textContent.trim()) || nn.textContent.trim().toLowerCase() === tr('Terug naar het net').toLowerCase())) return 'overschot'; return 'net'; }
    var title = titleOf(tile); if (!title) return null;
    var nl = title;
    for (var i = 0; i < KEYS.length; i++) if (KEYS[i][0].test(nl)) return KEYS[i][1];
    // Engelse weergave: vergelijk met de vertaalde titels
    for (var k in UITLEG) if (Object.prototype.hasOwnProperty.call(UITLEG, k) && tr(UITLEG[k][0]).toLowerCase() === nl.toLowerCase()) return k;
    return null;
  }
  var uitM = el('div', { id: 'xuit', class: 'xmodal', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'xuitt' },
    '<div class="xcard" style="width:min(560px,100%)"><h2><span id="xuitt">Hoe is dit berekend?</span><button type="button" data-x="close" aria-label="Sluiten">\u00D7</button></h2><div id="xuitn" style="font-weight:600;margin-bottom:6px"></div><div id="xuitb"></div></div>');
  document.body.appendChild(uitM);
  var lastFocus = null;
  function openUitleg(k) {
    var u = UITLEG[k]; if (!u) return;
    lastFocus = document.activeElement;
    $('xuitn').textContent = u[0]; $('xuitb').textContent = u[1];
    uitM.classList.add('on'); uitM.querySelector('button').focus();
  }
  function closeAll() { var any = false; [uitM, logM, cmpM].forEach(function (m) { if (m && m.classList.contains('on')) { m.classList.remove('on'); any = true; } }); if (panel.classList.contains('on')) { closeMenu(); any = true; } if (any && lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) { /* niets */ } } return any; }
  uitM.addEventListener('click', function (e) { var t = e.target; if (t === uitM || (t.getAttribute && t.getAttribute('data-x') === 'close')) closeAll(); });
  function markTiles() {
    var tiles = document.querySelectorAll('#stage .col, #stage .t, #stage .oc, #stage .node, #stage .mid, #stage .mc');
    for (var i = 0; i < tiles.length; i++) {
      var t = tiles[i];
      var k = keyFor(t);
      if (k) { if (t.getAttribute('data-uitleg') !== k) { t.setAttribute('data-uitleg', k); t.setAttribute('tabindex', '0'); t.setAttribute('role', 'button'); t.setAttribute('aria-label', 'Hoe is dit berekend? ' + UITLEG[k][0]); } }
      else if (t.hasAttribute('data-uitleg')) { t.removeAttribute('data-uitleg'); t.removeAttribute('tabindex'); t.removeAttribute('role'); t.removeAttribute('aria-label'); }
    }
  }
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('a, button, input, select, .sw, #xper, .xmodal, .xpanel')) return;
    var t = e.target.closest ? e.target.closest('[data-uitleg]') : null;
    if (t) openUitleg(t.getAttribute('data-uitleg'));
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (closeAll()) e.stopPropagation(); return; }
    if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.getAttribute && e.target.getAttribute('data-uitleg')) { e.preventDefault(); openUitleg(e.target.getAttribute('data-uitleg')); }
  }, true);
  // cijfertoetsen wisselen van pagina; niet tijdens het typen in een zoekveld of datumveld
  document.addEventListener('keydown', function (e) { var n = e.target && e.target.nodeName; if (n === 'INPUT' || n === 'SELECT' || n === 'TEXTAREA') e.stopPropagation(); }, true);

  /* ---------- weerachtergrond ---------- */
  var wx = el('div', { id: 'xwx', 'aria-hidden': 'true' }, ''); document.body.appendChild(wx);
  var wxMeta = document.querySelector('meta[name=theme-color]');
  function weatherState(d) {
    if (!d) return null;
    var ov = /[?&]wx=(zonnig|bewolkt|regen|sneeuw)/.exec(location.search); if (ov) return ov[1];
    var s = window.sun ? window.sun() : null;
    if (s && (s.now < s.rise - .2 || s.now > s.set + .2)) return 'nacht';
    var code = d.forecast3 && d.forecast3[0] && typeof d.forecast3[0].code === 'number' ? d.forecast3[0].code : null;
    if (code !== null && ((code >= 71 && code <= 77) || code === 85 || code === 86)) return 'sneeuw';
    if (code !== null && code >= 51) return 'regen';
    var ratio = d.maxPower ? d.watts / d.maxPower : 0, mid = s ? (s.now > s.rise + 1.5 && s.now < s.set - 1.5) : true;
    if (code !== null && code >= 2 && (code === 3 || code >= 45)) return 'bewolkt';
    if (mid && ratio < .1 && d.online) return 'bewolkt';
    return 'zonnig';
  }
  var WX = {
    zonnig: ['linear-gradient(180deg,rgba(90,150,235,.30),rgba(255,214,150,.18))', 'multiply', '#4f86d6'],
    bewolkt: ['linear-gradient(180deg,rgba(125,132,148,.62),rgba(170,175,188,.40))', 'multiply', '#8a93a6'],
    regen: ['linear-gradient(180deg,rgba(80,92,118,.50),rgba(112,124,146,.32))', 'multiply', '#5a6b88'],
    sneeuw: ['linear-gradient(180deg,rgba(150,165,195,.66),rgba(215,224,240,.46))', 'multiply', '#9fb0cf'],
    nacht: ['linear-gradient(180deg,rgba(4,8,36,.34),rgba(10,16,50,.24))', 'normal', '#0b1020']
  };
  function weather(d) {
    if (!weerOn() && !/[?&]wx=/.test(location.search)) { fx(null); document.documentElement.removeAttribute('data-wxs'); wx.style.background = 'transparent'; wx.removeAttribute('data-wx'); if (wxMeta) wxMeta.setAttribute('content', '#0b1020'); return; }
    var s = weatherState(d || window.D); if (!s) { fx(null); document.documentElement.removeAttribute('data-wxs'); return; }
    fx(s); document.documentElement.setAttribute('data-wxs', s);
    wx.style.background = WX[s][0]; wx.style.mixBlendMode = WX[s][1]; wx.setAttribute('data-wx', s);
    if (wxMeta) wxMeta.setAttribute('content', WX[s][2]);
  }

  /* ---------- periodekeuze op Details ---------- */
  var period = 'dag', seriesCache = {}, perOrig = null;
  var PTXT = { week: 'Opwek en verbruik, laatste 7 dagen', maand: 'Opwek en verbruik, laatste 30 dagen', jaar: 'Opwek en verbruik, laatste 12 maanden', alles: 'Opwek en verbruik, alle maanden met gegevens' };
  function fmtLabel(p, key) {
    if (p === 'jaar' || p === 'alles') { var m = key.split('-'); var dm = new Date(Number(m[0]), Number(m[1]) - 1, 1); return p === 'alles' ? dm.toLocaleDateString(LOC(), { month: 'short', year: '2-digit' }) : dm.toLocaleDateString(LOC(), { month: 'short' }); }
    var d = new Date(key + 'T12:00:00');
    return p === 'week' ? d.toLocaleDateString(LOC(), { weekday: 'short' }) : String(d.getDate());
  }
  function drawSeries(j) {
    var ch = $('ch1'), ax = $('ax1'); if (!ch || !ax || !j || !j.labels) return;
    var n = j.labels.length, mx = 0.1, i;
    for (i = 0; i < n; i++) { if (j.gen[i] > mx) mx = j.gen[i]; if (j.use[i] > mx) mx = j.use[i]; }
    var slot = 1000 / n, bw = slot * 0.36, o = '<line x1="0" y1="296" x2="1000" y2="296" stroke="#e3e7ef" stroke-width="2" vector-effect="non-scaling-stroke"/>';
    for (i = 0; i < n; i++) {
      var x = i * slot + slot * 0.1, g = j.gen[i], u = j.use[i], lab = j.labels[i];
      if (g !== null && g !== undefined) o += '<rect x="' + x.toFixed(1) + '" y="' + (296 - g / mx * 280).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(1, g / mx * 280).toFixed(1) + '" rx="3" fill="#ff9f1c"><title>' + fmtLabel(j.periode, lab) + ': ' + nf(g, 1) + ' kWh</title></rect>';
      if (u !== null && u !== undefined) o += '<rect x="' + (x + bw + slot * 0.04).toFixed(1) + '" y="' + (296 - u / mx * 280).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(1, u / mx * 280).toFixed(1) + '" rx="3" fill="#7a5cff"><title>' + fmtLabel(j.periode, lab) + ': ' + nf(u, 1) + ' kWh</title></rect>';
    }
    ch.innerHTML = o;
    var step = j.periode === 'maand' ? 5 : 1, ticks = '';
    for (i = 0; i < n; i++) {
      var vals = '';
      if (n <= 14) {
        if (j.gen[i] !== null && j.gen[i] !== undefined) vals += '<br><small style="color:#ff9f1c">' + nf(j.gen[i], 0) + '</small>';
        if (j.use[i] !== null && j.use[i] !== undefined) vals += '<br><small style="color:#7a5cff">' + nf(j.use[i], 0) + '</small>';
      }
      ticks += '<span>' + ((i % step === 0 || i === n - 1) ? fmtLabel(j.periode, j.labels[i]) : '') + vals + '</span>';
    }
    ax.innerHTML = ticks;
  }
  function loadSeries(p, done) {
    var c = seriesCache[p];
    if (c && Date.now() - c.at < 300000) { done(c.j); return; }
    fetch('reeks?periode=' + p).then(function (r) { return r.json(); }).then(function (j) { seriesCache[p] = { at: Date.now(), j: j }; done(j); }).catch(function () { /* blijf bij de oude weergave */ });
  }
  function injectPeriod() {
    if (window.view !== 'meer' || $('xper') || !$('ch1')) return;
    var h3 = $('ch1').parentNode.parentNode.querySelector('h3'); if (!h3) return;
    var first = h3.firstElementChild; perOrig = first ? first.textContent : null;
    var box = el('span', { id: 'xper', role: 'group', 'aria-label': 'Periode' }, '<button type="button" data-p="dag">Dag</button><button type="button" data-p="week">Week</button><button type="button" data-p="maand">Maand</button><button type="button" data-p="jaar">Jaar</button><button type="button" data-p="alles">Alles</button>');
    if (first) first.appendChild(box); else h3.appendChild(box);
    box.onclick = function (e) { var p = e.target.getAttribute && e.target.getAttribute('data-p'); if (!p) return; period = p; paintPeriod(); };
    paintPeriod();
  }
  function paintPeriod() {
    var box = $('xper'); if (!box) return;
    var bs = box.querySelectorAll('button');
    for (var i = 0; i < bs.length; i++) { var on = bs[i].getAttribute('data-p') === period; bs[i].classList.toggle('on', on); bs[i].setAttribute('aria-pressed', on); }
    var title = box.parentNode.firstChild;
    if (period === 'dag') {
      if (title && title.nodeType === 3) title.nodeValue = perOrig || 'Opwek en verbruik vandaag';
      if (window.D && window.updMeer) window.updMeer(window.D);
      return;
    }
    if (title && title.nodeType === 3) title.nodeValue = PTXT[period];
    loadSeries(period, drawSeries);
  }
  function afterMeer() {
    injectPeriod();
    var box = $('xper');
    if (box && period !== 'dag') { var c = seriesCache[period]; if (c) drawSeries(c.j); else loadSeries(period, drawSeries); }
  }

  /* ---------- dagen vergelijken (pagina Inzicht) ---------- */
  var cmpM = el('div', { id: 'xcmp', class: 'xmodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Dagen vergelijken' },
    '<div class="xcard"><h2><span>Dagen vergelijken</span><button type="button" data-x="close" aria-label="Sluiten">\u00D7</button></h2>' +
    '<div class="xrow"><label>Dag A <input type="date" id="xca"></label><label>Dag B <input type="date" id="xcb"></label></div>' +
    '<div id="xcg"></div></div>');
  document.body.appendChild(cmpM);
  function iso(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function lineChart(a, b, title, unit) {
    var W = 860, H = 240, mx = 0.05, i;
    for (i = 0; i < 24; i++) { mx = Math.max(mx, a[i] || 0, b[i] || 0); }
    function path(arr) { var p = ''; for (var h = 0; h < 24; h++) { var x = 30 + h / 23 * (W - 40), y = H - 24 - (arr[h] || 0) / mx * (H - 44); p += (h ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } return p; }
    var ax = ''; for (i = 0; i < 24; i += 3) ax += '<text x="' + (30 + i / 23 * (W - 40)).toFixed(1) + '" y="' + (H - 6) + '" font-size="12" text-anchor="middle" fill="#6a7388">' + i + ':00</text>';
    return '<h3 style="font-size:17px;margin:10px 0 2px">' + title + ' <small style="font-weight:400;color:#6a7388">(' + unit + ', max ' + nf(mx, 1) + ')</small></h3><svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;height:auto;display:block"><line x1="30" y1="' + (H - 24) + '" x2="' + (W - 10) + '" y2="' + (H - 24) + '" stroke="#e3e7ef" stroke-width="2"/>' +
      '<path d="' + path(a) + '" fill="none" stroke="#ff9f1c" stroke-width="8" stroke-opacity=".6" stroke-linejoin="round" stroke-linecap="round"/><path d="' + path(b) + '" fill="none" stroke="#7a5cff" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="1 0"/>' + ax + '</svg>';
  }
  function barsCmp(a, b) {
    var rows = [['Opgewekt', 'kwh'], ['Verbruik', 'usageKwh'], ['Ingekocht', 'importKwh'], ['Teruggeleverd', 'exportKwh']], mx = 0.1, o = '<div style="display:grid;grid-template-columns:auto 1fr;gap:6px 14px;align-items:center">';
    rows.forEach(function (r) { mx = Math.max(mx, a[r[1]] || 0, b[r[1]] || 0); });
    rows.forEach(function (r) {
      var va = a[r[1]], vb = b[r[1]];
      var bar = function (v, c) { return v === null || v === undefined ? '<div style="color:#6a7388;font-size:15px">\u2013</div>' : '<div style="display:flex;align-items:center;gap:8px"><div style="height:14px;border-radius:7px;background:' + c + ';width:' + Math.max(1, v / mx * 100) + '%"></div><span style="font-size:15px">' + nf(v, 1) + ' kWh</span></div>'; };
      o += '<div style="font-weight:600">' + r[0] + '</div><div>' + bar(va, '#ff9f1c') + bar(vb, '#7a5cff') + '</div>';
    });
    return o + '</div>';
  }
  function dayName(s) { return new Date(s + 'T12:00:00').toLocaleDateString(LOC(), { weekday: 'short', day: 'numeric', month: 'short' }); }
  function drawCompare() {
    var a = $('xca').value, b = $('xcb').value, g = $('xcg'); if (!a || !b) { g.textContent = ''; return; }
    fetch('vergelijk?a=' + encodeURIComponent(a) + '&b=' + encodeURIComponent(b)).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok) { g.innerHTML = '<div class="xlog"><div class="none">Voor een van deze dagen zijn geen gegevens. Kies een andere dag.</div></div>'; return; }
      var leg = '<div class="xleg"><span><i style="background:#ff9f1c"></i>' + dayName(j.a.date) + ' \u00B7 ' + nf(j.a.kwh, 1) + ' kWh opgewekt</span><span><i style="background:#7a5cff"></i>' + dayName(j.b.date) + ' \u00B7 ' + nf(j.b.kwh, 1) + ' kWh opgewekt</span></div>';
      var o = leg;
      if (j.mode === 'uur') {
        o += lineChart(j.a.genHours, j.b.genHours, 'Opwek per uur', 'kWh');
        if (j.a.useHours && j.b.useHours) o += lineChart(j.a.useHours, j.b.useHours, 'Verbruik per uur', 'kWh');
      } else o += '<div style="margin:8px 0;color:#6a7388;font-size:15px">Van een van de dagen zijn geen uurwaarden bewaard, daarom zie je alleen de totalen.</div>' + barsCmp(j.a, j.b);
      g.innerHTML = o;
    }).catch(function () { g.innerHTML = '<div class="xlog"><div class="none">Kon de dagen niet ophalen.</div></div>'; });
  }
  cmpM.addEventListener('click', function (e) { var t = e.target; if (t === cmpM || (t.getAttribute && t.getAttribute('data-x') === 'close')) closeAll(); });
  cmpM.querySelector('#xca').addEventListener('change', drawCompare); cmpM.querySelector('#xcb').addEventListener('change', drawCompare);
  function openCompare() {
    lastFocus = document.activeElement;
    var now = new Date(), y = new Date(now.getTime() - 864e5), y2 = new Date(now.getTime() - 2 * 864e5);
    var a = $('xca'), b = $('xcb'); a.max = b.max = iso(now);
    if (!a.value) a.value = iso(y); if (!b.value) b.value = iso(y2);
    cmpM.classList.add('on'); drawCompare(); a.focus();
  }
  function injectCompare() {
    if (window.view !== 'inzicht' || $('xcmpb') || !$('bkl')) return;
    var b = el('button', { id: 'xcmpb', type: 'button' }, 'Dagen vergelijken');
    $('bkl').parentNode.appendChild(b); b.onclick = openCompare;
  }

  /* ---------- haken in het dashboard ---------- */
  function after(d) {
    try { weather(d); } catch (e) { /* niets */ }
    try { if (window.view === 'meer') afterMeer(); } catch (e) { /* niets */ }
    try { injectCompare(); } catch (e) { /* niets */ }
    try { markTiles(); } catch (e) { /* niets */ }
    if (logM.classList.contains('on')) drawLog();
  }
  var origUpdate = window.update;
  if (typeof origUpdate === 'function') {
    window.update = function (d) { origUpdate(d); after(d); };
  }
  var origBuild = window.build;
  if (typeof origBuild === 'function') {
    window.build = function () { origBuild(); try { markTiles(); } catch (e) { /* niets */ } };
  }
  if (window.D) after(window.D);

  /* ---------- wolken, regen en sneeuw (alleen pagina Zon) ---------- */
  var fxC = null, fxX = null, fxMode = null, fxList = [], fxT = 0, fxRaf = 0, fxW = 0, fxH = 0;
  var still = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function fxSize() { if (!fxC) return; fxW = fxC.width = window.innerWidth; fxH = fxC.height = window.innerHeight; }
  function fxInit(mode) {
    fxList = []; var i, n;
    if (mode === 'bewolkt' || mode === 'regen' || mode === 'sneeuw') {
      n = mode === 'bewolkt' ? 9 : 7;
      for (i = 0; i < n; i++) fxList.push({ k: 'c', x: Math.random() * fxW, y: fxH * (0.04 + Math.random() * 0.42), s: 120 + Math.random() * 190, v: 4 + Math.random() * 9, a: mode === 'bewolkt' ? 0.30 : 0.34, p: Math.random() * 6 });
    }
    if (mode === 'regen') for (i = 0; i < 170; i++) fxList.push({ k: 'r', x: Math.random() * fxW, y: Math.random() * fxH, l: 16 + Math.random() * 22, v: 520 + Math.random() * 340 });
    if (mode === 'sneeuw') for (i = 0; i < 130; i++) fxList.push({ k: 's', x: Math.random() * fxW, y: Math.random() * fxH, r: 1.4 + Math.random() * 3.2, v: 28 + Math.random() * 46, p: Math.random() * 6 });
  }
  function cloud(c, ctx) {
    var cols = [[-.9, .1, .55], [-.45, -.25, .75], [0, -.1, .9], [.5, -.3, .7], [.95, .05, .5], [.2, .2, .7], [-.3, .22, .6]], i;
    for (i = 0; i < cols.length; i++) {
      var q = cols[i], x = c.x + q[0] * c.s * .5, y = c.y + q[1] * c.s * .28, r = q[2] * c.s * .36;
      var g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(235,240,250,' + c.a + ')'); g.addColorStop(1, 'rgba(235,240,250,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.fill();
    }
  }
  function fxFrame(t) {
    fxRaf = 0; if (!fxMode || !fxX) return;
    var dt = Math.min(.06, (t - fxT) / 1000 || .03); fxT = t;
    fxX.clearRect(0, 0, fxW, fxH);
    for (var i = 0; i < fxList.length; i++) {
      var o = fxList[i];
      if (o.k === 'c') { if (!still) o.x += o.v * dt; if (o.x - o.s > fxW) o.x = -o.s; cloud(o, fxX); }
      else if (o.k === 'r') {
        if (!still) { o.y += o.v * dt; o.x -= o.v * dt * .18; } if (o.y > fxH + 30) { o.y = -30; o.x = Math.random() * (fxW + 200); }
        fxX.strokeStyle = 'rgba(190,210,240,.42)'; fxX.lineWidth = 1.6; fxX.beginPath(); fxX.moveTo(o.x, o.y); fxX.lineTo(o.x + o.l * .18, o.y - o.l); fxX.stroke();
      } else {
        if (!still) { o.y += o.v * dt; o.p += dt * 1.2; o.x += Math.sin(o.p) * 18 * dt; } if (o.y > fxH + 10) { o.y = -10; o.x = Math.random() * fxW; }
        fxX.fillStyle = 'rgba(255,255,255,.82)'; fxX.beginPath(); fxX.arc(o.x, o.y, o.r, 0, 6.2832); fxX.fill();
      }
    }
    if (!still && !document.hidden) fxRaf = requestAnimationFrame(fxFrame);
  }
  function fx(mode) {
    if (mode !== 'bewolkt' && mode !== 'regen' && mode !== 'sneeuw') mode = null;
    if (mode && window.view && window.view !== 'zon') mode = null;
    if (mode === fxMode) return;
    fxMode = mode;
    if (!mode) { if (fxC) fxC.style.display = 'none'; return; }
    if (!fxC) { fxC = el('canvas', { id: 'xfx', 'aria-hidden': 'true' }, ''); fxC.style.cssText = 'position:fixed;inset:0;z-index:2;pointer-events:none;width:100%;height:100%'; document.body.appendChild(fxC); fxX = fxC.getContext('2d'); window.addEventListener('resize', function () { fxSize(); fxInit(fxMode); }); document.addEventListener('visibilitychange', function () { if (!document.hidden && fxMode && !fxRaf) fxRaf = requestAnimationFrame(fxFrame); }); }
    fxC.style.display = 'block'; fxSize(); fxInit(mode); if (!fxRaf) fxRaf = requestAnimationFrame(fxFrame);
  }

  window.SOLIS_EXTRA = { weatherState: weatherState, logMatch: logMatch, keyFor: keyFor };
})();
