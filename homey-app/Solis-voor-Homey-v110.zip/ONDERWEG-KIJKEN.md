# Je dashboard onderweg bekijken (veilig, met Tailscale)

Met Tailscale kun je het dashboard ook buiten je wifi bekijken, bijvoorbeeld op je telefoon. Je zet geen poorten open op je router. Het dashboard is alleen-lezen: niemand kan er iets mee veranderen.

Je Mac wordt hierbij de "brug" naar je thuisnetwerk. **Je Mac moet dan wel aan staan en wakker zijn** als je onderweg kijkt. Als je Mac slaapt, werkt het niet.

## Eenmalig instellen

1. Ga op je Mac naar https://tailscale.com en maak een gratis account (inloggen met Google of Apple kan).
2. Installeer Tailscale op je Mac (gratis, via tailscale.com/download) en log in.
3. Installeer Tailscale op je telefoon (App Store) en log in met **hetzelfde account**.
4. Open Terminal op je Mac en typ dit. Het netwerk is dat van je Homey. Jouw datalogger heeft 192.168.178.197, dus is dit 192.168.178.0/24:

   ```
   sudo tailscale set --advertise-routes=192.168.178.0/24
   ```

   Typ je Mac-wachtwoord als erom gevraagd wordt (je ziet het niet verschijnen). Staat er "command not found"? Gebruik dan:

   ```
   sudo /Applications/Tailscale.app/Contents/MacOS/Tailscale set --advertise-routes=192.168.178.0/24
   ```

5. Open https://login.tailscale.com/admin/machines in je browser. Zoek je Mac, klik rechts op de drie puntjes en kies **Edit route settings**. Vink `192.168.178.0/24` aan en kies **Save**.

## Gebruiken

1. Zet Tailscale aan op je telefoon.
2. Open in de browser: `http://IP-VAN-JE-HOMEY:8765` (hetzelfde adres als thuis).

Zet Tailscale op je telefoon uit als je het niet nodig hebt.

## Als het niet werkt

- Controleer of Tailscale op je Mac aan staat en je Mac niet slaapt (Systeeminstellingen, Energie of Batterij: voorkom automatisch slapen als de Mac aan het lichtnet hangt).
- Controleer in de Tailscale-beheerpagina of er bij je Mac een "Subnets"-label staat en of de route is goedgekeurd.
- Je telefoon moet zelf niet op een ander netwerk met hetzelfde adresbereik zitten (192.168.178.x). Dat komt weinig voor.
