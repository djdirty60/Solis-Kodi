var EN={
"f": {
"demoMode": {
"l": "Demo mode: show made-up data",
"h": "Handy for showing the dashboard or the TV pages without an inverter. All figures are fake. Turn it off again for your real data. A standalone demo file is available at /demo.html."
},
"compareVariableImport": {
"l": "Variable contract (to compare): price per kWh (€)",
"h": "Only for the contract comparison on the dashboard and TV. Including tax and VAT. 0 = do not compare."
},
"compareVariableExport": {
"l": "Variable contract (to compare): feed-in rate per kWh (€)",
"h": ""
},
"notifyUnderperform": {
"l": "Notify when the panels clearly produce too little on sunny days",
"h": "Compared with your own norm. Only after two sunny days in a row (or when it is very bad), so you do not get false alarms. Also available as a flow trigger."
},
"underperformPct": {
"l": "Panel check: notify from this many percent below the norm",
"h": "For example 30. Lower = more sensitive, but more chance of a false alarm."
},
"notifyBackupWeekly": {
"l": "Make a back-up and notify every Sunday",
"h": "The back-up stays inside Homey. The notification contains the link to also keep it on your computer."
},
"surplusSwitchOnW": {
"l": "Surplus switch: on from (W)",
"h": "For the flow trigger Solar surplus is on. For example 1000 for a heat pump or 1400 for a car charger."
},
"surplusSwitchOffW": {
"l": "Surplus switch: off below (W)",
"h": "Lower than the on limit, so it does not switch back and forth."
},
"surplusSwitchOnMin": {
"l": "Surplus switch: on after this many minutes",
"h": "The surplus must stay above the on limit this long."
},
"surplusSwitchOffMin": {
"l": "Surplus switch: off after this many minutes",
"h": "The surplus must stay below the off limit this long."
},
"batteryCapacityKwh": {
"l": "Home battery: size to calculate (kWh)",
"h": "The calculator on the Overview always shows 2.5, 5 and 10 kWh; this size is added if you are considering something else."
},
"notifyFeedinWarn": {
"l": "Warn when feeding back costs money",
"h": "Only for dynamic contracts with feed-in costs. A notification when tomorrow's price is lower than your feed-in cost (combined with the negative price notice)."
},
"dashboardToken": {
"l": "Token for Kodi and Lucent (only with a password)",
"h": "Empty = the Kodi and Lucent addresses stay open (even with a password). With a token only devices that send it (?token=... or header X-Solis-Token) can reach them. The Kodi add-on cannot send the token yet."
},
"dashboardPassword": {
"l": "Password for the dashboard",
"h": "Empty = no password. With a password the dashboard asks you to log in first (remembered for 30 days). See docs/WACHTWOORD.md."
},
"contract": {
"l": "Current contract",
"h": "Fixed = no price control. Dynamic = the app picks a mode based on the price."
},
"dynamicFrom": {
"l": "Switch to dynamic on (dd-mm-yyyy), only with fixed",
"h": "With Fixed, the app switches to Dynamic by itself on this date."
},
"supplier": {
"l": "Supplier of the fixed contract (name only)",
"h": ""
},
"supplierOther": {
"l": "Other fixed supplier (name)",
"h": ""
},
"fixedCosts": {
"l": "Fixed costs per kWh on top of the market price (€)",
"h": "Surcharge on top of the market price: taxes, supplier fee and VAT. The app adds this to the market price."
},
"uitBelow": {
"l": "Inverter off when price is below (€/kWh)",
"h": "If the price is below this amount the inverter switches off."
},
"geenExportBelow": {
"l": "No export when price is below (€/kWh)",
"h": "If the price is below this amount the app feeds nothing back."
},
"windowEnabled": {
"l": "No export in this window",
"h": ""
},
"windowFrom": {
"l": "From (hh:mm)",
"h": ""
},
"windowTo": {
"l": "To (hh:mm)",
"h": ""
},
"basicMode": {
"l": "Basics only",
"h": "On: the app reads the inverter and lets you limit power and switch the inverter on and off (also from flows). All extras are off: reports, tips, fetching prices, weather forecast, tracking appliances, planner and the dashboard. Notifications for a fault or when the inverter cannot be reached stay on."
},
"vacationMode": {
"l": "Holiday mode: notifications for real problems only",
"h": "Stops daily messages, tips and control. You still get faults, missing yield, high temperature and unusual consumption."
},
"vacationUntil": {
"l": "Holiday mode ends automatically after (dd-mm-yyyy, empty = manual)",
"h": ""
},
"notifyFault": {
"l": "Notify on faults or missing data",
"h": ""
},
"notifyMode": {
"l": "Notify when the mode changes",
"h": ""
},
"notifyConnection": {
"l": "Notify when the connection is lost or restored",
"h": ""
},
"notifyDaily": {
"l": "Send daily report",
"h": ""
},
"dailyTime": {
"l": "Daily report time (hh:mm)",
"h": ""
},
"notifyTemp": {
"l": "Notify on high temperature",
"h": ""
},
"tempMax": {
"l": "Temperature limit (°C)",
"h": "You get a notification above this temperature."
},
"notifyNoYield": {
"l": "Notify when there is no yield while the sun shines",
"h": ""
},
"notifyPrice": {
"l": "Notify when the price passes your limits",
"h": ""
},
"notifyPlan": {
"l": "Notify when tomorrow's prices are known",
"h": ""
},
"notifyWeekly": {
"l": "Send weekly report (Sunday)",
"h": ""
},
"notifyHealth": {
"l": "Daily check at 08:00 (only notifies on problems)",
"h": ""
},
"notifyGoodMoment": {
"l": "Notify at a good moment to start appliances",
"h": ""
},
"goodMomentWatts": {
"l": "Good moment from surplus (W)",
"h": ""
},
"notifySoiling": {
"l": "Notify when yield on sunny days drops",
"h": ""
},
"notifyRecord": {
"l": "Notify on a new record or the first negative price of the year",
"h": ""
},
"notifyApplianceLong": {
"l": "Notification when an appliance stays on too long",
"h": "Longer than 1.5 times its usual duration (6 hours if the app does not know it yet). Works for the appliances under Track appliances."
},
"applianceOffWhenDone": {
"l": "Switch the plug off when the washing machine, dishwasher or dryer is done",
"h": "Half an hour after the cycle ended (so the app is sure it will not continue) the app switches the plug off. Only for a washing machine, dishwasher or dryer under Track devices, and only if it then uses almost nothing. Note: switch the plug back on before you use the appliance again. With the flow card Arm appliance the app does that itself at the best moment."
},
"notifyApplianceDone": {
"l": "Notify when a tracked appliance is done (washing machine, dishwasher)",
"h": "Works for the devices under Track devices."
},
"notifyMorning": {
"l": "Send morning summary (forecast, prices, plan, problems)",
"h": ""
},
"morningTime": {
"l": "Morning summary time (hh:mm)",
"h": ""
},
"notifyExpensive": {
"l": "Warn shortly before expensive hours (dynamic contract)",
"h": "You get a notification about half an hour before."
},
"expensiveAbove": {
"l": "Expensive from (€ per kWh, 0 = automatic)",
"h": "At 0 the app decides: hours well above the average of the next 24 hours."
},
"notifyAnomaly": {
"l": "Notify on anomalies (unusually high consumption, remarkably low yield)",
"h": ""
},
"notifyMonthly": {
"l": "Send monthly report on the 1st",
"h": ""
},
"notifyNegative": {
"l": "Notify when tomorrow's price turns negative",
"h": ""
},
"notifyPriceAlarm": {
"l": "Price alarm: notify when the price drops below a limit",
"h": ""
},
"priceAlarmBelow": {
"l": "Price alarm: limit (€ per kWh, including fixed costs)",
"h": "For example 0.05. You get one notification as soon as the price drops below it."
},
"notifyBackup": {
"l": "Reminder to download a backup yourself (about every 6 weeks)",
"h": ""
},
"notifyYearly": {
"l": "Send a year review on 31 December",
"h": ""
},
"fetchPrices": {
"l": "Fetch electricity prices (per quarter hour, dynamic contract)",
"h": "Fetches the prices per quarter hour itself (per hour if that fails), so you do not need the flow Report price."
},
"p1Enabled": {
"l": "Read grid power from the P1 dongle",
"h": "On = you do not need the flow Report grid power."
},
"p1Name": {
"l": "Name of the P1 device",
"h": "Leave empty = search automatically. Use the action Find P1 devices to see the names."
},
"trackDevices": {
"l": "Track devices (names, separated by commas)",
"h": "e.g. Washing machine, Dishwasher. Usage and costs appear in the daily report."
},
"trackAuto": {
"l": "Track all smart plugs with power measurement automatically",
"h": "Every plug that measures usage is tracked. The app learns per device how long a run takes and what it costs."
},
"importTariffFixed": {
"l": "Price per kWh (€)",
"h": "Only for cost estimates with a fixed contract. 0 = unknown. Use the all-in price including taxes and VAT."
},
"exportTariffFixed": {
"l": "Feed-in compensation per kWh (€)",
"h": ""
},
"purchasePrice": {
"l": "Purchase price of the installation (€)",
"h": "For the payback time. 0 = unknown."
},
"batteryPricePerKwh": {
"l": "Home battery price per kWh (€), for the calculator",
"h": "Only to show on the Overview whether a battery would pay for itself."
},
"supplierDyn": {
"l": "Supplier of the dynamic contract (name only)",
"h": "You can fill this in now, even if your dynamic contract starts later."
},
"supplierDynOther": {
"l": "Other dynamic supplier (name)",
"h": ""
},
"feedInCostDyn": {
"l": "Feed-in costs per kWh (€)",
"h": "Does your dynamic supplier charge per exported kWh? 0 = no costs."
},
"salderingEnd": {
"l": "Net metering ends on (dd-mm-yyyy)",
"h": "In the Netherlands net metering (salderingsregeling) ends on 1 January 2027. From then on the app values an exported kWh with the feed-in compensation below instead of as a bought kWh."
},
"feedInMarkup": {
"l": "Fixed compensation for feed-in (€ per kWh)",
"h": "What your supplier pays on top of the market price for every exported kWh. Zonneplan: € 0.02. See your contract."
},
"feedInBonusPct": {
"l": "Solar bonus on daytime feed-in (%)",
"h": "Some suppliers pay a bonus on feed-in between sunrise and sunset. Zonneplan: 10. 0 = no bonus."
},
"exportLimitAuto": {
"l": "After net metering ends, decide by itself when exporting costs money",
"h": "On: with a dynamic contract the app switches to no export as soon as exporting costs more than it earns (market price plus compensation and bonus, minus feed-in costs). The fixed limit 'No export if price below' is then not used. Off: the app keeps using that fixed limit."
},
"feedInCost": {
"l": "Feed-in costs per kWh (€)",
"h": "Many suppliers charge this. The app warns in the monthly report when feeding back costs you money. 0 = no cost."
},
"feedInSchedule": {
"l": "Feed-in cost per period (date: amount)",
"h": "Example: 01-01-2027: 0.02; 01-07-2027: 0.04. The latest amount that has started applies. Empty = the fixed amount above."
},
"invoiceMonth": {
"l": "Month of the invoice (mm-yyyy)",
"h": "Example: 01-2027. The app compares the figures on your invoice with what it measured and tells you whether they match."
},
"invoiceImportKwh": {
"l": "Consumption according to the invoice (kWh)",
"h": ""
},
"invoiceExportKwh": {
"l": "Feed-in according to the invoice (kWh)",
"h": ""
},
"invoiceTotal": {
"l": "Invoice total (€)",
"h": "Compared with my calculation: energy costs from the measurements plus the fixed costs below."
},
"invoiceFixedMonthly": {
"l": "Fixed costs per month according to your contract (€)",
"h": "Fixed supply costs plus grid fee, minus the energy tax reduction. Without this the app compares the amount with energy costs only."
},
"soliscloudKeyId": {
"l": "SolisCloud KeyID",
"h": "Request it in SolisCloud: Account, Basic settings, API management. You may have to ask Solis support first."
},
"soliscloudSecret": {
"l": "SolisCloud KeySecret",
"h": ""
},
"soliscloudSn": {
"l": "Inverter serial number (empty = automatic)",
"h": ""
},
"loadsEnabled": {
"l": "Control devices on solar surplus",
"h": "The app switches devices on when there is surplus and off when power comes from the grid. It only switches off what it switched on itself."
},
"loadsTest": {
"l": "Test mode: only log what the app would do",
"h": "Leave this on for a few days and check the log before letting it switch for real."
},
"loadsList": {
"l": "Devices (name, power in W, minimum on time in minutes)",
"h": "Example: Boiler, 2000, 15; Charger, 1400, 20. The order is the priority. The name must match the name in Homey and the device must support on/off."
},
"plannerTasks": {
"l": "Devices you can shift (name, hours, power in W)",
"h": "Example: Dishwasher, 2, 1800; Charger, 5, 7400, 07:00. The optional last value is the hour by which it must be finished. A car or heat pump with more hours works too."
},
"plannerUseLearned": {
"l": "Use learned values (duration and power from earlier runs)",
"h": "Once the app has seen a device run at least 3 times, the planner uses the real duration and power instead of your estimate."
},
"plannerLearnedAuto": {
"l": "Schedule washing machine, dishwasher, dryer and charger automatically",
"h": "Once the app has learned them you no longer need to enter them under Planner."
},
"notifyWeekPlan": {
"l": "Sunday evening: report the best laundry day of the coming days",
"h": "Every Sunday at 19:00 a notification with the sunniest day and the strongest hours."
},
"dashboardEnabled": {
"l": "Show dashboard in the browser",
"h": "Open http://YOUR-HOMEY-IP:8765 in a browser on your home network. Read-only, nothing can be changed with it."
},
"language": {
"l": "Language",
"h": "Language of messages, reports and the dashboard. Auto follows the language of your Homey."
},
"dashboardPin": {
"l": "PIN for starting appliances from the TV",
"h": "Empty = control from the TV is off. With a PIN you can arm appliances from the Kodi add-on (OK button). Digits only, 4 to 8."
},
"dashboardPort": {
"l": "Dashboard port",
"h": "Only change if 8765 is already in use."
},
"dashboardTheme": {
"l": "Default style",
"h": ""
},
"dashboardMode": {
"l": "Light or dark",
"h": "Auto follows the setting of your Mac, iPhone or tablet. On the dashboard the D key also cycles auto, dark and light."
},
"dashboardNight": {
"l": "Dim the screen after sunset",
"h": "Handy for a wall display or tablet in the living room."
},
"dashboardRotateSec": {
"l": "Tour: switch every (sec)",
"h": "Only with the Tour style."
},
"notifyFuse": {
"l": "Notify when you get close to the main fuse",
"h": "Useful on a single phase: hob, washing machine and kettle together can trip the fuse."
},
"fuseAmps": {
"l": "Main fuse (amps)",
"h": "Usually 25. See your meter cupboard or smart meter."
},
"notifyMorning": {
"l": "Morning message with the best moment for laundry",
"h": "Every morning around 07:30 a notification with the best moment during the day."
},
"notifyStandby": {
"l": "Notify when standby consumption (night use) goes up",
"h": ""
},
"inverterBrand": {
"l": "Inverter brand",
"h": "Only Solis for now. More brands will follow; testers of other inverters can help (see Help and testing)."
},
"panelKwp": {
"l": "Solar panel power (kWp)",
"h": "Number of panels × power per panel. For example 6 × 400 Wp = 2.4 kWp. The app uses it to compare your yield with what is usual. 0 = off."
},
"budgetImportKwh": {
"l": "Monthly budget for grid import (kWh)",
"h": "You get a notification at 80 % and when the budget is used up. 0 = off."
},
"householdSize": {
"l": "Number of people in the household (1 to 5)",
"h": "For the comparison with an average household on the Smart page. 0 = off."
},
"goalSelfPct": {
"l": "Daily goal: own use of your solar power (%)",
"h": "For example 50. The app counts how many days in a row you reach it. 0 = off."
},
"notifyVoltage": {
"l": "Notify when the grid voltage gets too high (inverter backs off)",
"h": ""
},
"notifyGoal": {
"l": "Notify on a streak of your daily goal (3, 7, 14 and 30 days)",
"h": ""
},
"notifyNegDay": {
"l": "Explain afterwards when nothing was fed back during a negative price",
"h": ""
},
"notifyMaintenance": {
"l": "Maintenance reminder (mid March and mid October)",
"h": ""
},
"dashboardPages": {
"l": "Pages and order",
"h": "Choose from: zon, stroom, meer, inzicht, overzicht, dynamisch, verbruik, slim, instel, spaarpot, vergelijk, kids. Separated by commas. This also sets the Tour."
}
},
"s": {
"Contract en tarieven": "Contract and rates",
"Contract": "Contract",
"Vast contract": "Fixed contract",
"Dynamisch contract": "Dynamic contract",
"Vergelijken en terugverdienen": "Compare and payback",
"Sturing bij vast contract": "Control with a fixed contract",
"Installatie en doelen": "Installation and goals",
"Sturing van de omvormer": "Inverter control",
"Vakantie": "Holiday",
"Eenvoud": "Simple",
"Meldingen: storingen en controle": "Notifications: faults and checks",
"Meldingen: rapporten": "Notifications: reports",
"Meldingen: tips en prijzen": "Notifications: tips and prices",
"Apparaten en planner": "Devices and planner",
"Koppelingen en gegevens": "Connections and data",
"Factuurcontrole": "Invoice check",
"Dashboard (Mac, tablet)": "Dashboard (Mac, tablet)",
"Contract": "Contract",
"Vast contract: tijdvenster": "Fixed contract: time window",
"Meldingen": "Notifications",
"Prijzen en weer": "Prices and weather",
"P1-dongle": "P1 dongle",
"Kosten en apparaten": "Costs and devices",
"SolisCloud (echte dagopbrengst)": "SolisCloud (real daily yield)",
"Zelfverbruik-sturing": "Self-consumption control",
"Planner": "Planner"
},
"v": {
"Dynamisch": "Dynamic",
"Vast": "Fixed",
"Andere": "Other",
"Zonnebaan": "Sun path",
"Energiestroom": "Energy flow",
"Details": "Details",
"Inzicht": "Insight",
"Overzicht": "Overview",
"Rondgang (wisselt vanzelf)": "Tour (switches automatically)",
"Weer (achtergrond volgt zon en bewolking)": "Weather (background follows sun and clouds)",
"Automatisch": "Automatic",
"Nederlands": "Dutch",
"English": "English",
"Altijd licht": "Always light",
"Altijd donker": "Always dark"
},
"u": {
"Upload het dagbestand (CSV of Excel) uit Mijn Vattenfall, niet de PDF van de factuur. De app telt de maand uit en vult de getallen hierboven in. Controleer ze met je factuur en druk dan op Opslaan.": "Upload the daily file (CSV or Excel) from My Vattenfall, not the PDF of the invoice. The app adds up the month and fills in the numbers above. Check them against your invoice and then press Save.",
"Vul in met geüpload bestand": "Fill in from uploaded file",
"Ingevuld. Controleer de getallen met je factuur en druk op Opslaan.": "Filled in. Check the numbers against your invoice and press Save.",
"Ingevuld, maar de maand is niet compleet. Lees de tekst hieronder.": "Filled in, but the month is incomplete. Read the text below.",
"Lezen mislukt: ": "Reading failed: ",
"Welkom": "Welcome",
"Sluiten": "Close",
"1. Vul het IP-adres van de datalogger in.": "1. Enter the IP address of the datalogger.",
"2. Druk op Opslaan.": "2. Press Save.",
"3. Druk onderaan op Controleer mijn installatie.": "3. At the bottom, press Check my installation.",
"Hulp en testen": "Help and testing",
"Loopt na of alles werkt (omvormer, P1-dongle, prijzen, weer, dashboard) en geeft per probleem een tip. Het foutenrapport bevat geen sleutels, wachtwoorden, e-mailadressen of volledige adressen. Plak het in een bericht aan de maker van de app.": "Checks whether everything works (inverter, P1 dongle, prices, weather, dashboard) and gives a tip for each problem. The error report contains no keys, passwords, e-mail addresses or full addresses. Paste it in a message to the maker of the app.",
"Controleer mijn installatie": "Check my installation",
"Maak foutenrapport": "Create error report",
"Kopieer": "Copy",
"Bezig met controleren, dit kan even duren...": "Checking, this can take a moment...",
" punt(en) om na te kijken. Zie de tips hierboven.": " item(s) to look at. See the tips above.",
"Alles werkt.": "Everything works.",
"Bezig met maken...": "Creating...",
"Maken mislukt: ": "Creating failed: ",
"Het rapport staat hieronder. Druk op Kopieer.": "The report is below. Press Copy.",
"Gekopieerd.": "Copied.",
"Tik in het vak en kopieer de tekst zelf.": "Tap in the box and copy the text yourself.",
"Zoek in de instellingen (bijvoorbeeld kWp, melding, tarief)": "Search the settings (for example kWp, notification, rate)",
"Geschiedenis uit Homey": "History from Homey",
"Haalt eerdere dagen op uit de meterstanden die Homey zelf bewaart (omvormer en P1). Alleen dagen die de app nog niet kent worden toegevoegd. De app doet dit ook één keer vanzelf kort na de eerste start.": "Fetches earlier days from the meter readings Homey itself keeps (inverter and P1). Only days the app does not know yet are added. The app also does this once by itself shortly after the first start.",
"Geschiedenis uit Homey ophalen": "Fetch history from Homey",
"Dagopbrengst uit SolisCloud ophalen": "Fetch daily yield from SolisCloud",
"Homey Energie vergelijken":"Compare with Homey Energy","Haalt het verbruik per dag uit Homey Energie en gebruikt dat op het dashboard. De knop Homey Energie bekijken zet vandaag naast de eigen berekening van de app.":"Asks Homey Energy what it reports for today and puts that next to the app's own calculation.","Homey Energie bekijken":"View Homey Energy","Bezig met opvragen...":"Requesting...","Opvragen mislukt: ":"Request failed: ","Verbruik uit Homey Energie ophalen":"Fetch usage from Homey Energy","Bezig met ophalen, dit kan een minuut duren...":"Fetching, this can take a minute...","Meldingen testen": "Test notifications",
"Stuur een testmelding": "Send a test notification",
"Apparaten kiezen": "Choose devices",
"Zoekt alle apparaten in Homey die hun stroomverbruik meten (slimme stekkers eerst). Vink aan welke de app moet volgen en leren, en kies daarna Toepassen en Opslaan.": "Finds all devices in Homey that measure their power use (smart plugs first). Tick the ones the app should track and learn, then choose Apply and Save.",
"Apparaten zoeken": "Find devices",
"Toepassen": "Apply",
"Zoeken op naam": "Search by name",
"Back-up": "Backup",
"Bewaart je geschiedenis en instellingen. Op je Mac kun je een bestand downloaden via het dashboard: http://IP-VAN-JE-HOMEY:8765/backup.json": "Keeps your history and settings. On your Mac you can download a file from the dashboard: http://YOUR-HOMEY-IP:8765/backup.json",
"Back-up maken": "Create backup",
"Back-up terugzetten": "Restore backup",
"Hier verschijnt je back-up. Tik erin en kopieer alles.": "Your backup appears here. Tap it and copy everything.",
"Plak hier een eerder gemaakte back-up om terug te zetten": "Paste an earlier backup here to restore it",
"Opslaan": "Save",
"Hulp bij instellen": "Setup help",
"Nieuw hier? De wizard loopt in een paar stappen langs de belangrijkste instellingen.": "New here? The wizard walks through the most important settings in a few steps.",
"Start de wizard": "Start the wizard",
"Vorige": "Back",
"Volgende": "Next",
"Klaar en opslaan": "Finish and save",
"Stoppen": "Cancel",
"Stap": "Step",
"van": "of",
"Wizard: contract": "Wizard: contract",
"Wizard: tarieven": "Wizard: rates",
"Wizard: apparaten": "Wizard: devices",
"Wizard: meldingen": "Wizard: notifications",
"Wizard: klaar": "Wizard: done",
"Welk contract heb je? Bij een vast contract schakelt de app op de ingestelde datum zelf over naar dynamisch.": "Which contract do you have? With a fixed contract the app switches to dynamic by itself on the set date.",
"Vul je tarieven in. Gebruik prijzen inclusief belasting en btw, dan klopt de vergelijking tussen vast en dynamisch.": "Enter your rates. Use prices including taxes and VAT so the comparison between fixed and dynamic is fair.",
"Welke apparaten moet de app volgen en leren? Je kunt ze straks kiezen met \"Apparaten zoeken\" onderaan de instellingen.": "Which devices should the app track and learn? You can choose them with \"Find devices\" at the bottom of the settings.",
"Welke meldingen wil je? Je kunt dit later altijd aanpassen. Voor pushmeldingen op je telefoon maak je één flow met de kaart \"Solis melding\" (zie de handleiding).": "Which notifications do you want? You can change this later. For push notifications on your phone, make one flow with the card \"Solis melding\" (see the manual).",
"De wizard zet je keuzes in het formulier en slaat ze op. Daarna zie je alles terug in de lijst hierboven.": "The wizard puts your choices into the form and saves them. You will see everything in the list above.",
"Opgeslagen.": "Saved.",
"Opslaan mislukt: ": "Saving failed: ",
"Bezig met zoeken...": "Searching...",
"Bezig met ophalen, even geduld...": "Fetching, please wait...",
"Bezig met ophalen bij SolisCloud (sla eerst de KeyID en KeySecret op)...": "Fetching from SolisCloud (save the KeyID and KeySecret first)...",
"Plak eerst een back-up.": "Paste a backup first.",
"Dit is geen geldige back-up.": "This is not a valid backup.",
"Zoeken mislukt: ": "Search failed: ",
"Ophalen mislukt: ": "Fetching failed: ",
"Back-up mislukt: ": "Backup failed: ",
"Terugzetten mislukt: ": "Restoring failed: ",
"Versturen mislukt: ": "Sending failed: ",
"Niets gevonden.": "Nothing found.",
" apparaten met vermogensmeting gevonden.": " devices with power measurement found.",
" apparaten gekozen. Druk nu op Opslaan onderaan.": " devices chosen. Now press Save at the bottom.",
"Vul een getal in bij: ": "Enter a number for: ",
"stekker": "plug",
" · nu ": " · now ",
"Gegevens importeren (Vattenfall)": "Import data (Vattenfall)",
"Zitten er gaten in je geschiedenis, bijvoorbeeld van voor de installatie van je panelen? Download bij Mijn Vattenfall je verbruiksgegevens als Excel of CSV (meestal onder Verbruik of Mijn gegevens, kies Downloaden; de tekst op het scherm kan afwijken) en kies dat bestand hier. De app vult de dagen aan waar nog geen eigen meting is. Dagen die de app zelf gemeten heeft blijven zoals ze zijn.": "Are there gaps in your history, for example from before your panels were installed? In My Vattenfall, download your usage data as Excel or CSV (usually under Usage or My data, choose Download; the wording on screen may differ) and choose that file here. The app fills the days where it has no measurement of its own. Days the app measured itself stay as they are.",
"Controleren": "Check",
"Importeren": "Import",
"Ongedaan maken": "Undo",
"Wordt het bestand niet herkend? Stuur het naar de maker van de app, dan wordt de herkenning aangepast.": "File not recognised? Send it to the maker of the app and the recognition will be adjusted.",
"Kies eerst een bestand.": "Choose a file first.",
"Het bestand is te groot (meer dan 8 MB). Download een kortere periode of splits het bestand.": "The file is too large (more than 8 MB). Download a shorter period or split the file.",
"Bezig met lezen...": "Reading...",
"Het bestand kon niet gelezen worden.": "The file could not be read.",
"Bezig met versturen": "Sending",
"Controleren mislukt: ": "Check failed: ",
"Controle klaar. Lees het voorbeeld en druk op Importeren.": "Check done. Read the preview and press Import.",
"Controle klaar. Er is niets te importeren.": "Check done. There is nothing to import.",
"Bezig met importeren...": "Importing...",
"Importeren mislukt: ": "Import failed: ",
"Klaar. Open het dashboard om het resultaat te zien.": "Done. Open the dashboard to see the result.",
"Bezig met terugzetten...": "Restoring...",
"Ongedaan maken mislukt: ": "Undo failed: "
}
};
