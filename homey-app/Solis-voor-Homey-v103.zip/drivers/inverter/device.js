'use strict';

const sunLib = require('../../lib/sun');

const Homey = require('homey');
const { Solis } = require('../../lib/solis');
const { effectiveMode, computeLimitW, resolveContract } = require('../../lib/engine');
const { DayStats, reportText } = require('../../lib/stats');
const historyLib = require('../../lib/history');
const extras = require('./extras');
const slim2 = require('./slim2');
const p1 = require('./p1');

const DEFAULT_CONTROL_S = 37;     // limiet opnieuw schrijven (omvormer vergeet hem na ~1 min)
const NET_MAX_AGE_MS = 5 * 60 * 1000;
const MIN_CONTROL_GAP_MS = 3 * 1000;
const SWITCH_REFRESH_MS = 30 * 1000;
const NORMAL_REFRESH_MS = 5 * 60 * 1000;
const PRICE_MAX_AGE_MS = 3 * 60 * 60 * 1000;   // prijs ouder dan 3 uur telt niet meer: veilig terug naar Normaal
const SURPLUS_EVERY_MS = 5 * 1000;
const WRITE_BACKOFF_MS = 20 * 1000;
const STARTUP_DELAY_MS = 15 * 1000;
const { Dashboard } = require('../../lib/dashboard');
const { createAuth } = require('../../lib/auth');
const { APP_DEFAULTS } = require('../../lib/appsettings');

module.exports = class InverterDevice extends Homey.Device {
  /** Apparaat-instellingen + app-instellingen (de pagina Instellingen van de app) samen. */
  getSettings() {
    const base = super.getSettings();
    let cfg = null;
    try { cfg = this.homey && this.homey.settings && this.homey.settings.get('cfg'); } catch (e) { cfg = null; }
    if (!cfg) return base;
    return Object.assign({}, base, APP_DEFAULTS, cfg);
  }

  /** Eenmalig: oude apparaat-instellingen overnemen in de app-instellingen. */
  migrateSettings() {
    try {
      const st = this.homey && this.homey.settings;
      if (!st || st.get('cfg')) return;
      const base = super.getSettings();
      const cfg = {};
      for (const k of Object.keys(APP_DEFAULTS)) cfg[k] = base[k] !== undefined && base[k] !== null ? base[k] : APP_DEFAULTS[k];
      st.set('cfg', cfg);
      this.logEvent && this.logEvent('Instellingen overgezet naar de app-instellingen.');
    } catch (e) { this.error(e.message); }
  }

  async onInit() {
    this.migrateSettings();
    this.applyLanguage();
    this.inv = null;
    this.price = null;
    this.netW = null;
    this.netAt = 0;
    this.pvW = 0;
    this.fails = 0;
    this.online = null;
    this.lastEffective = null;
    this.lastControlAt = 0;
    this.lastSwitchAt = 0;
    this.lastNormalAt = 0;
    this.lastFaultAlarm = 0;
    this.busy = false;
    this.priceAt = 0;
    this.surplus = 0;
    this.lastSurplusAt = 0;
    this.notifiedMode = null;
    this.priceStaleNotified = false;
    this.netStaleNotified = false;
    this.lastPersist = 0;
    this.events = this.getStoreValue('events') || [];
    this.history = this.getStoreValue('history') || [];
    // lopende apparaat-beurten terugzetten (alleen als ze minder dan 30 minuten geleden nog liepen)
    try {
      const ar = this.getStoreValue('appRun') || {};
      this.appRun = {};
      for (const n of Object.keys(ar)) { const r = ar[n]; if (r && r.on && Date.now() - (r.last || 0) < 30 * 60 * 1000) this.appRun[n] = Object.assign({}, r, { last: Date.now(), low: 0 }); }
    } catch (e) { this.appRun = {}; }
    this.restoreFromAutoBackup().catch((e) => this.error('Terugzetten uit back-up mislukt:', e.message));
    this.forecastAt = 0;
    this.priceZone = null;
    this.writeFails = 0;

    const sp = this.getStoreValue('price');
    if (sp && typeof sp.p === 'number') { this.price = sp.p; this.priceAt = sp.at || 0; }
    this.stats = new DayStats(this.getStoreValue('day'));
    if (this.stats.data().date !== this.todayString()) {
      // De app start op een nieuwe dag (bijvoorbeeld na een herinstallatie na middernacht).
      // Eerst de vorige dag bewaren; voorheen ging die dag hier verloren.
      const prev = this.stats.data();
      if (prev && prev.date && prev.lastTick && !(this.history || []).some((h) => h.date === prev.date)) {
        try {
          this.history = historyLib.addDay(this.history || [], this.dayEntry(prev));
          await this.setStoreValue('history', this.history).catch(this.error);
          this.log('Vorige dag ' + prev.date + ' bewaard bij het opstarten.');
        } catch (e) { this.error('Vorige dag bewaren mislukt:', e.message); }
      }
      this.stats.reset(this.todayString());
    }

    for (const c of ['inverter_effective', 'inverter_price', 'inverter_limit', 'inverter_surplus', 'inverter_yesterday', 'inverter_week',
      'inverter_month', 'inverter_saving_month', 'inverter_dc_current', 'inverter_forecast', 'inverter_plan_today', 'inverter_plan_tomorrow', 'inverter_last_event', 'inverter_year', 'inverter_selfuse_month', 'inverter_health', 'inverter_cost_month', 'inverter_best_hour']) {
      if (!this.hasCapability(c)) await this.addCapability(c).catch(this.error);
    }

    const wanted = this.getStoreValue('wanted') || 'auto';
    await this.setCapabilityValue('inverter_mode', wanted).catch(this.error);

    this.registerCapabilityListener('inverter_mode', async (v) => this.setWantedMode(v));
    this.registerCapabilityListener('onoff', async (v) => this.setWantedMode(v ? 'auto' : 'uit'));

    this.connect();
    if (!this.getSettings().host) {
      await this.setUnavailable('Vul eerst het IP-adres van de datalogger in bij de instellingen (tandwiel).').catch(this.error);
    }
    this.schedulePoll(STARTUP_DELAY_MS); // even wachten: de datalogger moet eerst de oude verbinding loslaten
    this.startControlTimer();
    this.reportTimer = this.homey.setInterval(() => this.checkReport().catch(this.error), 60 * 1000);
    this.externalTimer = this.homey.setInterval(() => this.refreshExternal().catch(this.error), extras.EXTERNAL_EVERY_MS);
    this.homey.setTimeout(() => this.refreshExternal().catch(this.error), 15 * 1000);
    this.logEvent('App gestart.');
    this.homey.setTimeout(() => this.startP1().catch(this.error), 5000);
    this.homey.setTimeout(() => this.startDashboard(), 6000);
    this.homey.setTimeout(() => { if (!this.getStoreValue('homeyImported') || this.missingRecentDays()) this.importFromHomey().catch((e) => this.logEvent('Overnemen uit Homey mislukt: ' + String(e.message).slice(0, 60))); }, 90 * 1000);
    this.appPower = {};
    this.appsTimer = this.homey.setInterval(() => { this.refreshApps().catch(this.error); this.loadsTick().catch(this.error); this.armedTick().catch(this.error); this.checkFuse().catch(this.error); }, 20 * 1000);
  }

  startControlTimer() {
    if (this.controlTimer) this.homey.clearInterval(this.controlTimer);
    const sec = Math.min(55, Math.max(10, Number(this.getSettings().limitRefreshSec) || DEFAULT_CONTROL_S));
    this.controlTimer = this.homey.setInterval(() => this.control().catch(this.error), sec * 1000);
  }

  // ---------- meldingen ----------
  async notify(kind, text) {
    const s = this.getSettings();
    const on = {
      mode: s.notifyMode === true,
      fault: s.notifyFault !== false,
      connection: s.notifyConnection === true,
      daily: s.notifyDaily !== false,
      temp: s.notifyTemp !== false,
      noyield: s.notifyNoYield !== false,
      price: s.notifyPrice === true,
      plan: s.notifyPlan !== false,
      weekplan: s.notifyWeekPlan !== false,
      goodmoment: s.notifyGoodMoment === true,
      soiling: s.notifySoiling !== false,
      anomaly: s.notifyAnomaly !== false,
      expensive: s.notifyExpensive !== false,
      pricealarm: s.notifyPriceAlarm === true,
      applianceLong: s.notifyApplianceLong !== false,
      feedinWarn: s.notifyFeedinWarn !== false,
      underperform: s.notifyUnderperform !== false,
      update: true,
    }[kind];
    if (!on) return;
    if (s.basicMode === true && !['fault', 'connection', 'update'].includes(kind)) return; // alleen de basis
    if (this.vacationOn() && !['fault', 'connection', 'temp', 'noyield', 'anomaly'].includes(kind)) return;
    try {
      await this.sendNotification('Solis: ' + text);
    } catch (e) { this.error('Melding mislukt:', e.message); }
  }

  connect() {
    if (this.inv) this.inv.close();
    const s = this.getSettings();
    this.inv = new Solis({
      host: s.host, port: s.port, unitId: s.unitId, timeout: 6000, maxPower: s.maxPower, idleClose: 0,
    });
  }

  startDashboard() {
    try {
      const s = this.getSettings();
      if (!this.dashboard) {
        this.dashboard = new Dashboard({
          getData: () => this.widgetData(),
          getBackup: () => this.backupDownload(),
          getFeed: (since) => this.feedSince(since),
          getCsv: () => this.csvDownload(),
          getDay: (date) => this.dayReview(date),
          getSeries: (periode) => this.seriesData(periode),
          getCompare: (a, b) => this.compareData(a, b),
          remote: this.remoteControl(),
          auth: createAuth({ getPassword: () => this.getSettings().dashboardPassword, getToken: () => this.getSettings().dashboardToken }),
          getConfig: () => {
            const c = this.getSettings();
            return { mode: c.dashboardMode || 'auto', thema: c.dashboardTheme || 'zon', nacht: c.dashboardNight !== false, wissel: Number(c.dashboardRotateSec) || 20, pages: (() => { let raw = String(c.dashboardPages || '').split(',').map((x) => x.trim().toLowerCase()).filter((x) => ['zon', 'stroom', 'meer', 'inzicht', 'overzicht', 'dynamisch', 'verbruik', 'slim', 'instel', 'spaarpot', 'vergelijk', 'kids'].includes(x)); if (raw.join(',') === 'zon,stroom,meer,inzicht,overzicht') raw = raw.concat('dynamisch'); if (raw.join(',') === 'zon,stroom,meer,inzicht,overzicht,dynamisch') raw = raw.concat('verbruik'); if (raw.join(',') === 'zon,stroom,meer,inzicht,overzicht,dynamisch,verbruik') raw = raw.concat('slim'); if (raw.join(',') === 'zon,stroom,meer,inzicht,overzicht,dynamisch,verbruik,slim') raw = raw.concat('instel'); if (raw.join(',') === 'zon,stroom,meer,inzicht,overzicht,dynamisch,verbruik,slim,instel') raw = raw.concat(['spaarpot', 'vergelijk', 'kids']); return raw; })() };
          },
          log: (m) => this.logEvent(m),
        });
      }
      this.dashboard.tz = this.homey.clock.getTimezone();
      const port = Number(s.dashboardPort) || 8765;
      if (s.dashboardEnabled === false || s.basicMode === true) this.dashboard.stop();
      else this.dashboard.start(port);
    } catch (e) { this.error(e.message); }
  }

  stopDashboard() {
    if (this.dashboard) this.dashboard.stop();
  }

  async onSettings() {
    // settings zijn pas na deze functie opgeslagen, dus even wachten
    this.homey.setTimeout(() => this.applySettings(), 500);
  }

  applySettings() {
    this.applyLanguage();
    {
      this.startControlTimer();
      this.startP1().catch(this.error);
      this.startDashboard();
      this.appDevices = null;
      this.forecastAt = 0;
      this.todayPrices = null;
      this.tomorrowPrices = null;
      this.connect();
      this.schedulePoll(500);
      this.control().catch(this.error);
      this.refreshExternal().catch(this.error);
    }
  }

  // ---------- uitlezen ----------
  schedulePoll(ms) {
    if (this.pollTimer) this.homey.clearTimeout(this.pollTimer);
    this.pollTimer = this.homey.setTimeout(() => this.poll(), ms);
  }

  /** Zonhoogte nu; null als de locatie onbekend is. */
  sunElevation() {
    try {
      const lat = this.homey.geolocation.getLatitude();
      const lon = this.homey.geolocation.getLongitude();
      if (typeof lat !== 'number' || typeof lon !== 'number') return null;
      return sunLib.elevation(Date.now(), lat, lon);
    } catch (e) { return null; }
  }

  async poll() {
    const s = this.getSettings();
    let next = s.pollSeconds * 1000;
    if (!s.host) { this.schedulePoll(5000); return; }
    try {
      const d = await this.inv.readAll();
      this.fails = 0;
      this.connNote(true);
      this.pvW = d.power;
      await this.setCapabilityValue('measure_power', d.power);
      await this.setCapabilityValue('meter_power', d.totalKwh);
      await this.setCapabilityValue('measure_voltage', d.acVoltage);
      await this.setCapabilityValue('measure_current', d.acCurrent);
      await this.setCapabilityValue('measure_temperature', d.temperature);
      await this.setCapabilityValue('inverter_today', d.todayKwh);
      await this.setCapabilityValue('inverter_dc_voltage', d.dcVoltage);
      await this.setCapabilityValue('inverter_frequency', d.frequency);
      await this.setCapabilityValue('inverter_dc_current', d.dcCurrent).catch(this.error);
      await this.setCapabilityValue('inverter_status', d.statusText);
      if (d.alarm && d.alarm !== this.lastFaultAlarm) {
        this.logEvent('Storing: ' + d.statusText + ' (' + d.alarm + ')');
        this.homey.flow.getDeviceTriggerCard('fault').trigger(this, { status: d.statusText, alarm: d.alarm }).catch(this.error);
        this.notify('fault', 'de omvormer meldt een storing: ' + d.statusText + ' (alarmcode ' + d.alarm + ').');
      }
      this.tickStats(d.power, d.todayKwh);
      this.checkExtraAlerts(d);
      await this.updateSummaryCaps(d.monthKwh);
      this.lastFaultAlarm = d.alarm;
      if (this.sleeping) {
        this.sleeping = false;
        this.logEvent('Omvormer is wakker (' + Math.round(d.power) + ' W).');
      }
      if (this.online !== true) {
        const was = this.online;
        this.online = true;
        await this.setAvailable();
        if (was === false) {
          this.logEvent('Verbinding hersteld' + (this.offlineSince ? ' na ' + Math.round((Date.now() - this.offlineSince) / 60000) + ' min.' : '.'));
          this.offlineSince = 0;
          this.homey.flow.getDeviceTriggerCard('connection_restored').trigger(this).catch(this.error);
          if (this.lostNotifiedAt && Date.now() - this.lostNotifiedAt < 12 * 3600 * 1000) this.notify('connection', 'verbinding met de omvormer is hersteld.');
        }
      }
    } catch (e) {
      this.fails += 1;
      this.error('Uitlezen mislukt:', e.message);
      if (typeof this.noteModbusError === 'function') this.noteModbusError(e.message);
      if (this.fails % 6 === 0) {
        // vastgelopen verbinding: helemaal opnieuw opbouwen (zoals een herstart van de app)
        this.logEvent('Verbinding opnieuw opgebouwd (na ' + this.fails + ' mislukte pogingen).');
        this.connect();
      }
      const elev = this.sunElevation();
      if (this.fails >= 3) this.connNote(false, elev);
      if (this.fails >= 3 && elev !== null && elev < 10 && this.online !== false) {
        // ochtend/avond: de omvormer en de datalogger slapen of schakelen aan en uit door te weinig zon. Dat is geen storing.
        this.pvW = 0;
        await this.setCapabilityValue('measure_power', 0).catch(this.error);
        await this.setCapabilityValue('inverter_status', 'Wacht op zon').catch(this.error);
        if (!this.sleeping) { this.sleeping = true; this.logEvent('Omvormer slaapt of heeft te weinig zon (zon ' + Math.round(elev) + '°). Ik blijf rustig proberen.'); }
        // vlak voor en na zonsopkomst vaak proberen, dieper in de nacht zelden
        next = elev > -4 ? 20 * 1000 : (elev > -10 ? 60 * 1000 : 5 * 60 * 1000);
      } else if (this.fails >= 3) {
        this.pvW = 0;
        await this.setCapabilityValue('measure_power', 0).catch(this.error);
        const msg = 'Niet bereikbaar op ' + s.host + ':' + s.port + ' (ID ' + s.unitId + '). Fout: ' + e.message + '. Ik blijf het proberen.';
        if (this.online !== false) {
          this.online = false;
          this.offlineSince = Date.now();
          this.logEvent('Verbinding weg: ' + e.message);
          this.homey.flow.getDeviceTriggerCard('connection_lost').trigger(this).catch(this.error);
          // 's avonds en 's nachts slaapt de omvormer: dat is geen storing. Alleen overdag melden, en hooguit eens per 2 uur.
          const m = this.currentMinutes();
          if (m >= 9 * 60 && m <= 16 * 60 && Date.now() - (this.lostNotifiedAt || 0) > 2 * 3600 * 1000) {
            this.lostNotifiedAt = Date.now();
            this.notify('connection', 'omvormer niet bereikbaar.');
          }
        }
        if (this.lastMsg !== msg) {
          this.lastMsg = msg;
          await this.setUnavailable(msg).catch(this.error);
        }
        next = this.fails < 20 ? (Number(s.retryFastSec) || 30) * 1000 : (Number(s.retrySlowMin) || 5) * 60 * 1000; // eerst vaak proberen, 's nachts niet hameren
      }
    }
    if (this.lastEffective === 'geen-export' && this.online && this.fails === 0) next = Math.min(next, 5000);
    // Eén blijvende verbinding met de datalogger, in plaats van elke 20 seconden open en dicht.
    // De S2-WL-ST loopt vast (poort 502 antwoordt niet meer) als er duizenden keren per dag opnieuw verbonden wordt.
    if (this.inv && this.inv.setIdleClose) this.inv.setIdleClose(0);
    this.schedulePoll(next);
  }

  // ---------- stand ----------
  async setWantedMode(mode) {
    await this.setStoreValue('wanted', mode);
    await this.setCapabilityValue('inverter_mode', mode).catch(this.error);
    this.lastNormalAt = 0;
    this.lastEffective = null;
    await this.control(true);
  }

  async emergency() {
    this.log('NOODSTOP');
    await this.setWantedMode('normaal');
  }

  async reportNetPower(w) {
    if (Number.isNaN(w)) return;
    this.netW = w;
    this.netAt = Date.now();
    this.netStaleNotified = false;
    this.updateSurplus(w);
    if (this.lastEffective === 'geen-export' && Date.now() - this.lastControlAt > MIN_CONTROL_GAP_MS) {
      await this.control().catch(this.error);
    }
  }

  async reportPrice(p) {
    if (Number.isNaN(p)) return;
    if (this.price !== p) await this.setStoreValue('price', { p, at: Date.now() }).catch(this.error);
    this.price = p;
    this.priceAt = Date.now();
    this.priceStaleNotified = false;
    await this.setCapabilityValue('inverter_price', p).catch(this.error);
    await this.control().catch(this.error);
  }

  updateSurplus(netW) {
    const now = Date.now();
    if (now - this.lastSurplusAt < SURPLUS_EVERY_MS) return;
    this.lastSurplusAt = now;
    const sur = Math.max(0, Math.round(-netW));
    const prev = this.surplus;
    if (sur === prev) return;
    this.surplus = sur;
    this.setCapabilityValue('inverter_surplus', sur).catch(this.error);
    this.homey.flow.getDeviceTriggerCard('surplus_above').trigger(this, { surplus: sur }, { surplus: sur, prev }).catch(this.error);
  }

  currentContract() {
    const s = this.getSettings();
    return resolveContract(s.contract, s.dynamicFrom, this.todayString());
  }

  importPrice(price) {
    const s = this.getSettings();
    if (this.currentContract() === 'dynamisch') return price;
    return Number(s.importTariffFixed) > 0 ? Number(s.importTariffFixed) : null;
  }

  exportPrice(price) {
    const s = this.getSettings();
    if (this.currentContract() === 'dynamisch') return price === null ? null : price - (Number(s.fixedCosts) || 0);
    return Number(s.importTariffFixed) > 0 ? Number(s.exportTariffFixed) || 0 : null;
  }

  freshPrice() {
    if (this.price !== null && this.priceAt && Date.now() - this.priceAt <= PRICE_MAX_AGE_MS) return this.price;
    return this.ownPrice();
  }

  tickStats(pvW, todayKwh) {
    const today = this.todayString();
    if (this.stats.data().date !== today) {
      this.closeDay(this.stats.data());
      this.stats.reset(today);
      this.forecastAt = 0; // nieuwe dag: nieuwe verwachting
      this.rollPrices(today);
    }
    const now = Date.now();
    const price = this.freshPrice();
    const fixed = Number(this.getSettings().fixedCosts) || 0;
    this.stats.tick({
      now,
      mode: this.lastEffective,
      pvW,
      netW: now - this.netAt < 60000 ? this.netW : undefined,
      price,
      todayKwh,
      potW: this.potentialNowW(),
      saveRate: price !== null && this.currentContract() === 'dynamisch' ? Math.max(0, fixed - price) : 0,
      importPrice: this.importPrice(price),
      exportPrice: this.exportPrice(price),
      apps: this.appPower,
      acV: Number(this.getCapabilityValue('measure_voltage')) || undefined,
      hour: Math.floor(this.currentMinutes() / 60),
    });
    this.checkGoodMoment();
    try { this.checkSurplusSwitch(); } catch (e) { this.error(e.message); }
    this.checkSpecials(todayKwh, price);
    this.checkPriceZone(price);
    if (this.isWeeklyDue() && this.currentMinutes() >= 20 * 60 + 30) this.sendWeekly().catch(this.error);
    if (now - this.lastPersist > 60 * 1000) { // elke minuut bewaren: bij een update gaat dan hooguit een minuut verloren
      this.lastPersist = now;
      this.setStoreValue('day', this.stats.data()).catch(this.error);
    }
  }

  // ---------- dagrapport ----------
  async checkReport() {
    if (this.isHealthDue()) await this.healthCheck(false);
    await this.checkMorning().catch(this.error);
    await this.checkExpensive().catch(this.error);
    await this.checkNegativeTomorrow().catch(this.error);
    await this.checkPriceAlarm().catch(this.error);
    await this.checkMonthly().catch(this.error);
    try { this.lightTick(); } catch (e) { this.error(e.message); }
    await this.checkWeekPlan().catch(this.error);
    await this.checkYearly().catch(this.error);
    this.checkBestMoment();
    await this.checkWindows().catch(this.error);
    this.refreshHomeyToday().catch(this.error);
    await this.checkHomeyEnergyDaily().catch(this.error);
    await this.checkVacationEnd().catch(this.error);
    await this.checkInvoice().catch(this.error);
    await this.checkSlim().catch(this.error);
    await this.checkMaintenance().catch(this.error);
    await this.checkMorning().catch(this.error);
    await this.autoBackup().catch(this.error);
    await this.checkBackupReminder().catch(this.error);
    await this.checkWeeklyBackup().catch(this.error);
    const s = this.getSettings();
    if (s.notifyDaily === false) return;
    const m = /^(\d{1,2}):(\d{2})$/.exec(s.dailyTime || '21:00');
    if (!m) return;
    const today = this.todayString();
    if (this.getStoreValue('lastReport') === today) return;
    if (this.currentMinutes() >= Number(m[1]) * 60 + Number(m[2])) await this.sendReport(false);
  }

  async sendReport(manual) {
    const d = this.stats.data();
    const today = this.todayString();
    const kwh = Number(this.getCapabilityValue('inverter_today')) || 0;
    const text = reportText(d, kwh, this.currentContract());
    await this.setStoreValue('lastReport', today).catch(this.error);
    this.logEvent('Dagrapport verstuurd.');
    await this.setStoreValue('day', d).catch(this.error);
    if (this.getSettings().basicMode === true) return; // alleen de basis: geen dagrapport
    try {
      await this.sendNotification('Solis dagrapport: ' + text);
    } catch (e) { this.error('Dagrapport melding mislukt:', e.message); }
    this.homey.flow.getDeviceTriggerCard('daily_report').trigger(this, {
      text,
      produced: kwh,
      peak: Math.round(d.peakW),
      limited_hours: Math.round((d.ms['geen-export'] / 3600000) * 10) / 10,
      off_hours: Math.round((d.ms.uit / 3600000) * 10) / 10,
      exported: Math.round(d.exportWh) / 1000,
      min_price: d.minPrice === null ? 0 : d.minPrice,
      max_price: d.maxPrice === null ? 0 : d.maxPrice,
      neg_exported: Math.round(d.exportNegWh) / 1000,
      neg_cost: Math.round(d.exportNegCost * 1000) / 1000,
    }).catch(this.error);
    return manual;
  }

  todayString() {
    return new Intl.DateTimeFormat('en-CA', { timeZone: this.homey.clock.getTimezone(), year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  }

  currentMinutes() {
    const tz = this.homey.clock.getTimezone();
    const parts = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date());
    const h = Number(parts.find((x) => x.type === 'hour').value) % 24;
    const m = Number(parts.find((x) => x.type === 'minute').value);
    return h * 60 + m;
  }

  async control(force) {
    if (this.busy) return;
    const s = this.getSettings();
    const wanted = this.getStoreValue('wanted') || 'auto';
    const cfg = {
      contract: resolveContract(s.contract, s.dynamicFrom, this.todayString()),
      uitBelow: s.uitBelow,
      geenExportBelow: s.geenExportBelow,
      window: { enabled: s.windowEnabled, from: s.windowFrom, to: s.windowTo },
    };
    const price = this.freshPrice();
    if (cfg.contract === 'dynamisch' && wanted === 'auto' && this.priceAt && price === null && !this.priceStaleNotified) {
      this.priceStaleNotified = true;
      this.notify('fault', 'al meer dan 3 uur geen prijs ontvangen. De stand staat veilig op Normaal. Controleer je flow "Geef prijs door".');
    }
    const eff = effectiveMode(wanted, cfg, price, this.currentMinutes());
    const changed = eff !== this.lastEffective;
    this.trackNegSaving(price, eff);
    this.busy = true;
    try {
      if (changed) {
        this.lastEffective = eff;
        await this.setCapabilityValue('inverter_effective', eff).catch(this.error);
        await this.setCapabilityValue('onoff', eff !== 'uit').catch(this.error);
        this.homey.flow.getDeviceTriggerCard('mode_changed').trigger(this, { mode: eff, price: price === null ? 0 : price }).catch(this.error);
        if (this.notifiedMode !== null && this.notifiedMode !== eff) this.notify('mode', 'stand is nu "' + eff + '".');
        this.notifiedMode = eff;
        this.logEvent('Stand: ' + eff + (price === null ? '' : ' (prijs ' + price.toFixed(3).replace('.', ',') + ')'));
      }
      if (!s.allowWrite || this.online !== true) return;
      const now = Date.now();
      if (!force && this.lastWriteFailAt && now - this.lastWriteFailAt < WRITE_BACKOFF_MS) return; // datalogger even met rust laten
      this.lastControlAt = now;

      if (eff === 'normaal') {
        if (changed || force || now - this.lastNormalAt > NORMAL_REFRESH_MS) {
          this.lastNormalAt = now;
          await this.inv.setOn();
          await this.inv.setLimitRaw(11000);
          await this.inv.limitSwitch(false);
          await this.setCapabilityValue('inverter_limit', s.maxPower).catch(this.error);
        }
      } else if (eff === 'uit') {
        await this.inv.setOff(); // elke ronde herhalen
        await this.setCapabilityValue('inverter_limit', 0).catch(this.error);
      } else if (eff === 'geen-export') {
        if (changed) await this.inv.setOn();
        if (this.netW === null || now - this.netAt > NET_MAX_AGE_MS) {
          this.log('Geen recent netvermogen ontvangen; limiet niet aangepast');
          this.lastControlAt = 0; // zodra er netvermogen binnenkomt meteen aanpassen
          if (!this.netStaleNotified) {
            this.netStaleNotified = true;
            this.notify('fault', 'geen netvermogen ontvangen. Geen export werkt niet zonder. Controleer je flow "Geef netvermogen door".');
          }
          return;
        }
        const w = computeLimitW(this.pvW, this.netW, s.margin, s.maxPower);
        if (changed || now - this.lastSwitchAt > SWITCH_REFRESH_MS) {
          this.lastSwitchAt = now;
          await this.inv.limitSwitch(true);
        }
        await this.inv.setLimitWatts(w);
        await this.setCapabilityValue('inverter_limit', w).catch(this.error);
      }
      this.writeFails = 0;
    } catch (e) {
      this.error('Aansturen mislukt:', e.message);
      this.lastWriteFailAt = Date.now();
      this.writeFails += 1;
      if (this.writeFails === 3) {
        this.logEvent('Schrijven naar omvormer mislukt (3x): ' + e.message);
        this.notify('fault', 'schrijven naar de omvormer mislukt (3 keer achter elkaar): ' + e.message);
      }
    } finally {
      this.busy = false;
    }
  }

  async onUninit() {
    // app stopt (herstart of nieuwe versie): verbinding netjes sluiten
    for (const t of ['pollTimer']) if (this[t]) this.homey.clearTimeout(this[t]);
    for (const t of ['controlTimer', 'reportTimer', 'externalTimer']) if (this[t]) this.homey.clearInterval(this[t]);
    if (this.appsTimer) this.homey.clearInterval(this.appsTimer);
    this.stopP1();
    this.stopDashboard();
    if (this.inv) this.inv.close();
  }

  async onDeleted() {
    if (this.pollTimer) this.homey.clearTimeout(this.pollTimer);
    if (this.controlTimer) this.homey.clearInterval(this.controlTimer);
    if (this.reportTimer) this.homey.clearInterval(this.reportTimer);
    if (this.externalTimer) this.homey.clearInterval(this.externalTimer);
    this.stopP1();
    this.stopDashboard();
    try {
      // laat de omvormer in een veilige toestand achter
      if (this.inv && this.getSettings().allowWrite) {
        await this.inv.setOn();
        await this.inv.setLimitRaw(11000);
        await this.inv.limitSwitch(false);
      }
    } catch (e) { /* niet kritiek */ }
    if (this.inv) this.inv.close();
  }
};

Object.assign(module.exports.prototype, extras, p1, slim2);
